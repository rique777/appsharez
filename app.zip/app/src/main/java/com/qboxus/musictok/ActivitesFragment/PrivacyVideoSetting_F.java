package com.qboxus.musictok.ActivitesFragment;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;

public class PrivacyVideoSetting_F extends Fragment implements View.OnClickListener {

    View view;
    TextView viewVideo;
    Switch allowCommentSwitch, allowDuetSwitch;
    String videoId, commentValue, duetValue, privacyValue, duetVideoId;
    RelativeLayout allowDuetLayout;
    FragmentCallBack callback;
    Boolean callApi = false;
    Bundle bundle;

    public PrivacyVideoSetting_F(FragmentCallBack callback) {
        this.callback = callback;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_privacy_video_setting, container, false);
        viewVideo = view.findViewById(R.id.view_video);
        allowDuetLayout = view.findViewById(R.id.allow_duet_layout);

        allowCommentSwitch = view.findViewById(R.id.allow_comment_switch);
        allowCommentSwitch.setOnClickListener(this);

        allowDuetSwitch = view.findViewById(R.id.allow_duet_switch);
        allowDuetSwitch.setOnClickListener(this);

        view.findViewById(R.id.view_video_layout).setOnClickListener(this);
        view.findViewById(R.id.back_btn).setOnClickListener(this);

        Bundle bundle = getArguments();
        if (bundle != null) {

            videoId = bundle.getString("video_id");
            privacyValue = bundle.getString("privacy_value");
            duetValue = bundle.getString("duet_value");
            commentValue = bundle.getString("comment_value");
            duetVideoId = bundle.getString("duet_video_id");

            viewVideo.setText(privacyValue);

            allowCommentSwitch.setChecked(commentValue(commentValue));

            allowDuetSwitch.setChecked(getTrueFalseCondition(duetValue));

            if (Functions.getSharedPreference(getContext()).getBoolean(Variables.IsExtended,false) && (duetVideoId != null && duetVideoId.equalsIgnoreCase("0"))) {
                allowDuetLayout.setVisibility(View.VISIBLE);
            }
        }
        return view;
    }


    private boolean getTrueFalseCondition(String str) {
        if (str.equalsIgnoreCase("1"))
            return true;
        else
            return false;
    }


    private boolean commentValue(String str) {
        if (str.equalsIgnoreCase("true"))
            return true;
        else
            return false;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.view_video_layout:
                openDialogForPrivacy(getActivity());
                break;

            case R.id.back_btn:
                getActivity().onBackPressed();
                break;

            case R.id.allow_duet_switch:
                if (allowDuetSwitch.isChecked()) {
                    duetValue = "1";
                } else {
                    duetValue = "0";
                }
                callApi();
                break;

            case R.id.allow_comment_switch:
                if (allowCommentSwitch.isChecked()) {
                    commentValue = "true";
                } else {
                    commentValue = "false";
                }
                callApi();
                break;

            default:
                break;


        }

    }


    // call api for change the privacy setting of profile
    public void callApi() {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", videoId);
            params.put("allow_comments", commentValue);
            params.put("allow_duet", duetValue);
            params.put("privacy_type", viewVideo.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.printLog(Constants.tag, "params at video_setting: " + params);

        ApiRequest.callApi(getActivity(), ApiLinks.updateVideoDetail, params, new Callback() {
            @Override
            public void onResponce(String resp) {

                parseDate(resp);


            }
        });

    }


    public void parseDate(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");

            if (code.equals("200")) {
                Functions.showToast(view.getContext(), "Setting Update");

                callApi = true;
                bundle = new Bundle();
                bundle.putString("video_id", videoId);
                bundle.putBoolean("call_api", callApi);
            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    // open the dialog for privacy public or private options
    private void openDialogForPrivacy(Context context) {
        final CharSequence[] options = {"Public", "Private"};

        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AlertDialogCustom);

        builder.setTitle(null);

        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override

            public void onClick(DialogInterface dialog, int item) {
                viewVideo.setText(options[item]);
                callApi();
                dialog.dismiss();

            }

        });

        builder.show();

    }


    @Override
    public void onDetach() {
        super.onDetach();
        if (callback != null) {
            callback.onResponce(bundle);
        }
    }


}