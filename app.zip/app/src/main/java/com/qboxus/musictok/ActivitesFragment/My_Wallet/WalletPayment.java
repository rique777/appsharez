package com.qboxus.musictok.ActivitesFragment.My_Wallet;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;


public class WalletPayment extends Fragment implements View.OnClickListener{

    View view;
    ImageView btnBack;
    TextView tvEmail,tvAdd;

    public WalletPayment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_wallet_payment, container, false);
        METHOD_initViews();

        return view;
    }


    private void METHOD_initViews() {
        tvAdd = view.findViewById(R.id.tvAdd);
        tvAdd.setOnClickListener(this);
        btnBack = view.findViewById(R.id.back_btn);
        btnBack.setOnClickListener(this);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvEmail.setOnClickListener(this);
        SetupScreenData();

    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tvAdd:
            {
                METHOD_openAddCard_F(false);
            }
            break;
            case R.id.back_btn:
            {
                getActivity().onBackPressed();
            }
            break;
            case R.id.tvEmail:
            {
                METHOD_openAddCard_F(true);
            }
            break;
            default:
                break;
        }
    }


    private void METHOD_openAddCard_F(boolean isEdit) {
        AddPayoutMethod f = new AddPayoutMethod(new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {
                if (bundle.getBoolean("isShow",false))
                {
                    SetupScreenData();
                }
            }
        });
        Bundle bundle = new Bundle();
        bundle.putString("email",tvEmail.getText().toString());
        bundle.putBoolean("isEdit",isEdit);
        f.setArguments(bundle);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.payout_method_container, f).commit();
    }

    private void SetupScreenData() {
        tvEmail.setText(Functions.getSharedPreference(view.getContext()).getString(Variables.U_PAYOUT_ID,""));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        System.out.println("Check : payment ");
    }

}
