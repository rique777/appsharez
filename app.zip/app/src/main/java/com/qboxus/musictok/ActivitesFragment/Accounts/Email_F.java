package com.qboxus.musictok.ActivitesFragment.Accounts;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Models.UserModel;
import com.qboxus.musictok.MainMenu.MainMenuActivity;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;

public class Email_F extends Fragment implements View.OnClickListener {

    View view;
    EditText emailEdit, passwordEdt;
    TextView loginTermsConditionTxt, forgotPassBtn;
    Button nextBtn;
    SharedPreferences sharedPreferences;
    String fromWhere;
    UserModel userModel;

    public Email_F(UserModel userModel, String fromWhere) {
        this.userModel = userModel;
        this.fromWhere = fromWhere;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_email_reg, container, false);
        emailEdit = view.findViewById(R.id.email_edit);
        passwordEdt = view.findViewById(R.id.password_edt);
        forgotPassBtn = view.findViewById(R.id.forgot_pass_btn);
        nextBtn = view.findViewById(R.id.btn_next);
        loginTermsConditionTxt = view.findViewById(R.id.login_terms_condition_txt);
        sharedPreferences = Functions.getSharedPreference(getContext());
        if (fromWhere != null && fromWhere != null) {
            if (fromWhere.equals("login")) {
                loginTermsConditionTxt.setVisibility(View.GONE);
                forgotPassBtn.setVisibility(View.VISIBLE);
                passwordEdt.setVisibility(View.VISIBLE);
                nextBtn.setText("Log in");
            } else {
                if (userModel != null) {
                    emailEdit.setText(userModel.email);
                    nextBtn.setEnabled(true);
                    nextBtn.setClickable(true);
                }
            }
        }


        emailEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                // check the email validation during user typing
                String txtName = emailEdit.getText().toString();
                if (txtName.length() > 0) {
                    nextBtn.setEnabled(true);
                    nextBtn.setClickable(true);
                } else {
                    nextBtn.setEnabled(false);
                    nextBtn.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        nextBtn.setOnClickListener(this::onClick);
        forgotPassBtn.setOnClickListener(this::onClick);


        return view;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_next:
                Functions.printLog(Constants.tag,"next button click");
                // check the email validation and then call the api for login or open the password screen depend of login or signup
                if (checkValidation()) {
                    if (fromWhere.equals("login")) {
                        Functions.printLog(Constants.tag,"next button Login");
                        callApiForLogin();
                    } else {
                        Functions.printLog(Constants.tag,"next button Signup");
                        CreatePassword_F create_password_f = new CreatePassword_F("fromEmail");
                        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                        Bundle bundle = new Bundle();
                        userModel.email = emailEdit.getText().toString();
                        bundle.putSerializable("user_model", userModel);
                        create_password_f.setArguments(bundle);
                        transaction.addToBackStack(null);
                        transaction.replace(R.id.sign_up_fragment, create_password_f).commit();
                    }
                }
                break;
            case R.id.forgot_pass_btn:
                startActivity(new Intent(getActivity(), ForgotPass_A.class));
                break;
        }

    }

    private void callApiForLogin() {
        JSONObject parameters = new JSONObject();
        try {

            parameters.put("email", emailEdit.getText().toString());
            parameters.put("password", "" + passwordEdt.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(getActivity(), false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.login, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                parseLoginData(resp);

            }
        });

    }

    public void parseLoginData(String loginData) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {

                JSONObject jsonArray = jsonObject.getJSONObject("msg");
                JSONObject userdata = jsonArray.getJSONObject("User");
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(Variables.U_ID, userdata.optString("id"));
                editor.putString(Variables.F_NAME, userdata.optString("first_name"));
                editor.putString(Variables.L_NAME, userdata.optString("last_name"));
                editor.putString(Variables.U_NAME, userdata.optString("username"));
                editor.putString(Variables.GENDER, userdata.optString("gender"));
                editor.putString(Variables.U_PIC, userdata.optString("profile_pic"));
                editor.putString(Variables.AUTH_TOKEN, userdata.optString("auth_token"));
                editor.putString(Variables.U_WALLET, userdata.optString("wallet","0"));
                editor.putString(Variables.U_PAYOUT_ID, userdata.optString("paypal",""));
                editor.putBoolean(Variables.IS_LOGIN, true);
                editor.commit();

                Variables.reloadMyVideos = true;
                Variables.reloadMyVideosInner = true;
                Variables.reloadMyLikesInner = true;
                Variables.reloadMyNotification = true;
                getActivity().finish();
                startActivity(new Intent(getActivity(), MainMenuActivity.class));

            } else {
                Toast.makeText(getActivity(), jsonObject.optString("msg"), Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // this will check the validations like none of the field can be the empty
    public boolean checkValidation() {

        final String st_email = emailEdit.getText().toString();
        final String password = passwordEdt.getText().toString();

        Functions.printLog(Constants.tag,"next button st_email");

        if (TextUtils.isEmpty(st_email)) {
            emailEdit.setError("Please enter email");
            return false;
        }

        else if(!Functions.isValidEmail(st_email)){
            emailEdit.setError("Please enter valid email");
            return false;
        }

        if (fromWhere.equals("login")) {
            if (TextUtils.isEmpty(password)) {
                passwordEdt.setError("Please enter password");
                return false;
            }
        }

        return true;
    }


}