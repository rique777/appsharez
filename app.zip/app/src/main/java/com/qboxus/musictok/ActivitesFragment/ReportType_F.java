package com.qboxus.musictok.ActivitesFragment;

import android.content.pm.ActivityInfo;
import android.os.Bundle;

import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qboxus.musictok.Adapters.ReportTypeAdapter;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.ReportTypeModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class ReportType_F extends RootFragment implements View.OnClickListener {


    View view;
    RecyclerView recyclerview;
    ReportTypeAdapter adapter;
    Boolean isFromRegister;

    private FragmentCallBack fragmentCallBack;
    String videoId, userId;


    ArrayList<ReportTypeModel> dataList = new ArrayList<>();

    public ReportType_F(boolean isfrom, FragmentCallBack callBack) {
        this.isFromRegister = isfrom;
        this.fragmentCallBack = callBack;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_report_type, container, false);
        view.findViewById(R.id.back_btn).setOnClickListener(this);
        recyclerview = view.findViewById(R.id.recylerview);

        Bundle bundle = getArguments();
        if (bundle != null) {
            videoId = bundle.getString("video_id");
            userId = bundle.getString("user_id");
        }

        callApiForGetReportType();

        return view;
    }


    // get the types of reports
    private void callApiForGetReportType() {

        Functions.showLoader(getActivity(), false, false);
        JSONObject parameters = new JSONObject();
        ApiRequest.callApi(getActivity(), ApiLinks.showReportReasons, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {

                Functions.printLog(Constants.tag, "resp at report : " + resp);
                Functions.cancelLoader();
                parseData(resp);
            }
        });

    }

    private void parseData(String resp) {
        dataList.clear();
        try {
            JSONObject jsonObject = new JSONObject(resp);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");

                for (int i = 0; i < msgArray.length(); i++) {
                    JSONObject itemdata = msgArray.optJSONObject(i);
                    JSONObject reportreason = itemdata.optJSONObject("ReportReason");

                    ReportTypeModel item = new ReportTypeModel();
                    item.id = reportreason.optString("id");
                    item.title = reportreason.optString("title");
                    dataList.add(item);
                }
                setAdapter();
                Functions.cancelLoader();

            } else {
                Functions.cancelLoader();
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            Functions.cancelLoader();
            e.printStackTrace();
        }

    }


    private void setAdapter() {
        adapter = new ReportTypeAdapter(getActivity(), dataList, new ReportTypeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int positon, ReportTypeModel item, View view) {
                switch (view.getId()) {
                    case R.id.rlt_report:
                        if (isFromRegister) {
                            Functions.printLog(Constants.tag, item.title);
                            sendDataBack(item.title);
                        } else {
                            SubmitReport_F submit_report_f = new SubmitReport_F(new FragmentCallBack() {
                                @Override
                                public void onResponce(Bundle bundle) {
                                    getActivity().onBackPressed();
                                }
                            });
                            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                            transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
                            transaction.addToBackStack(null);
                            Bundle args = new Bundle();
                            args.putString("report_id", item.id);
                            args.putString("report_type", item.title);
                            args.putString("video_id", videoId);
                            args.putString("user_id", userId);
                            submit_report_f.setArguments(args);
                            transaction.replace(R.id.fragment_select_report, submit_report_f).commit();
                        }

                        break;

                }
            }
        });

        adapter.setHasStableIds(true);
        recyclerview.setHasFixedSize(true);
        recyclerview.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerview.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    private void sendDataBack(String reason) {

        Bundle bundle = new Bundle();
        if (isFromRegister) {
            bundle.putString("reason", reason);
            fragmentCallBack.onResponce(bundle);
            getFragmentManager().popBackStackImmediate();
        }

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.back_btn:
                getActivity().onBackPressed();
                break;
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (!isFromRegister) {
            if (fragmentCallBack != null)
                fragmentCallBack.onResponce(new Bundle());
        }

    }


}