package com.qboxus.musictok.Interfaces;

/**
 * Created by qboxus on 3/26/2019.
 */

public interface ProgressBarListener {

    void timeinMill(long mills);
}
