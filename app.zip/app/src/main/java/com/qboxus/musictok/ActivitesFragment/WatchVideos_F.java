package com.qboxus.musictok.ActivitesFragment;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.danikula.videocache.HttpProxyCacheServer;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.upstream.DefaultAllocator;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.CacheDataSource;
import com.google.android.exoplayer2.upstream.cache.CacheDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;
import com.hendraanggrian.appcompat.widget.SocialTextView;
import com.hendraanggrian.appcompat.widget.SocialView;
import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.Adapters.WatchVideosAdapter;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.TicTic;
import com.qboxus.musictok.ActivitesFragment.SoundLists.VideoSound_A;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.Interfaces.KeyboardHeightObserver;
import com.qboxus.musictok.SimpleClasses.KeyboardHeightProvider;
import com.qboxus.musictok.MainMenu.MainMenuActivity;
import com.qboxus.musictok.MainMenu.MainMenuFragment;
import com.qboxus.musictok.ActivitesFragment.Profile.Profile_F;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.APICallBack;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.Interfaces.FragmentDataSend;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.OnProgressListener;
import com.downloader.PRDownloader;
import com.downloader.Progress;
import com.downloader.request.DownloadRequest;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.util.Util;
import com.qboxus.musictok.ActivitesFragment.VideoRecording.Video_Recoder_Duet_A;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Function;


/**
 * A simple {@link Fragment} subclass.
 */

public class WatchVideos_F extends AppCompatActivity implements Player.EventListener,
        KeyboardHeightObserver, View.OnClickListener, FragmentDataSend {

    Context context;

    RecyclerView recyclerView;
    ArrayList<HomeModel> dataList;
    int position = 0;
    int currentPage = -1;
    LinearLayoutManager layoutManager;

    WatchVideosAdapter adapter;

    ProgressBar p_bar;

    private KeyboardHeightProvider keyboardHeightProvider;

    RelativeLayout writeLayout;

    EditText messageEdit;
    ImageButton sendBtn;
    ProgressBar sendProgress;

    Handler handler;
    Runnable runnable;
    Boolean animationRunning = false;

    String videoId;
    String link;

    public WatchVideos_F() {

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_watchvideo);
        context = this;


        p_bar = findViewById(R.id.p_bar);
        handler = new Handler();
        Intent bundle = getIntent();
        if (bundle != null) {

            Uri appLinkData = bundle.getData();
            videoId = bundle.getStringExtra("video_id");

            if (videoId != null) {
                callApiForSinglevideos(videoId);
            } else if (appLinkData == null) {
                dataList = (ArrayList<HomeModel>) bundle.getSerializableExtra("arraylist");
                position = bundle.getIntExtra("position", 0);
                setAdapter();
            } else {
                link = appLinkData.toString();
                String[] parts = link.split("=");
                videoId = parts[1];
                callApiForSinglevideos(parts[1]);
            }

        }


        findViewById(R.id.goBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        writeLayout = findViewById(R.id.write_layout);
        messageEdit = findViewById(R.id.message_edit);
        sendBtn = findViewById(R.id.send_btn);
        sendBtn.setOnClickListener(this);

        sendProgress = findViewById(R.id.send_progress);

        keyboardHeightProvider = new KeyboardHeightProvider(this);


        findViewById(R.id.watchVideo_F).post(new Runnable() {
            public void run() {
                keyboardHeightProvider.start();
            }
        });


       getSupportFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                int count = getSupportFragmentManager().getBackStackEntryCount();
                if (count == 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Functions.blackStatusBar(WatchVideos_F.this);
                    }

                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Functions.whiteStatusBar(WatchVideos_F.this);
                    }
                }
            }
        });


    }


    @Override
    public void onBackPressed() {

        if (videoId != null && link != null) {
            startActivity(new Intent(this, MainMenuActivity.class));
            finish();
        } else {
            super.onBackPressed();
        }

    }


    private void callApiForSinglevideos(String videoId) {

        try {
            JSONObject parameters = new JSONObject();
            if (Functions.getSharedPreference(context).getString(Variables.U_ID, null) != null)
                parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, "0"));

            parameters.put("video_id", videoId);


            ApiRequest.callApi(this, ApiLinks.showVideoDetail, parameters, new Callback() {
                @Override
                public void onResponce(String resp) {

                    singalVideoParseData(resp);
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            Functions.printLog(Constants.tag, e.toString());
        }
    }


    public void singalVideoParseData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONObject msg = jsonObject.optJSONObject("msg");

                JSONObject video = msg.optJSONObject("Video");
                JSONObject user = msg.optJSONObject("User");
                JSONObject sound = msg.optJSONObject("Sound");
                JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                JSONObject pushNotification = user.optJSONObject("PushNotification");

                HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, pushNotification);


                Functions.printLog(Constants.tag,item.gif);

                if (dataList != null && !dataList.isEmpty()) {
                    dataList.remove(currentPage);
                    dataList.add(currentPage, item);
                    adapter.notifyDataSetChanged();
                } else {
                    dataList = new ArrayList<>();
                    dataList.add(item);
                    setAdapter();
                }

            } else {
                Functions.showToast(WatchVideos_F.this, jsonObject.optString("msg"));
            }

        } catch (JSONException e) {

            e.printStackTrace();
        }

    }


    public void setAdapter() {

        recyclerView = findViewById(R.id.recylerview);
        layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(false);

        SnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(recyclerView);


        adapter = new WatchVideosAdapter(context, dataList, new WatchVideosAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int postion, final HomeModel item, View v) {

                switch (v.getId()) {

                    case R.id.user_pic:
                        onPause();
                        openProfile(item, false);
                        break;

                    case R.id.promote_btn:
                        onPause();
                        openUrl(ApiLinks.Promote_Video + item.video_id, "Promote Video");
                        break;

                    case R.id.animate_rlt:
                        if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                                likeVideo(position,item);

                        } else {

                            Intent intent = new Intent(WatchVideos_F.this, Login_A.class);
                            startActivity(intent);
                            overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                        }
                        break;

                    case R.id.comment_layout:
                        openComment(item);
                        break;

                    case R.id.shared_layout:

                        final VideoAction_F fragment = new VideoAction_F(item.video_id, new FragmentCallBack() {
                            @Override
                            public void onResponce(Bundle bundle) {

                                if (bundle.getString("action").equals("save")) {

                                    if(Functions.checkStoragePermision(WatchVideos_F.this)) {
                                        saveVideo(item);
                                    }

                                } else if (bundle.getString("action").equals("duet")) {

                                    if(Functions.checkStoragePermision(WatchVideos_F.this)) {
                                        duetVideo(item);
                                    }

                                } else if (bundle.getString("action").equals("privacy")) {
                                    PrivacyVideoSetting_F privacy_video_settingF = new PrivacyVideoSetting_F(new FragmentCallBack() {
                                        @Override
                                        public void onResponce(Bundle bundle) {
                                            if (bundle != null) {
                                                if (bundle.getBoolean("call_api")) {
                                                    callApiForSinglevideos(bundle.getString("video_id"));
                                                }
                                            }
                                        }
                                    });
                                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                                    transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
                                    Bundle bundle1 = new Bundle();
                                    bundle1.putString("video_id", item.video_id);
                                    bundle1.putString("privacy_value", item.privacy_type);
                                    bundle1.putString("duet_value", item.allow_duet);
                                    bundle1.putString("comment_value", item.allow_comments);
                                    bundle1.putString("duet_video_id", item.duet_video_id);
                                    privacy_video_settingF.setArguments(bundle1);
                                    transaction.addToBackStack(null);
                                    transaction.replace(R.id.watchVideo_F, privacy_video_settingF).commit();
                                    onPause();
                                } else if (bundle.getString("action").equals("delete")) {

                                    Functions.showLoader(WatchVideos_F.this, false, false);
                                    Functions.callApiForDeleteVideo(WatchVideos_F.this, item.video_id, new APICallBack() {
                                        @Override
                                        public void arrayData(ArrayList arrayList) {

                                        }

                                        @Override
                                        public void onSuccess(String responce) {

                                            Functions.cancelLoader();
                                            finish();

                                        }

                                        @Override
                                        public void onFail(String responce) {

                                        }
                                    });

                                } else if (bundle.getString("action").equals("favourite")) {
                                    favouriteVideo(item);
                                } else if (bundle.getString("action").equals("not_intrested")) {
                                    notInterestVideo(item);
                                } else if (bundle.getString("action").equals("report")) {
                                    openVideoReport(item);
                                }


                            }
                        });

                        Bundle bundle = new Bundle();
                        bundle.putString("video_id", item.video_id);
                        bundle.putString("user_id", item.user_id);
                        bundle.putSerializable("data", item);

                        fragment.setArguments(bundle);

                        fragment.show(getSupportFragmentManager(), "");

                        break;


                    case R.id.sound_image_layout:

                        if (checkPermissions()) {
                            Intent intent = new Intent(WatchVideos_F.this, VideoSound_A.class);
                            intent.putExtra("data", item);
                            startActivity(intent);
                        }

                        break;

                    case R.id.duet_open_video:
                        openDuetVideo(item);
                        break;
                }

            }
        }, new WatchVideosAdapter.LikedClicked() {
            @Override
            public void like_clicked(View view, HomeModel item, int position) {
                if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                    view.animate().start();
                    likeVideo(position, item);
                } else {
                    view.animate().cancel();
                    Intent intent = new Intent(getApplicationContext(), Login_A.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                }
            }
        });

        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);


        // this is the scroll listener of recycler view which will tell the current item number
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                //here we find the current item number
                final int scrollOffset = recyclerView.computeVerticalScrollOffset();
                final int height = recyclerView.getHeight();
                int page_no = scrollOffset / height;

                if (page_no != currentPage) {
                    currentPage = page_no;

                    priviousPlayer();
                    setPlayer(currentPage);
                }

            }
        });


        recyclerView.scrollToPosition(position);


    }


    private void openDuetVideo(HomeModel item) {

        Intent intent123 = new Intent(this, WatchVideos_F.class);
        intent123.putExtra("video_id", item.duet_video_id);
        startActivity(intent123);
    }

    public void openUrl(String Link, String title) {
        Webview_F webview_f = new Webview_F();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        Bundle bundle = new Bundle();
        bundle.putString("url", Link);
        bundle.putString("title", title);
        webview_f.setArguments(bundle);
        transaction.addToBackStack(null);
        transaction.replace(R.id.watchVideo_F, webview_f).commit();
    }

    @Override
    public void onResume() {
        super.onResume();
        keyboardHeightProvider.setKeyboardHeightObserver(this);
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }


    int priviousHeight = 0;
    @Override
    public void onKeyboardHeightChanged(int height, int orientation) {

        Functions.printLog(Constants.tag, "" + height);
        if (height < 0) {
            priviousHeight = Math.abs(height);
            ;
        }

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(writeLayout.getWidth(), writeLayout.getHeight());
        params.bottomMargin = height + priviousHeight;
        writeLayout.setLayoutParams(params);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.send_btn:
                if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {

                    String comment_txt = messageEdit.getText().toString();
                    if (!TextUtils.isEmpty(comment_txt)) {
                        sendComments(dataList.get(currentPage).user_id, dataList.get(currentPage).video_id, comment_txt);
                    }

                } else {
                    Intent intent = new Intent(getApplicationContext(), Login_A.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                }
                break;
        }
    }


    @Override
    public void onDataSent(String yourData) {
        int comment_count = Functions.parseInterger(yourData);
        HomeModel item = dataList.get(currentPage);
        item.video_comment_count = "" + comment_count;
        dataList.add(currentPage, item);
        adapter.notifyDataSetChanged();
    }


    public void setPlayer(final int currentPage) {

        final HomeModel item = dataList.get(currentPage);

       callCache();

        Functions.printLog(Constants.tag, item.video_url);

        LoadControl loadControl = new DefaultLoadControl.Builder()
                .setAllocator(new DefaultAllocator(true, 16))
                .setBufferDurationsMs(1 * 1024, 1 * 1024, 500, 1024)
                .setTargetBufferBytes(-1)
                .setPrioritizeTimeOverSizeThresholds(true)
                .createDefaultLoadControl();

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(context);

        final SimpleExoPlayer player = new SimpleExoPlayer.Builder(context).
                setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .build();


        SimpleCache simpleCache = TicTic.simpleCache;
        CacheDataSourceFactory cacheDataSourceFactory = new CacheDataSourceFactory(simpleCache, new DefaultHttpDataSourceFactory(Util.getUserAgent(this, "BubbleTok"))
                , CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

        ProgressiveMediaSource videoSource = new ProgressiveMediaSource.Factory(cacheDataSourceFactory).createMediaSource(Uri.parse(item.video_url));


        player.prepare(videoSource);

        player.setRepeatMode(Player.REPEAT_MODE_ALL);
        player.addListener(this);


        View layout = layoutManager.findViewByPosition(currentPage);
        PlayerView playerView = layout.findViewById(R.id.playerview);
        playerView.setPlayer(player);


        player.setPlayWhenReady(true);
        privious_player = player;


        final RelativeLayout mainlayout = layout.findViewById(R.id.mainlayout);
        playerView.setOnTouchListener(new View.OnTouchListener() {
            private GestureDetector gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                    super.onFling(e1, e2, velocityX, velocityY);
                    float deltaX = e1.getX() - e2.getX();
                    float deltaXAbs = Math.abs(deltaX);
                    // Only when swipe distance between minimal and maximal distance value then we treat it as effective swipe
                    if ((deltaXAbs > 100) && (deltaXAbs < 1000)) {
                        if (deltaX > 0) {
                            openProfile(item, true);
                        }
                    }


                    return true;
                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    super.onSingleTapUp(e);
                    if (!player.getPlayWhenReady()) {
                        privious_player.setPlayWhenReady(true);
                    } else {
                        privious_player.setPlayWhenReady(false);
                    }


                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    super.onLongPress(e);
                    showVideoOption(item);

                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {


                    if (!player.getPlayWhenReady()) {
                        privious_player.setPlayWhenReady(true);
                    }

                    if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {

                        if (!animationRunning) {
                            if (handler != null && runnable != null) {
                                handler.removeCallbacks(runnable);

                            }
                            runnable = new Runnable() {
                                public void run() {
                                    showHeartOnDoubleTap(dataList.get(currentPage), mainlayout, e);
                                    likeVideo(currentPage, dataList.get(currentPage));
                                }
                            };
                            handler.postDelayed(runnable, 500);


                        }

                    } else {

                        Intent intent = new Intent(getApplicationContext(), Login_A.class);
                        startActivity(intent);
                        overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                    }
                    return super.onDoubleTap(e);

                }
            });

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                gestureDetector.onTouchEvent(event);
                return true;
            }
        });


        SocialTextView desc_txt = layout.findViewById(R.id.desc_txt);
        desc_txt.setOnHashtagClickListener(new SocialView.OnClickListener() {
            @Override
            public void onClick(@NonNull SocialView view, @NonNull CharSequence text) {
                openHashtag(text.toString());

            }
        });

        desc_txt.setOnMentionClickListener(new SocialView.OnClickListener() {
            @Override
            public void onClick(@NonNull SocialView view, @NonNull CharSequence text) {

                openProfileByUsername(text.toString());
                Functions.showToast(context, "" + text);
            }
        });


        LinearLayout soundimage = (LinearLayout) layout.findViewById(R.id.sound_image_layout);
        Animation aniRotate = AnimationUtils.loadAnimation(context, R.anim.d_clockwise_rotation);
        soundimage.startAnimation(aniRotate);

        if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false))
            Functions.callApiForUpdateView(WatchVideos_F.this, item.video_id);


        if (item.allow_comments != null && item.allow_comments.equalsIgnoreCase("false")) {
            writeLayout.setVisibility(View.INVISIBLE);
        } else {
            writeLayout.setVisibility(View.VISIBLE);
        }


        callApiForSinglevideos(item.video_id);
    }


    SimpleExoPlayer cache_player;

    public void callCache() {

        Functions.printLog(Constants.tag,"current page"+currentPage);
        Functions.printLog(Constants.tag,"dataList size"+ dataList.size());

        if ((currentPage + 1) < dataList.size()) {

            if (cache_player != null)
                cache_player.release();

            TicTic.getProxy(context);

            LoadControl loadControl = new DefaultLoadControl.Builder()
                    .setAllocator(new DefaultAllocator(true, 16))
                    .setBufferDurationsMs(1 * 1024, 1 * 1024, 500, 1024)
                    .setTargetBufferBytes(-1)
                    .setPrioritizeTimeOverSizeThresholds(true)
                    .createDefaultLoadControl();

            DefaultTrackSelector trackSelector = new DefaultTrackSelector(context);

            SimpleExoPlayer cache_player = new SimpleExoPlayer.Builder(context).
                    setTrackSelector(trackSelector)
                    .setLoadControl(loadControl)
                    .build();

            SimpleCache simpleCache = TicTic.simpleCache;
            CacheDataSourceFactory cacheDataSourceFactory = new CacheDataSourceFactory(simpleCache, new DefaultHttpDataSourceFactory(Util.getUserAgent(this, getString(R.string.app_name)))
                    , CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

            ProgressiveMediaSource videoSource = new ProgressiveMediaSource.Factory(cacheDataSourceFactory).createMediaSource(Uri.parse(dataList.get(currentPage + 1).video_url));

            cache_player.prepare(videoSource);

        }

    }

    // when we swipe for another video this will relaese the privious player
    SimpleExoPlayer privious_player;

    public void priviousPlayer() {
        if (privious_player != null) {
            privious_player.removeListener(this);
            privious_player.release();
        }
    }


    private void showVideoOption(final HomeModel item) {

        Functions.showVideoOption(context, item, new Callback() {
            @Override
            public void onResponce(String resp) {

                if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                    if (resp.equalsIgnoreCase("favourite")) {
                        favouriteVideo(item);
                    } else if (resp.equalsIgnoreCase("not_intrested")) {
                        notInterestVideo(item);
                    } else if (resp.equalsIgnoreCase("report")) {
                        openVideoReport(item);
                    }

                } else {

                    Intent intent = new Intent(getApplicationContext(), Login_A.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                }

            }
        });
    }


    public void favouriteVideo(final HomeModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", item.video_id);
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(this, ApiLinks.addVideoFavourite, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject jsonObject = new JSONObject(resp);

                    String code = jsonObject.optString("code");
                    if (code.equals("200")) {

                        if (item.favourite != null && item.favourite.equals("0"))
                            item.favourite = "1";
                        else
                            item.favourite = "0";

                        dataList.set(currentPage, item);
                        adapter.notifyDataSetChanged();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });


    }

    public void notInterestVideo(final HomeModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", item.video_id);
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }


        Functions.showLoader(context, false, false);
        ApiRequest.callApi(this, ApiLinks.notInterestedVideo, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject jsonObject = new JSONObject(resp);
                    String code = jsonObject.optString("code");
                    if (code.equals("200")) {
                        dataList.remove(item);
                        adapter.notifyDataSetChanged();
                        Functions.showToast(context, "Successfully added action!");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });


    }

    public void openVideoReport(HomeModel home_model) {
        ReportType_F reportType_f = new ReportType_F(false, null);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);

        Bundle bundle = new Bundle();
        bundle.putString("video_id", home_model.video_id);
        reportType_f.setArguments(bundle);

        transaction.addToBackStack(null);
        transaction.replace(R.id.watchVideo_F, reportType_f).commit();
        onPause();
    }


    public void showHeartOnDoubleTap(HomeModel item, final RelativeLayout mainlayout, MotionEvent e) {

        int x = (int) e.getX() - 100;
        int y = (int) e.getY() - 100;
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        final ImageView iv = new ImageView(getApplicationContext());
        lp.setMargins(x, y, 0, 0);
        iv.setLayoutParams(lp);
        if (item.liked.equals("1"))
            iv.setImageDrawable(getResources().getDrawable(
                    R.drawable.ic_like));
        else
            iv.setImageDrawable(getResources().getDrawable(
                    R.drawable.ic_like_fill));

        mainlayout.addView(iv);
        Animation fadeoutani = AnimationUtils.loadAnimation(context, R.anim.fade_out);

        fadeoutani.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // this will call when animation start
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mainlayout.removeView(iv);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // this will call when animation start again
            }
        });
        iv.startAnimation(fadeoutani);

    }

    // this function will call for like the video and Call an Api for like the video
    public void likeVideo(final int position, final HomeModel home_model) {

        String action = home_model.liked;

        if (action.equals("1")) {
            action = "0";
            home_model.like_count = "" + (Functions.parseInterger(home_model.like_count) - 1);
        } else {
            action = "1";
            home_model.like_count = "" + (Functions.parseInterger(home_model.like_count) + 1);
        }


        dataList.remove(position);
        home_model.liked = action;
        dataList.add(position, home_model);
        adapter.notifyDataSetChanged();


        Functions.callApiForLikeVideo(this, home_model.video_id, action, null);
    }


    public boolean checkPermissions() {

        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
        };

        if (!hasPermissions(context, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, 2);
        } else {

            return true;
        }

        return false;
    }


    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    // this will open the comment screen
    public void openComment(HomeModel item) {
        int comment_count = Functions.parseInterger(item.video_comment_count);
        FragmentDataSend fragment_data_send = this;

        Comment_F comment_f = new Comment_F(comment_count, fragment_data_send, "WatchVideos_F");
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("video_id", item.video_id);
        args.putString("user_id", item.user_id);
        args.putSerializable("data", item);
        comment_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.watchVideo_F, comment_f).commit();

    }


    // this will open the profile of user which have uploaded the currenlty running video
    private void openProfile(final HomeModel item, boolean from_right_to_left) {

        if (Functions.getSharedPreference(context).getString(Variables.U_ID, "0").equals(item.user_id)) {

            TabLayout.Tab profile = MainMenuFragment.tabLayout.getTabAt(4);
            profile.select();

        } else {

            Profile_F profile_f = new Profile_F(new FragmentCallBack() {
                @Override
                public void onResponce(Bundle bundle) {

                    callApiForSinglevideos(item.video_id);

                }
            });
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            if (from_right_to_left)
                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
            else
                transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);

            Bundle args = new Bundle();
            args.putString("user_id", item.user_id);
            args.putString("user_name", item.username);
            args.putString("user_pic", item.profile_pic);
            profile_f.setArguments(args);
            transaction.addToBackStack(null);
            transaction.replace(R.id.watchVideo_F, profile_f).commit();

        }


    }


    private void openProfileByUsername(String username) {

        if (Functions.getSharedPreference(context).getString(Variables.U_NAME, "0").equals(username)) {

            TabLayout.Tab profile = MainMenuFragment.tabLayout.getTabAt(4);
            profile.select();

        } else {

            Profile_F profile_f = new Profile_F();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
            Bundle args = new Bundle();
            args.putString("user_name", username);
            profile_f.setArguments(args);
            transaction.addToBackStack(null);
            transaction.replace(R.id.watchVideo_F, profile_f).commit();

        }


    }


    public void sendComments(final String user_id, String video_id, final String comment) {

        sendProgress.setVisibility(View.VISIBLE);
        sendBtn.setVisibility(View.GONE);

        Functions.callApiForSendComment(this, video_id, comment, new APICallBack() {
            @Override
            public void arrayData(ArrayList arrayList) {

                messageEdit.setText(null);
                sendProgress.setVisibility(View.GONE);
                sendBtn.setVisibility(View.VISIBLE);

                int comment_count = Functions.parseInterger(dataList.get(currentPage).video_comment_count);
                comment_count++;
                onDataSent("" + comment_count);


            }

            @Override
            public void onSuccess(String responce) {
                // this method will be call when data return in string form
            }

            @Override
            public void onFail(String responce) {
                // on faild api this will be call
            }
        });

    }


    public void duetVideo(final HomeModel item) {

        Functions.printLog(Constants.tag, item.video_url);
        if (item.video_url != null) {

            Functions.showDeterminentLoader(context, false, false);
            PRDownloader.initialize(getApplicationContext());
            DownloadRequest prDownloader = PRDownloader.download(item.video_url, Functions.getAppFolder(context), item.video_id + ".mp4")
                    .build()

                    .setOnProgressListener(new OnProgressListener() {
                        @Override
                        public void onProgress(Progress progress) {
                            int prog = (int) ((progress.currentBytes * 100) / progress.totalBytes);
                            Functions.showLoadingProgress(prog);

                        }
                    });


            prDownloader.start(new OnDownloadListener() {
                @Override
                public void onDownloadComplete() {
                    Functions.cancelDeterminentLoader();
                    openDuetRecording(item);
                }

                @Override
                public void onError(Error error) {
                    Functions.showToast(context, "Error");
                    Functions.cancelDeterminentLoader();
                }


            });

        }

    }

    public void openDuetRecording(HomeModel item) {
        Intent intent = new Intent(WatchVideos_F.this, Video_Recoder_Duet_A.class);
        intent.putExtra("data", item);
        startActivity(intent);
    }


    // this will open the profile of user which have uploaded the currenlty running video
    private void openHashtag(String tag) {

        TagedVideos_F taged_videos_f = new TagedVideos_F();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("tag", tag);
        taged_videos_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.watchVideo_F, taged_videos_f).commit();

    }


    public void saveVideo(final HomeModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", item.video_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(this, ApiLinks.downloadVideo, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject responce = new JSONObject(resp);
                    String code = responce.optString("code");
                    if (code.equals("200")) {
                        final String download_url = responce.optString("msg");

                        if (download_url != null) {

                            Functions.showDeterminentLoader(context, false, false);
                            PRDownloader.initialize(getApplicationContext());
                            DownloadRequest prDownloader = PRDownloader.download(Constants.BASE_URL + download_url, Functions.getAppFolder(context), item.video_id + ".mp4")
                                    .build()
                                    .setOnProgressListener(new OnProgressListener() {
                                        @Override
                                        public void onProgress(Progress progress) {

                                            int prog = (int) ((progress.currentBytes * 100) / progress.totalBytes);
                                            Functions.showLoadingProgress(prog);

                                        }
                                    });


                            prDownloader.start(new OnDownloadListener() {
                                @Override
                                public void onDownloadComplete() {
                                    Functions.cancelDeterminentLoader();
                                    deleteWaterMarkeVideo(download_url);
                                    scanFile(item);
                                }

                                @Override
                                public void onError(Error error) {
                                    Functions.showToast(context, "Error");
                                    Functions.cancelDeterminentLoader();
                                }


                            });

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });


    }


    public void deleteWaterMarkeVideo(String video_url) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_url", video_url);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(this, ApiLinks.deleteWaterMarkVideo, params, null);


    }


    public void scanFile(HomeModel item) {

        if (Build.VERSION.SDK_INT < 29) {

            try {
                Functions.copyFile(new File(Functions.getAppFolder(context) + item.video_id + ".mp4"),new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+item.video_id + ".mp4"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            MediaScannerConnection.scanFile(this,
                    new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+item.video_id + ".mp4"},
                    null,
                    new MediaScannerConnection.OnScanCompletedListener() {

                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });

        }
    }



    // this is lifecyle of the Activity which is importent for play,pause video or relaese the player
    @Override
    public void onPause() {
        super.onPause();

        if (privious_player != null) {
            privious_player.setPlayWhenReady(false);
        }

    }


    @Override
    public void onStop() {
        super.onStop();
        if (privious_player != null) {
            privious_player.setPlayWhenReady(false);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (privious_player != null) {
            privious_player.release();
        }
        keyboardHeightProvider.setKeyboardHeightObserver(null);
        keyboardHeightProvider.close();
    }


    // handle that call when the player state change
    @Override
    public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

        if (playbackState == Player.STATE_BUFFERING) {
            p_bar.setVisibility(View.VISIBLE);
        } else if (playbackState == Player.STATE_READY) {
            p_bar.setVisibility(View.GONE);
        }

    }


}
