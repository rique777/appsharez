package com.qboxus.musictok.ActivitesFragment;


import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.musictok.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class SeeFullImage_F extends Fragment {

    View view;
    Context context;
    ImageButton closeGallery;
    SimpleDraweeView singleImage;
    String imageUrl;
    int width, height;

    public SeeFullImage_F() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_see_full_image, container, false);
        context = getContext();

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        height = displayMetrics.heightPixels;
        width = displayMetrics.widthPixels;

        imageUrl = getArguments().getString("image_url");

        closeGallery = view.findViewById(R.id.close_gallery);
        closeGallery.setOnClickListener(v -> {
            getActivity().onBackPressed();

        });


        singleImage = view.findViewById(R.id.single_image);
        if (imageUrl != null && !imageUrl.equalsIgnoreCase("")) {
            Uri uri = Uri.parse(imageUrl);
            singleImage.setImageURI(uri);

        }


        return view;
    }


}


