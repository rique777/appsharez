package com.qboxus.musictok.ActivitesFragment;

import android.content.Context;
import android.os.Bundle;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ChangePassword_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;
    TextView oldPasswordEt, newPasswordEt, rePasswordEt;
    Button changePass;

    public ChangePassword_F() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_change_password, container, false);
        context = getContext();

        view.findViewById(R.id.goBack).setOnClickListener(this);
        view.findViewById(R.id.change_password_btn).setOnClickListener(this);

        oldPasswordEt = view.findViewById(R.id.old_password_et);
        newPasswordEt = view.findViewById(R.id.new_password_et);
        rePasswordEt = view.findViewById(R.id.re_password_et);
        changePass = view.findViewById(R.id.change_password_btn);

        rePasswordEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                String txtName = rePasswordEt.getText().toString();
                if (txtName.length() > 0) {
                    changePass.setEnabled(true);
                    changePass.setClickable(true);
                } else {
                    changePass.setEnabled(false);
                    changePass.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        return view;

    }

    // this will check the validations like none of the field can be the empty
    public boolean checkValidation() {

        String o_password = oldPasswordEt.getText().toString();
        String n_password = newPasswordEt.getText().toString();
        String v_password = rePasswordEt.getText().toString();

        if (o_password.isEmpty()) {
            Functions.showToast(getActivity(), "Please enter valid old password");
            return false;
        }

        if (o_password.length() <= 5 || o_password.length() >= 12) {
            Functions.showToast(getActivity(), "Password length should be between 5 to 12");
            return false;
        }


        if (TextUtils.isEmpty(n_password) || n_password.length() < 2 || n_password.length() > 12) {
            Functions.showToast(getActivity(), "Please enter valid new password");
            return false;
        }

        if (n_password.length() <= 5 || n_password.length() >= 12) {
            Functions.showToast(getActivity(), "Password length should be between 5 to 12");
            return false;
        }


        if (v_password.isEmpty()) {
            Functions.showToast(getActivity(), "Please enter valid verify password");
            return false;
        }
        if (!v_password.equals(n_password)) {
            Functions.showToast(getActivity(), "verify password doesnot match new password");
            return false;
        }

        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.goBack:
                getActivity().onBackPressed();
                break;


            case R.id.change_password_btn:
                if (checkValidation()) {
                    callApiForChangePass();
                }
                break;


        }
    }

    private void callApiForChangePass() {
        Functions.showLoader(getActivity(), false, false);

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, "0"));
            parameters.put("old_password", oldPasswordEt.getText().toString());
            parameters.put("new_password", newPasswordEt.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.changePassword, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    JSONArray msg = response.optJSONArray("msg");
                    if (code.equals("200")) {
                        Toast.makeText(getContext(), "Password Changed Successfully", Toast.LENGTH_SHORT).show();
                        getActivity().onBackPressed();
                    } else {
                        String msg_txt = response.getString("msg");
                        Functions.showToast(getActivity(), msg_txt);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}