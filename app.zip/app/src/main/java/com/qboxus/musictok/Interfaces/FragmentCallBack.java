package com.qboxus.musictok.Interfaces;

import android.os.Bundle;

/**
 * Created by qboxus on 4/4/2019.
 */

public interface FragmentCallBack {
    void onResponce(Bundle bundle);
}
