package com.qboxus.musictok.ActivitesFragment;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;

import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.Adapters.ViewPager2Adapter;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.Services.UploadService;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qboxus.musictok.MainMenu.MainMenuFragment;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

/**
 * A simple {@link Fragment} subclass.
 */

// this is the main view which is show all  the video in list
public class Home_F extends RootFragment implements View.OnClickListener, FragmentCallBack {

    View view;
    Context context;
    ArrayList<HomeModel> dataList;
    SwipeRefreshLayout swiperefresh;
    TextView followingBtn, relatedBtn, liveUsers;
    String type = "related";


    public Home_F() {

    }

    int page_count = 0;
    boolean isApiRuning = false;
    Handler handler;

    RelativeLayout uploadVideoLayout;
    ImageView uploadingThumb;
    ImageView uploadingIcon;
    UploadingVideoBroadCast mReceiver;

    @Override
    public void onResponce(Bundle bundle) {
        if (bundle != null && bundle.get("action").equals("showad")) {
            showCustomAd();
        } else if (bundle != null && bundle.get("action").equals("hidead")) {
            hideCustomad();
        }
    }

    private class UploadingVideoBroadCast extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            if (Functions.isMyServiceRunning(context, UploadService.class)) {
                uploadVideoLayout.setVisibility(View.VISIBLE);
                Bitmap bitmap = Functions.base64ToBitmap(Functions.getSharedPreference(context).getString(Variables.UPLOADING_VIDEO_THUMB, ""));
                if (bitmap != null)
                    uploadingThumb.setImageBitmap(bitmap);

            } else {
                uploadVideoLayout.setVisibility(View.GONE);
            }

        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        context = getContext();


        handler = new Handler();
        followingBtn = view.findViewById(R.id.following_btn);
        relatedBtn = view.findViewById(R.id.related_btn);

        followingBtn.setOnClickListener(this);
        relatedBtn.setOnClickListener(this);
        liveUsers = view.findViewById(R.id.live_users);
        liveUsers.setOnClickListener(this);


        swiperefresh = view.findViewById(R.id.swiperefresh);
        swiperefresh.setProgressViewOffset(false, 0, 200);

        swiperefresh.setColorSchemeResources(R.color.black);
        swiperefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                page_count = 0;
                dataList.clear();
                callVideoApi();
            }
        });


        if (!Constants.IS_REMOVE_ADS)
            loadAdd();

        uploadVideoLayout = view.findViewById(R.id.upload_video_layout);
        uploadingThumb = view.findViewById(R.id.uploading_thumb);
        uploadingIcon = view.findViewById(R.id.uploading_icon);

        mReceiver = new UploadingVideoBroadCast();
        getActivity().registerReceiver(mReceiver, new IntentFilter("uploadVideo"));


        if (Functions.isMyServiceRunning(context, UploadService.class)) {
            uploadVideoLayout.setVisibility(View.VISIBLE);
            Bitmap bitmap = Functions.base64ToBitmap(Functions.getSharedPreference(context).getString(Variables.UPLOADING_VIDEO_THUMB, ""));
            if (bitmap != null)
                uploadingThumb.setImageBitmap(bitmap);
        }


            setTabs();
            callApiForGetad();


        return view;
    }


    // set the fragments for all the videos list

    int swipeCount = 0;
    protected ViewPager2 menuPager;
    ViewPager2Adapter viewPager2Adapter;

    public void setTabs() {
        dataList = new ArrayList<>();

        viewPager2Adapter = new ViewPager2Adapter(this);
        menuPager = (ViewPager2) view.findViewById(R.id.viewpager);
        menuPager.setAdapter(viewPager2Adapter);
        menuPager.setOffscreenPageLimit(1);

        menuPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);

            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);

                if (position == 0 && (viewPager2Adapter!=null && viewPager2Adapter.getItemCount()>0)) {
                    VideosList_F fragment = (VideosList_F) viewPager2Adapter.getFragment(menuPager.getCurrentItem());
                    fragment.setData();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            fragment.setPlayer(is_visible_to_user);
                        }
                    }, 500);

                }



                if (dataList.size() > 2 && (dataList.size() - 1) == position) {
                    if(!isApiRuning) {
                        page_count++;
                        callVideoApi();
                    }
                }



                swipeCount++;
                if (swipeCount > Constants.SHOW_AD_ON_EVERY) {
                    swipeCount = 0;
                    showAdd();
                }


            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
            }

        });

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.following_btn:

                if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                    type = "following";
                    swiperefresh.setRefreshing(true);
                    relatedBtn.setTextColor(context.getResources().getColor(R.color.graycolor2));
                    followingBtn.setTextColor(context.getResources().getColor(R.color.white));
                    page_count = 0;
                    dataList.clear();
                    callVideoApi();
                }
                else {
                    openLogin();
                }
                break;

            case R.id.related_btn:
                type = "related";
                swiperefresh.setRefreshing(true);
                relatedBtn.setTextColor(context.getResources().getColor(R.color.white));
                followingBtn.setTextColor(context.getResources().getColor(R.color.graycolor2));
                page_count = 0;
                dataList.clear();
                callVideoApi();

                break;

            case R.id.live_users:
                onPause();

                Fragment f = new LiveUsers_F();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                transaction.addToBackStack(null);
                transaction.replace(R.id.mainMenuFragment, f).commit();
                break;

            default:
                return;
        }

    }

    @Override
    public void onPause() {
        super.onPause();

        if(viewPager2Adapter!=null && viewPager2Adapter.getItemCount()>0) {

            VideosList_F fragment = (VideosList_F) viewPager2Adapter.getFragment(menuPager.getCurrentItem());
            fragment.mainMenuVisibility(false);
        }

    }

    public void callVideoApi() {
        isApiRuning = true;

        if (type.equalsIgnoreCase("following")) {

            callApiForGetFollowingvideos();
        }
        else {

            callApiForGetAllvideos();
        }
    }

    private void callApiForGetad() {
        JSONObject parameters = new JSONObject();
        ApiRequest.callApi(getActivity(), ApiLinks.showVideoDetailAd, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                swiperefresh.setRefreshing(false);

                try {
                    JSONObject jsonObject=new JSONObject(resp);
                    String code=jsonObject.optString("code");

                    if(code!=null && code.equals("200")){
                        JSONObject msg=jsonObject.optJSONObject("msg");
                        JSONObject video=msg.optJSONObject("Video");
                        JSONObject user=msg.optJSONObject("User");
                        JSONObject sound = msg.optJSONObject("Sound");
                        JSONObject pushNotification=msg.optJSONObject("PushNotification");
                        JSONObject privacySetting=msg.optJSONObject("PrivacySetting");
                        HomeModel item = Functions.parseVideoData(user, sound, video, privacySetting, pushNotification);
                        item.promote="1";
                        dataList.add(0,item);

                        viewPager2Adapter.addFragment(new VideosList_F(item, Home_F.this::onResponce), "");
                        viewPager2Adapter.notifyDataSetChanged();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                callVideoApi();
            }
        });


    }


    // api for get the videos list from server
    private void callApiForGetAllvideos() {
        JSONObject parameters = new JSONObject();
        try {

            if (Functions.getSharedPreference(context).getString(Variables.U_ID, null) != null) {
                parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, "0"));
            }
            parameters.put("device_id", Functions.getSharedPreference(context).getString(Variables.DEVICE_ID, "0"));
            parameters.put("starting_point", "" + page_count);

        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showRelatedVideos, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                swiperefresh.setRefreshing(false);
                parseData(resp);
            }
        });


    }

    // call the api for get the api list of the follower user list
    private void callApiForGetFollowingvideos() {

        JSONObject parameters = new JSONObject();
        try {

            if (Functions.getSharedPreference(context).getString(Variables.U_ID, null) != null)
                parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, "0"));

            parameters.put("device_id", Functions.getSharedPreference(context).getString(Variables.DEVICE_ID, "0"));
            parameters.put("starting_point", "" + page_count);

        }

        catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showFollowingVideos, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                swiperefresh.setRefreshing(false);
                parseData(resp);
            }
        });


    }


    // parse the list of the videos
    public void parseData(String responce) {
        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");

            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");

                ArrayList<HomeModel> temp_list = new ArrayList();
                for (int i = 0; i < msgArray.length(); i++) {
                    JSONObject itemdata = msgArray.optJSONObject(i);

                    JSONObject video = itemdata.optJSONObject("Video");
                    JSONObject user = itemdata.optJSONObject("User");
                    JSONObject sound = itemdata.optJSONObject("Sound");
                    JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                    JSONObject pushNotification = user.optJSONObject("PushNotification");

                    HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, pushNotification);


                    if (Constants.IS_DEMO_APP) {
                        if (i < Constants.DEMO_APP_VIDEOS_COUNT)
                            temp_list.add(item);
                    }
                    else {
                        temp_list.add(item);
                    }


                }

                Collections.shuffle(temp_list);


                if(dataList.isEmpty()){
                    setTabs();
                }
                dataList.addAll(temp_list);

                for (HomeModel item : temp_list) {
                    viewPager2Adapter.addFragment(new VideosList_F(item, this::onResponce), "");
                }
                viewPager2Adapter.notifyDataSetChanged();


            } else {

                if (dataList.isEmpty() && type.equalsIgnoreCase("following")) {
                    Functions.showToast(getActivity(), "Follow an account to see there videos here.");
                    type = "related";
                    relatedBtn.setTextColor(context.getResources().getColor(R.color.white));
                    followingBtn.setTextColor(context.getResources().getColor(R.color.graycolor2));
                }
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }
        } catch (JSONException e) {
            e.printStackTrace();

            if(page_count>0)
                page_count--;

        } finally {
            isApiRuning = false;
        }

    }


    // opent the the login screen
    public void openLogin() {
        Intent intent = new Intent(getActivity(), Login_A.class);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
    }


    public void showCustomAd() {
        if(is_visible_to_user && (type!=null && type.equalsIgnoreCase("related"))) {

            view.findViewById(R.id.top_btn_layout).setVisibility(View.GONE);

            if (MainMenuFragment.tabLayout != null)
                MainMenuFragment.tabLayout.setVisibility(View.GONE);

        }
    }

    public void hideCustomad() {

        if (MainMenuFragment.tabLayout != null)
                MainMenuFragment.tabLayout.setVisibility(View.VISIBLE);

            view.findViewById(R.id.top_btn_layout).setVisibility(View.VISIBLE);


    }



    // loader the ad and make it ready for show when 4 videos watched
    InterstitialAd mInterstitialAd;
    public void loadAdd() {

        mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId(context.getResources().getString(R.string.my_Interstitial_Add));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        });


    }


    public void showAdd() {
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
    }



    // this will call when go to the home tab From other tab.
    // this is very importent when for video play and pause when the focus is changes
    boolean is_visible_to_user;
    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        is_visible_to_user = visible;

        if (viewPager2Adapter != null && viewPager2Adapter.getItemCount() > 0) {

            VideosList_F fragment = (VideosList_F) viewPager2Adapter.getFragment(menuPager.getCurrentItem());
            fragment.mainMenuVisibility(is_visible_to_user);

        }

    }


    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mReceiver != null) {
            getActivity().unregisterReceiver(mReceiver);
            mReceiver = null;
        }

    }


}
