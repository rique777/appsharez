package com.qboxus.musictok.ActivitesFragment.Search;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ProgressBar;

import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.qboxus.musictok.Adapters.HashTagAdapter;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.HashTagModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.qboxus.musictok.ActivitesFragment.TagedVideos_F;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.qboxus.musictok.ActivitesFragment.Search.SearchMain_F.searchEdit;

// search the hash tag
public class SearchHashTags_F extends RootFragment {

    View view;
    Context context;
    String type;
    ShimmerFrameLayout shimmerFrameLayout;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    ProgressBar loadMoreProgress;
    int pageCount = 0;
    boolean ispostFinsh;
    ArrayList<HashTagModel> dataList;
    HashTagAdapter adapter;


    public SearchHashTags_F(String type) {
        this.type = type;
    }

    public SearchHashTags_F() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_search, container, false);
        context = getContext();


        shimmerFrameLayout = view.findViewById(R.id.shimmer_view_container);
        shimmerFrameLayout.startShimmer();

        recyclerView = view.findViewById(R.id.recylerview);
        linearLayoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(linearLayoutManager);
        dataList = new ArrayList<>();
        adapter = new HashTagAdapter(context, dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {

                switch (view.getId()) {
                    case R.id.fav_btn:
                        callApiFavHashtag(pos, (HashTagModel) object);
                        break;
                    default:
                        HashTagModel item = (HashTagModel) object;
                        openHashtag(item.name);
                        break;
                }

            }
        });
        recyclerView.setAdapter(adapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            boolean userScrolled;
            int scrollOutitems;

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    userScrolled = true;
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                scrollOutitems = linearLayoutManager.findLastVisibleItemPosition();

                Functions.printLog("resp", "" + scrollOutitems);
                if (userScrolled && (scrollOutitems == dataList.size() - 1)) {
                    userScrolled = false;

                    if (loadMoreProgress.getVisibility() != View.VISIBLE && !ispostFinsh) {
                        loadMoreProgress.setVisibility(View.VISIBLE);
                        pageCount = pageCount + 1;

                        if (type != null && type.equalsIgnoreCase("hashtag"))
                            callApiSearch();
                    }
                }


            }
        });


        loadMoreProgress = view.findViewById(R.id.load_more_progress);
        pageCount = 0;


        if (type != null && type.equalsIgnoreCase("favourite")) {
            callApiGetFavourite();
        } else
            callApiSearch();


        return view;
    }

    // get the hashtage that a user search for
    public void callApiSearch() {

        JSONObject params = new JSONObject();
        try {
            if (Functions.getSharedPreference(context).getString(Variables.U_ID, null) != null) {
                params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, "0"));
            }

            params.put("type", type);
            params.put("keyword", searchEdit.getText().toString());
            params.put("starting_point", "" + pageCount);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.search, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                shimmerFrameLayout.stopShimmer();
                shimmerFrameLayout.setVisibility(View.GONE);

                parseData(resp);
            }
        });

    }


    // get the hash tag that a user is favourite it
    public void callApiGetFavourite() {

        JSONObject params = new JSONObject();
        try {
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, "0"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showFavouriteHashtags, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                shimmerFrameLayout.stopShimmer();
                shimmerFrameLayout.setVisibility(View.GONE);

                parseData(resp);
            }
        });

    }

    // parse the data of hashtag list
    public void parseData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {

                JSONArray msgArray = jsonObject.getJSONArray("msg");
                ArrayList<HashTagModel> temp_list = new ArrayList<>();
                for (int i = 0; i < msgArray.length(); i++) {
                    JSONObject itemdata = msgArray.optJSONObject(i);

                    JSONObject hashtag = itemdata.optJSONObject("Hashtag");

                    HashTagModel item = new HashTagModel();

                    item.id = hashtag.optString("id");
                    item.name = hashtag.optString("name");
                    item.views = hashtag.optString("views");
                    item.videos_count = hashtag.optString("videos_count");

                    item.fav = hashtag.optString("favourite", "1");
                    temp_list.add(item);

                }

                if (pageCount == 0) {
                    dataList.clear();
                }

                dataList.addAll(temp_list);
                adapter.notifyDataSetChanged();

                if (dataList.isEmpty()) {
                    view.findViewById(R.id.no_data_layout).setVisibility(View.VISIBLE);
                } else {
                    view.findViewById(R.id.no_data_layout).setVisibility(View.GONE);
                }

            } else {
                if (dataList.isEmpty())
                    view.findViewById(R.id.no_data_layout).setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {

            e.printStackTrace();
        } finally {
            loadMoreProgress.setVisibility(View.GONE);
        }
    }

    // open the video list against the hashtags
    private void openHashtag(String tag) {
        TagedVideos_F taged_videos_f = new TagedVideos_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("tag", tag);
        taged_videos_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.searchMain_F, taged_videos_f).commit();

    }

    // send the fav state into the server
    public void callApiFavHashtag(final int pos, final HashTagModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
            params.put("hashtag_id", item.id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.addHashtagFavourite, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                if (item.fav != null && item.fav.equalsIgnoreCase("0")) {
                    item.fav = "1";
                } else {
                    item.fav = "0";
                }

                dataList.remove(pos);
                dataList.add(pos, item);
                adapter.notifyDataSetChanged();

            }
        });

    }


}
