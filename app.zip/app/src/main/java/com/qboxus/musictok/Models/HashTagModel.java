package com.qboxus.musictok.Models;

public class HashTagModel {

    public String id, name, views, fav, videos_count;
}
