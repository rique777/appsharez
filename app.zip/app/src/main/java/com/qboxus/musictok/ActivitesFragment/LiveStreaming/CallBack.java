package com.qboxus.musictok.ActivitesFragment.LiveStreaming;

public interface CallBack {
    void getResponse(String requestType, String response);
}
