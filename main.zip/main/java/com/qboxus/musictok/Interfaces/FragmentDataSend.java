package com.qboxus.musictok.Interfaces;

public interface FragmentDataSend {

    void onDataSent(String yourData);
}
