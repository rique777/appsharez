package com.qboxus.musictok.Interfaces;

/**
 * Created by qboxus on 4/4/2019.
 */

public interface Callback {

    void onResponce(String resp);
}
