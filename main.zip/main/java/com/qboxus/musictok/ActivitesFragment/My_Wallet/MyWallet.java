package com.qboxus.musictok.ActivitesFragment.My_Wallet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.anjlab.android.iab.v3.BillingProcessor;
import com.anjlab.android.iab.v3.TransactionDetails;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class MyWallet extends AppCompatActivity implements BillingProcessor.IBillingHandler,View.OnClickListener {

    RecyclerView recyclerView;
    MyWalletAdapter adapter ;
    ArrayList<WalletModel> datalist = new ArrayList<>();
    TextView coins_txt;

    WalletModel selectWalletModel;

    BillingProcessor bp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_wallet);

        coins_txt=findViewById(R.id.coins_txt);

        findViewById(R.id.back_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



        findViewById(R.id.tab_cashout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(MyWallet.this, Withdraw_Coins_A.class),200);
            }
        });

        initlizeBilling();
        initViews();
    }


    @Override
    protected void onResume() {
        super.onResume();
        setUpScreenData();
    }

    private void setUpScreenData() {
        coins_txt.setText(""+Functions.getSharedPreference(MyWallet.this).getString(Variables.U_WALLET, "0"));
    }


    public void initlizeBilling(){
        bp = new BillingProcessor(this, Constants.licencekey, this);
        bp.initialize();
    }


    @Override
    public void onProductPurchased(@NonNull String productId, @Nullable TransactionDetails details) {


     String purchaseToken= details.purchaseInfo.purchaseData.purchaseToken;
     Log.d(Constants.tag,purchaseToken);
     callApiUpdateWallet(selectWalletModel.coins+" coins", selectWalletModel.coins, selectWalletModel.price,purchaseToken);


    }


    @Override
    public void onPurchaseHistoryRestored() {

    }

    @Override
    public void onBillingError(int errorCode, @Nullable Throwable error) {

    }

    @Override
    public void onBillingInitialized() {

        Log.d(Constants.tag,"onBillingInitialized");
        if(bp.loadOwnedPurchasesFromGoogle()){
            Log.d(Constants.tag,"loadOwnedPurchasesFromGoogle");
            bp.consumePurchase(Constants.Product_ID1);
            bp.consumePurchase(Constants.Product_ID2);
            bp.consumePurchase(Constants.Product_ID3);
            bp.consumePurchase(Constants.Product_ID4);
            bp.consumePurchase(Constants.Product_ID5);
        }


    }

    // when we click the continue btn this method will call
    public void puchaseItem(int postion, WalletModel wallet_model) {
        this.selectWalletModel =wallet_model;
        boolean isAvailable = BillingProcessor.isIabServiceAvailable(this);
        if(isAvailable) {

            switch (postion){
                case 0:
                    bp.purchase(this, Constants.Product_ID1);
                    break;

                case 1:
                    bp.purchase(this, Constants.Product_ID2);
                    break;

                case 2:
                    bp.purchase(this, Constants.Product_ID3);
                    break;

                case 3:
                    bp.purchase(this, Constants.Product_ID4);
                    break;

                case 4:
                    bp.purchase(this, Constants.Product_ID5);
                    break;
            }

        }
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(Constants.tag, "onActivity Result Code : " + resultCode+"--"+requestCode);
        if(resultCode==RESULT_OK){
            if(requestCode==200){
                setUpScreenData();
            }
        }

        if (!bp.handleActivityResult(requestCode, resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }

    }


    @Override
    public void onClick(View v) {

    }



    @Override
    public void onDestroy() {
        if (bp != null) {
            bp.release();
        }
        super.onDestroy();
    }


    private void initViews() {

        recyclerView = findViewById(R.id.recylerview);

        datalist.add(new WalletModel("",Constants.COINS1,Constants.PRICE1));
        datalist.add(new WalletModel("",Constants.COINS2,Constants.PRICE2));
        datalist.add(new WalletModel("",Constants.COINS3,Constants.PRICE3));
        datalist.add(new WalletModel("",Constants.COINS4,Constants.PRICE4));
        datalist.add(new WalletModel("",Constants.COINS5,Constants.PRICE5));

        adapter = new MyWalletAdapter(this, datalist, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                WalletModel wallet_model=(WalletModel) object;
                puchaseItem(pos,wallet_model);
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }






    public void callApiUpdateWallet(String name, String coins, String price, String Tid){

        JSONObject params=new JSONObject();
        try {
            params.put("user_id",Variables.sharedPreferences.getString(Variables.U_ID,""));
            params.put("coin",coins);
            params.put("title",name);
            params.put("price",price);
            params.put("transaction_id",Tid);
            params.put("device","android");
        } catch (JSONException e) {
            e.printStackTrace();
        }


        Functions.showLoader(this,false,false);
        ApiRequest.callApi(this, ApiLinks.purchaseCoin, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject jsonObject=new JSONObject(resp);

                    String code=jsonObject.optString("code");
                    if(code!=null && code.equals("200")){
                        JSONObject msgObj=jsonObject.getJSONObject("msg");
                        JSONObject userdata = msgObj.getJSONObject("User");
                        SharedPreferences.Editor editor = Functions.getSharedPreference(MyWallet.this).edit();
                        editor.putString(Variables.U_WALLET, userdata.optString("wallet","0"));
                        editor.commit();
                        setUpScreenData();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });
    }


}
