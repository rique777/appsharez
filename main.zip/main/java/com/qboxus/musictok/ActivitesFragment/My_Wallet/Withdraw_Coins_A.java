package com.qboxus.musictok.ActivitesFragment.My_Wallet;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;

import com.qboxus.musictok.ActivitesFragment.LiveStreaming.CallBack;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.function.Function;


public class Withdraw_Coins_A extends AppCompatActivity {


    TextView coins_txt,coins_txt2,amount_txt,checkout_btn;

    double total_coins=0f,total_amount=0f,unit_amount=0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw_coins);

        coins_txt=findViewById(R.id.coins_txt);
        coins_txt2=findViewById(R.id.coins_txt2);

        amount_txt=findViewById(R.id.amount_txt);

        checkout_btn=findViewById(R.id.checkout_btn);

        findViewById(R.id.back_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_OK, new Intent());
                finish();
            }
        });

        checkout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (total_amount >= 1)
                    Call_api_cash_out();
                else
                    Toast.makeText(Withdraw_Coins_A.this, "You don't have sufficient Coins", Toast.LENGTH_SHORT).show();

            }
        });

        String wallet =""+Functions.getSharedPreference(Withdraw_Coins_A.this).getString(Variables.U_WALLET, "0");
        coins_txt.setText(wallet);
        coins_txt2.setText(wallet);
        total_coins=Double.parseDouble(wallet);

        Call_api_get_coins_value();



    }




    public void Call_api_get_coins_value(){

        JSONObject params=new JSONObject();
        ApiRequest.callApi(this, ApiLinks.showCoinWorth, params, new Callback() {
            @Override
            public void onResponce(String resp) {

                try {
                    JSONObject jsonObject=new JSONObject(resp);
                    String code=jsonObject.optString("code");
                    if(code.equals("200")){


                        JSONObject msgObj=jsonObject.optJSONObject("msg");
                        JSONObject object=msgObj.optJSONObject("CoinWorth");

                        String amount=object.optString("price");


                        unit_amount=Double.parseDouble(amount);

                        total_amount=(total_coins*unit_amount);

                        if(total_amount>=1)
                            checkout_btn.setBackgroundTintList(ContextCompat.getColorStateList(Withdraw_Coins_A.this, R.color.blue));

                        amount_txt.setText("$"+total_amount);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });
    }



    public void Call_api_cash_out(){

        JSONObject params=new JSONObject();
        try {
            params.put("user_id",Variables.sharedPreferences.getString(Variables.U_ID,""));
//            params.put("coins",""+total_coins);
            params.put("amount",""+total_amount);
//            params.put("paypal_id",payment_edit.getText().toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(this,false,false);
        ApiRequest.callApi(this, ApiLinks.withdrawRequest, params, new Callback() {
            @Override
            public void onResponce(String resp) {

                Functions.cancelLoader();
                try {
                    JSONObject jsonObject=new JSONObject(resp);
                    String code=jsonObject.optString("code");
                    if(code.equals("200")){
                        Toast.makeText(Withdraw_Coins_A.this, "Check out Successfully", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK, new Intent());
                        finish();
                    }
                    else
                    if(code.equals("201") && (!jsonObject.optString("msg").equalsIgnoreCase("You have already requested a payout.")))
                    {
                        Functions.showAlert(Withdraw_Coins_A.this, "Alert", "For payout you must need to add paypal id", new CallBack() {
                            @Override
                            public void getResponse(String requestType, String response) {
                                AddPayoutMethod f = new AddPayoutMethod(new FragmentCallBack() {
                                    @Override
                                    public void onResponce(Bundle bundle) {
                                        if (bundle.getBoolean("isShow",false))
                                        {
                                            Call_api_cash_out();
                                        }
                                    }
                                });
                                Bundle bundle = new Bundle();
                                bundle.putString("email","");
                                bundle.putBoolean("isEdit",false);
                                f.setArguments(bundle);
                                FragmentTransaction transaction =getSupportFragmentManager().beginTransaction();
                                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                                transaction.addToBackStack(null);
                                transaction.replace(R.id.withdraw_container_id, f).commit();
                            }
                        });
                    }

                }
                catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }



    @Override
    public void onBackPressed() {
        setResult(RESULT_OK, new Intent());
        super.onBackPressed();
    }
}
