package com.qboxus.musictok.ActivitesFragment.Search;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.qboxus.musictok.Adapters.RecentSearchAdapter;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Adapters.ViewPagerAdapter;
import com.google.android.material.tabs.TabLayout;
import com.qboxus.musictok.SimpleClasses.Functions;

import net.yslibrary.android.keyboardvisibilityevent.util.UIUtil;

import java.util.ArrayList;

import io.paperdb.Paper;

/**
 * A simple {@link Fragment} subclass.
 */
public class SearchMain_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;

    public static EditText searchEdit;
    TextView search_btn;

    public SearchMain_F() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_search_main, container, false);
        context = getContext();

        searchEdit = view.findViewById(R.id.search_edit);

        search_btn = view.findViewById(R.id.search_btn);
        search_btn.setOnClickListener(this::onClick);


        showRecentSearch();

        searchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (searchEdit.getText().toString().length() > 0) {
                    search_btn.setVisibility(View.VISIBLE);

                } else {
                    search_btn.setVisibility(View.GONE);
                }

                showRecentSearch();

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        searchEdit.setFocusable(true);
        UIUtil.showKeyboard(context, searchEdit);


        searchEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    performSearch();

                    view.findViewById(R.id.recent_layout).setVisibility(View.GONE);
                    addSearchKey(searchEdit.getText().toString());

                    return true;
                }
                return false;
            }
        });


        view.findViewById(R.id.clear_all_txt).setOnClickListener(this::onClick);

        return view;
    }


    public void performSearch() {
        if (menuPager != null) {
            menuPager.removeAllViews();
        }
        setTabs();
    }


    protected TabLayout tabLayout;
    protected ViewPager menuPager;
    ViewPagerAdapter adapter;

    public void setTabs() {

        adapter = new ViewPagerAdapter(getChildFragmentManager());
        menuPager = (ViewPager) view.findViewById(R.id.viewpager);
        menuPager.setOffscreenPageLimit(3);
        tabLayout = (TabLayout) view.findViewById(R.id.tabs);

        adapter.addFrag(new SearchUser_F("user"), "Users");
        adapter.addFrag(new SearchVideo_F("video"), "Videos");
        adapter.addFrag(new SearchSound_F("sound"), "Sounds");
        adapter.addFrag(new SearchHashTags_F("hashtag"), "HashTags");

        menuPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(menuPager);

    }


    public void addSearchKey(String search_key) {
        ArrayList<String> search_list = (ArrayList<String>) Paper.book().read("recent_search", new ArrayList<String>());
        search_list.add(search_key);
        Paper.book().write("recent_search", search_list);

    }


    // this method will get the recent searched list from local db

    RecyclerView recyclerView;
    RecentSearchAdapter recentsearchAdapter;
    ArrayList<String> searchQueryList = new ArrayList<>();

    public void showRecentSearch() {
        ArrayList<String> search_list = (ArrayList<String>) Paper.book().read("recent_search", new ArrayList<String>());

        searchQueryList.clear();
        searchQueryList.addAll(search_list);

        if (searchQueryList.isEmpty()) {
            view.findViewById(R.id.recent_layout).setVisibility(View.GONE);
            return;
        } else {
            view.findViewById(R.id.recent_layout).setVisibility(View.VISIBLE);
        }

        if (recentsearchAdapter != null) {
            recentsearchAdapter.getFilter().filter(searchEdit.getText().toString());
            recentsearchAdapter.notifyDataSetChanged();
            return;
        }

        view.findViewById(R.id.recent_layout).setVisibility(View.VISIBLE);
        recentsearchAdapter = new RecentSearchAdapter(context, searchQueryList, new AdapterClickListener() {
            @Override
            public void onItemClick(View v, int pos, Object object) {

                if (v.getId() == R.id.delete_btn) {
                    searchQueryList.remove(object);
                    recentsearchAdapter.notifyDataSetChanged();

                    search_list.remove(object);
                    Paper.book().write("recent_search", search_list);
                } else {

                    String search = (String) object;
                    searchEdit.setText(search);
                    performSearch();
                    view.findViewById(R.id.recent_layout).setVisibility(View.GONE);
                }

            }
        });
        recyclerView = view.findViewById(R.id.recylerview);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(recentsearchAdapter);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.search_btn:
                Functions.hideSoftKeyboard(getActivity());
                performSearch();
                view.findViewById(R.id.recent_layout).setVisibility(View.GONE);
                addSearchKey(searchEdit.getText().toString());
                break;

            case R.id.clear_all_txt:
                Paper.book().delete("recent_search");
                showRecentSearch();
                break;


        }
    }


}
