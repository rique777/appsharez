package com.qboxus.musictok.ActivitesFragment;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.PushNotificationSettingModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;

import io.paperdb.Paper;

public class PushNotificationSetting_F extends RootFragment implements View.OnClickListener {


    View view;
    LinearLayout linearLayout;
    ImageView imgBack;
    Switch stLikes, stComment, stNewFollow, stMention, stDirectMessage, stVideoUpdate;
    String strLikes = "1", strComment = "1", strNewFollow = "1", strMention = "1", strDirectMessage = "1", str_video_update = "1";

    PushNotificationSettingModel pushNotificationSettingModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_push_notification_setting, container, false);
        initControl();
        return view;
    }


    private void initControl() {
        pushNotificationSettingModel = (PushNotificationSettingModel) Paper.book("Setting").read("PushSettingModel");
        linearLayout = view.findViewById(R.id.clickLess);
        linearLayout.setOnClickListener(this);
        imgBack = view.findViewById(R.id.Push_Notification_Setting_F_img_back);
        imgBack.setOnClickListener(this);
        stLikes = view.findViewById(R.id.Push_Notification_Setting_F_st_likes);
        stLikes.setOnClickListener(this);
        stComment = view.findViewById(R.id.Push_Notification_Setting_F_st_comments);
        stComment.setOnClickListener(this);
        stNewFollow = view.findViewById(R.id.Push_Notification_Setting_F_st_new_follower);
        stNewFollow.setOnClickListener(this);
        stMention = view.findViewById(R.id.Push_Notification_Setting_F_st_mention);
        stMention.setOnClickListener(this);
        stDirectMessage = view.findViewById(R.id.Push_Notification_Setting_F_st_direct_message);
        stDirectMessage.setOnClickListener(this);
        stVideoUpdate = view.findViewById(R.id.Push_Notification_Setting_F_st_video_update);
        stVideoUpdate.setOnClickListener(this);

        setUpScreenData();

    }


    private void setUpScreenData() {
        try {
            strLikes = pushNotificationSettingModel.getLikes();
            stLikes.setChecked(getTrueFalseCondition(strLikes));

            str_video_update = pushNotificationSettingModel.getVideoupdates();
            stVideoUpdate.setChecked(getTrueFalseCondition(str_video_update));

            strDirectMessage = pushNotificationSettingModel.getDirectmessage();
            stDirectMessage.setChecked(getTrueFalseCondition(strDirectMessage));

            strMention = pushNotificationSettingModel.getMentions();
            stMention.setChecked(getTrueFalseCondition(strMention));

            strNewFollow = pushNotificationSettingModel.getNewfollowers();
            stNewFollow.setChecked(getTrueFalseCondition(strNewFollow));

            strComment = pushNotificationSettingModel.getComments();
            stComment.setChecked(getTrueFalseCondition(strComment));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }


    private boolean getTrueFalseCondition(String str) {
        if (str.equalsIgnoreCase("1"))
            return true;
        else
            return false;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.Push_Notification_Setting_F_img_back:
                getActivity().onBackPressed();
                break;
            case R.id.clickLess:
                break;
            case R.id.Push_Notification_Setting_F_st_likes:
                if (stLikes.isChecked()) {
                    strLikes = "1";
                } else {
                    strLikes = "0";
                }
                callApi();
                break;
            case R.id.Push_Notification_Setting_F_st_comments:
                if (stComment.isChecked()) {
                    strComment = "1";
                } else {
                    strComment = "0";
                }
                callApi();
                break;
            case R.id.Push_Notification_Setting_F_st_new_follower:
                if (stNewFollow.isChecked()) {
                    strNewFollow = "1";
                } else {
                    strNewFollow = "0";
                }
                callApi();
                break;
            case R.id.Push_Notification_Setting_F_st_mention:
                if (stMention.isChecked()) {
                    strMention = "1";
                } else {
                    strMention = "0";
                }
                callApi();
                break;
            case R.id.Push_Notification_Setting_F_st_direct_message:
                if (stDirectMessage.isChecked()) {
                    strDirectMessage = "1";
                } else {
                    strDirectMessage = "0";
                }
                callApi();
                break;
            case R.id.Push_Notification_Setting_F_st_video_update:
                if (stVideoUpdate.isChecked()) {
                    str_video_update = "1";
                } else {
                    str_video_update = "0";
                }
                callApi();
                break;
        }
    }


    // call the api for update the pushnotification settings

    public void callApi() {

        JSONObject params = new JSONObject();
        try {
            params.put("likes", strLikes);
            params.put("comments", strComment);
            params.put("new_followers", strNewFollow);
            params.put("mentions", strMention);
            params.put("video_updates", str_video_update);
            params.put("direct_messages", strDirectMessage);
            params.put("user_id", Functions.getSharedPreference(getContext()).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.updatePushNotificationSetting, params, new Callback() {
            @Override
            public void onResponce(String resp) {

                parsedata(resp);


            }
        });

    }


    // set the already selected pushnotification ui
    public void parsedata(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");

            if (code.equals("200")) {

                JSONObject msg = jsonObject.optJSONObject("msg");
                JSONObject push_notification_setting = msg.optJSONObject("PushNotification");
                pushNotificationSettingModel = new PushNotificationSettingModel();
                pushNotificationSettingModel.setComments("" + push_notification_setting.optString("comments"));
                pushNotificationSettingModel.setLikes("" + push_notification_setting.optString("likes"));
                pushNotificationSettingModel.setNewfollowers("" + push_notification_setting.optString("new_followers"));
                pushNotificationSettingModel.setMentions("" + push_notification_setting.optString("mentions"));
                pushNotificationSettingModel.setDirectmessage("" + push_notification_setting.optString("direct_messages"));
                pushNotificationSettingModel.setVideoupdates("" + push_notification_setting.optString("video_updates"));
                Paper.book("Setting").write("PushSettingModel", pushNotificationSettingModel);

                Functions.showToast(view.getContext(), "Setting Update");
            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}