package com.qboxus.musictok.ActivitesFragment;


import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.Adapters.FollowingShareAdapter;
import com.qboxus.musictok.Adapters.VideoSharingAppsAdapter;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Models.FollowingModel;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.FragmentCallBack;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */

public class VideoAction_F extends BottomSheetDialogFragment implements View.OnClickListener {

    View view;
    Context context;
    RecyclerView recyclerView, recylerviewFollowing;

    FragmentCallBack fragmentCallback;

    String videoId, userId;
    ProgressBar progressBar;
    HomeModel item;

    TextView bottomBtn;

    public VideoAction_F() {
    }

    @SuppressLint("ValidFragment")
    public VideoAction_F(String id, FragmentCallBack fragmentCallback) {
        videoId = id;
        this.fragmentCallback = fragmentCallback;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.fragment_video_action, container, false);
        context = getContext();


        Bundle bundle = getArguments();
        if (bundle != null) {
            item = (HomeModel) bundle.getSerializable("data");
            videoId = bundle.getString("video_id");
            userId = bundle.getString("user_id");
        }

        progressBar = view.findViewById(R.id.progress_bar);

        view.findViewById(R.id.copy_layout).setOnClickListener(this);
        view.findViewById(R.id.delete_layout).setOnClickListener(this);
        view.findViewById(R.id.privacy_setting_layout).setOnClickListener(this);

        if (userId != null && userId.equals(Functions.getSharedPreference(context).getString(Variables.U_ID, ""))) {
            view.findViewById(R.id.delete_layout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.privacy_setting_layout).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.delete_layout).setVisibility(View.GONE);
            view.findViewById(R.id.privacy_setting_layout).setVisibility(View.GONE);
        }

        if (isShowVideoDownloadPrivacy(item)) {

            view.findViewById(R.id.save_video_layout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.save_video_layout).setOnClickListener(this::onClick);
        } else
            view.findViewById(R.id.save_video_layout).setVisibility(View.GONE);


        if (Constants.IS_SECURE_INFO) {
            progressBar.setVisibility(View.GONE);
            view.findViewById(R.id.copy_layout).setVisibility(View.GONE);
        } else {

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    getSharedApp();

                }
            }, 1000);

        }


        if (Functions.getSharedPreference(context).getBoolean(Variables.IsExtended,false) && (item.allow_duet != null && item.allow_duet.equalsIgnoreCase("1"))
                && Functions.isShowContentPrivacy(context, item.apply_privacy_model.getDuet(), item.follow_status_button.equalsIgnoreCase("friends"))) {
            view.findViewById(R.id.duet_layout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.duet_layout).setOnClickListener(this::onClick);
        } else {
            view.findViewById(R.id.duet_layout).setVisibility(View.GONE);
        }


        view.findViewById(R.id.add_favourite_layout).setOnClickListener(this::onClick);
        view.findViewById(R.id.not_intrested_layout).setOnClickListener(this::onClick);
        view.findViewById(R.id.report_layout).setOnClickListener(this::onClick);
        if (userId != null && userId.equals(Functions.getSharedPreference(context).getString(Variables.U_ID, ""))) {
            view.findViewById(R.id.not_intrested_layout).setVisibility(View.GONE);
            view.findViewById(R.id.report_layout).setVisibility(View.GONE);
        }



        bottomBtn =view.findViewById(R.id.bottom_btn);
        bottomBtn.setOnClickListener(this::onClick);

        if(Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN,false)) {
            setFollowingAdapter();
            callApiForGetAllfollowing();
        }


        return view;
    }

    private boolean isShowVideoDownloadPrivacy(HomeModel home_item) {
        if (home_item.apply_privacy_model.getVideos_download() != null && home_item.apply_privacy_model.getVideos_download().equalsIgnoreCase("0"))
            return false;
        else
            return true;
    }






    ArrayList<FollowingModel> followingModels;
    FollowingShareAdapter followingShareAdapter;
    public void setFollowingAdapter(){
        followingModels=new ArrayList<>();
        recylerviewFollowing =view.findViewById(R.id.recylerview_following);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
        recylerviewFollowing.setLayoutManager(layoutManager);
        recylerviewFollowing.setHasFixedSize(false);

        followingShareAdapter=new FollowingShareAdapter(context, followingModels, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                clickedUsers(pos);
            }
        });
        recylerviewFollowing.setAdapter(followingShareAdapter);
    }

    private void callApiForGetAllfollowing() {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }


        ApiRequest.callApi(getActivity(), ApiLinks.showFollowing, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                parseFollowingData(resp);
            }
        });


    }

    public void parseFollowingData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");
                for (int i = 0; i < msgArray.length(); i++) {

                    JSONObject object = msgArray.optJSONObject(i);
                    JSONObject FollowingList = object.optJSONObject("FollowingList");


                    FollowingModel item = new FollowingModel();
                    item.fb_id = FollowingList.optString("id");
                    item.bio = FollowingList.optString("bio");
                    item.username = FollowingList.optString("username");

                    item.profile_pic = FollowingList.optString("profile_pic", "");
                    if (!item.profile_pic.contains(Variables.http)) {
                        item.profile_pic = Constants.BASE_URL + item.profile_pic;
                    }


                    item.follow_status_button = FollowingList.optString("button");


                    followingModels.add(item);
                }

                followingShareAdapter.notifyDataSetChanged();
                view.findViewById(R.id.sendTo_txt).setVisibility(View.VISIBLE);
                view.findViewById(R.id.recylerview_following).setVisibility(View.VISIBLE);

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    FollowingModel selected_user;
    public void clickedUsers(int postion){

        for (int i=0;i<followingModels.size();i++){
            if(i!=postion){
                FollowingModel followingModel=followingModels.get(i);
                followingModel.is_select=false;
                followingModels.remove(i);
                followingModels.add(i,followingModel);
            }
        }

        selected_user=followingModels.get(postion);
        if(selected_user.is_select){
            selected_user.is_select=false;
            bottomBtn.setBackgroundColor(context.getResources().getColor(R.color.white));
            bottomBtn.setTextColor(context.getResources().getColor(R.color.dimgray));
            bottomBtn.setText("Cancel");

        }
        else {
            selected_user.is_select=true;
            bottomBtn.setBackgroundColor(context.getResources().getColor(R.color.colorAccent));
            bottomBtn.setTextColor(context.getResources().getColor(R.color.white));
            bottomBtn.setText("Send");
        }
        followingModels.remove(postion);
        followingModels.add(postion,selected_user);
        followingShareAdapter.notifyDataSetChanged();

    }


    // this method will upload the image in chhat
    public void sendvideo() {

        Functions.showLoader(context,false,false);

        DatabaseReference rootref= FirebaseDatabase.getInstance().getReference();
        String senderId=Functions.getSharedPreference(context).getString(Variables.U_ID,"0");

        Date c = Calendar.getInstance().getTime();
        final String formattedDate = Variables.df.format(c);


        DatabaseReference dref = rootref.child("chat").child(senderId + "-" + selected_user.fb_id).push();
        final String key = dref.getKey();

        String current_user_ref = "chat" + "/" + senderId + "-" + selected_user.fb_id;
        String chat_user_ref = "chat" + "/" + selected_user.fb_id + "-" + senderId;

        HashMap message_user_map = new HashMap<>();
        message_user_map.put("receiver_id", selected_user.fb_id);
        message_user_map.put("sender_id", senderId);
        message_user_map.put("chat_id", key);
        message_user_map.put("text", "");
        message_user_map.put("type", "video");
        message_user_map.put("pic_url", item.thum);
        message_user_map.put("video_id", item.video_id);
        message_user_map.put("status", "0");
        message_user_map.put("time", "");
        message_user_map.put("sender_name", Functions.getSharedPreference(context).getString(Variables.U_NAME, ""));
        message_user_map.put("timestamp", formattedDate);
        HashMap user_map = new HashMap<>();

        user_map.put(current_user_ref + "/" + key, message_user_map);
        user_map.put(chat_user_ref + "/" + key, message_user_map);

        rootref.updateChildren(user_map, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                String inbox_sender_ref = "Inbox" + "/" + senderId + "/" + selected_user.fb_id;
                String inbox_receiver_ref = "Inbox" + "/" + selected_user.fb_id + "/" + senderId;


                HashMap sendermap = new HashMap<>();
                sendermap.put("rid", senderId);
                sendermap.put("name", Functions.getSharedPreference(context).getString(Variables.U_NAME, ""));
                sendermap.put("pic", Functions.getSharedPreference(context).getString(Variables.U_PIC, ""));
                sendermap.put("msg", "Send an video...");
                sendermap.put("status", "0");
                sendermap.put("timestamp", -1 * System.currentTimeMillis());
                sendermap.put("date", formattedDate);

                HashMap receivermap = new HashMap<>();
                receivermap.put("rid", selected_user.fb_id);
                receivermap.put("name", selected_user.username);
                receivermap.put("pic", selected_user.profile_pic);
                receivermap.put("msg", "Send an video...");
                receivermap.put("status", "1");
                receivermap.put("timestamp", -1 * System.currentTimeMillis());
                receivermap.put("date", formattedDate);

                HashMap both_user_map = new HashMap<>();
                both_user_map.put(inbox_sender_ref, receivermap);
                both_user_map.put(inbox_receiver_ref, sendermap);

                rootref.updateChildren(both_user_map).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        Functions.cancelLoader();

                        Toast.makeText(context, "Video send to "+item.username, Toast.LENGTH_SHORT).show();
                        dismiss();


                    }
                });

            }
        });
    }











    // show the list of apps that can be used for share the video link to its friends
    VideoSharingAppsAdapter adapter;

    public void getSharedApp() {
        recyclerView = (RecyclerView) view.findViewById(R.id.recylerview);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(false);

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {

                    PackageManager pm = getActivity().getPackageManager();
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TEXT, "https://google.com");

                    List<ResolveInfo> launchables = pm.queryIntentActivities(intent, 0);

                    for (int i = 0; i < launchables.size(); i++) {

                        if (launchables.get(i).activityInfo.name.contains("SendTextToClipboardActivity")) {
                            launchables.remove(i);
                            break;
                        }

                    }

                    Collections.sort(launchables,
                            new ResolveInfo.DisplayNameComparator(pm));

                    adapter = new VideoSharingAppsAdapter(context, launchables, new VideoSharingAppsAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(int positon, ResolveInfo item, View view) {
                            openApp(item);
                        }
                    });


                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            recyclerView.setAdapter(adapter);
                            progressBar.setVisibility(View.GONE);
                        }
                    });


                } catch (Exception e) {

                }
            }
        }).start();


    }

    public void openApp(ResolveInfo resolveInfo) {
        try {

            ActivityInfo activity = resolveInfo.activityInfo;
            ComponentName name = new ComponentName(activity.applicationInfo.packageName,
                    activity.name);
            Intent i = new Intent(Intent.ACTION_MAIN);

            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            i.setComponent(name);

            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT,
                    Constants.BASE_URL + "?" + Functions.getRandomString(3) + videoId + Functions.getRandomString(3));
            intent.setComponent(name);
            startActivity(intent);
        } catch (Exception e) {

        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.save_video_layout:

                if (Functions.checkStoragePermision(getActivity())) {

                    Bundle bundle = new Bundle();
                    bundle.putString("action", "save");
                    dismiss();

                    if (fragmentCallback != null)
                        fragmentCallback.onResponce(bundle);
                }

                break;


            case R.id.duet_layout:
                if (!Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                    openLogin();
                } else if (Functions.checkPermissions(getActivity())) {

                    Bundle duet_bundle = new Bundle();
                    duet_bundle.putString("action", "duet");
                    dismiss();

                    if (fragmentCallback != null)
                        fragmentCallback.onResponce(duet_bundle);

                }

                break;

            case R.id.copy_layout:
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Copied Text", Constants.BASE_URL + "?" + Functions.getRandomString(3) + videoId + Functions.getRandomString(3));
                clipboard.setPrimaryClip(clip);

                Functions.showToast(getContext(), "Link Copy in clipboard");
                break;

            case R.id.delete_layout:
                if (Constants.IS_SECURE_INFO) {
                    Functions.showToast(context, getString(R.string.delete_function_not_available_in_demo));
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", "delete");
                    dismiss();

                    if (fragmentCallback != null)
                        fragmentCallback.onResponce(bundle);
                }
                break;


            case R.id.privacy_setting_layout:
                if (Constants.IS_SECURE_INFO) {
                    Functions.showToast(context, getString(R.string.privacy_function_not_available_in_demo));
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("action", "privacy");
                    dismiss();

                    if (fragmentCallback != null)
                        fragmentCallback.onResponce(bundle);
                }
                break;

            case R.id.add_favourite_layout:
                Bundle bundle = new Bundle();
                bundle.putString("action", "favourite");
                dismiss();

                if (fragmentCallback != null)
                    fragmentCallback.onResponce(bundle);

                break;

            case R.id.not_intrested_layout:
                Bundle not_interested_bundle = new Bundle();
                not_interested_bundle.putString("action", "not_intrested");
                dismiss();

                if (fragmentCallback != null)
                    fragmentCallback.onResponce(not_interested_bundle);
                break;

            case R.id.report_layout:
                Bundle report_bundle = new Bundle();
                report_bundle.putString("action", "report");
                dismiss();

                if (fragmentCallback != null)
                    fragmentCallback.onResponce(report_bundle);
                break;


            case R.id.bottom_btn:
                if(selected_user!=null &&selected_user.is_select){
                    sendvideo();
                }
                else {
                    dismiss();
                }

                break;

        }


    }

    public void openLogin() {
        Intent intent = new Intent(getActivity(), Login_A.class);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
    }

}
