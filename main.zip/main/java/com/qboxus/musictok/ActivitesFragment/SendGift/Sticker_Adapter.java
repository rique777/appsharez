package com.qboxus.musictok.ActivitesFragment.SendGift;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import java.util.ArrayList;
import java.util.List;


public class Sticker_Adapter extends RecyclerView.Adapter<Sticker_Adapter.CustomViewHolder >{

    public Context context;
    List<Sticker_model> gif_list = new ArrayList<>();
    private Sticker_Adapter.OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Sticker_model item);
    }

    public Sticker_Adapter(Context context, List<Sticker_model> gif_list, Sticker_Adapter.OnItemClickListener listener) {
        this.context = context;
        this.gif_list = gif_list;
        this.listener = listener;

    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewtype) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_send_gif_layout,null);
        return  new CustomViewHolder(view);
    }

    @Override
    public int getItemCount() {
       return gif_list.size();
    }


    class CustomViewHolder extends RecyclerView.ViewHolder {
        SimpleDraweeView gif_image;
        TextView name_txt,coins_txt;
        ImageView ivSelect;

        public CustomViewHolder(View view) {
            super(view);
            gif_image=view.findViewById(R.id.gif_image);
            name_txt=view.findViewById(R.id.name_txt);
            coins_txt=view.findViewById(R.id.coin_txt);
            ivSelect=view.findViewById(R.id.ivSelect);
        }

        public void bind(final Sticker_model item, final Sticker_Adapter.OnItemClickListener listener) {

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(item);
                }
            });

        }

    }


    @Override
    public void onBindViewHolder(final Sticker_Adapter.CustomViewHolder holder, final int i) {
        Sticker_model model = gif_list.get(i);

        if (model.image != null && !model.image.equals("")) {
            if (!model.image.contains(Variables.http)) {
                model.image = Constants.BASE_URL + model.image;
            }
            Functions.printLog(Constants.tag, model.image);
            Uri uri = Uri.parse(model.image);
            holder.gif_image.setImageURI(uri);
        }
        holder.name_txt.setText(model.name);
        holder.coins_txt.setText(model.coins+" Coins");
        if (model.isSelected)
        {
            holder.ivSelect.setVisibility(View.VISIBLE);
        }
        else
        {
            holder.ivSelect.setVisibility(View.GONE);
        }

        holder.bind(model,listener);
   }

}