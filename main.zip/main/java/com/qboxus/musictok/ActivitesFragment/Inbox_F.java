package com.qboxus.musictok.ActivitesFragment;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.qboxus.musictok.Adapters.InboxAdapter;
import com.qboxus.musictok.ActivitesFragment.Chat.ChatActivity;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.InboxModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

/**
 * A simple {@link Fragment} subclass.
 */
public class Inbox_F extends RootFragment {


    View view;
    Context context;

    RecyclerView inboxList;

    ArrayList<InboxModel> inboxArraylist;
    DatabaseReference rootRef;
    InboxAdapter inboxAdapter;
    ProgressBar pbar;

    boolean isviewCreated = false;

    public Inbox_F() {

    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_inbox, container, false);
        context = getContext();

        rootRef = FirebaseDatabase.getInstance().getReference();


        pbar = view.findViewById(R.id.pbar);
        inboxList = view.findViewById(R.id.inboxlist);

        // intialize the arraylist and and inboxlist
        inboxArraylist = new ArrayList<>();

        inboxList = (RecyclerView) view.findViewById(R.id.inboxlist);
        LinearLayoutManager layout = new LinearLayoutManager(context);
        inboxList.setLayoutManager(layout);
        inboxList.setHasFixedSize(false);
        inboxAdapter = new InboxAdapter(context, inboxArraylist, new InboxAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(InboxModel item) {

                // if user allow the stroage permission then we open the chat view
                if (checkReadStoragepermission())
                    chatFragment(item.getId(), item.getName(), item.getPic());


            }
        }, new InboxAdapter.OnLongItemClickListener() {
            @Override
            public void onLongItemClick(InboxModel item) {

            }
        });

        inboxList.setAdapter(inboxAdapter);


        view.setOnClickListener(v -> {
            Functions.hideSoftKeyboard(getActivity());


        });

        view.findViewById(R.id.back_btn).setOnClickListener(v -> {
            getActivity().onBackPressed();


        });


        isviewCreated = true;

        getData();

        return view;
    }


    // show the banner ad at the bottom of the screen
    AdView adView;

    @Override
    public void onStart() {
        super.onStart();
        adView = view.findViewById(R.id.bannerad);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }


    // on start we will get the Inbox Message of user  which is show in bottom list of third tab
    ValueEventListener eventListener2;
    Query inboxQuery;

    public void getData() {

        pbar.setVisibility(View.VISIBLE);

        inboxQuery = rootRef.child("Inbox").child(Functions.getSharedPreference(getContext()).getString(Variables.U_ID, "0")).orderByChild("date");
        eventListener2 = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                inboxArraylist.clear();
                pbar.setVisibility(View.GONE);
                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    InboxModel model = ds.getValue(InboxModel.class);
                    model.setId(ds.getKey());

                    inboxArraylist.add(model);
                }


                if (inboxArraylist.isEmpty()) {
                    Functions.showToast(context, "no data");
                    view.findViewById(R.id.no_data_layout).setVisibility(View.VISIBLE);
                } else {
                    Functions.showToast(context, "no data");
                    view.findViewById(R.id.no_data_layout).setVisibility(View.GONE);
                    Collections.reverse(inboxArraylist);
                    inboxAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                pbar.setVisibility(View.GONE);
                view.findViewById(R.id.no_data_layout).setVisibility(View.VISIBLE);
            }
        };

        inboxQuery.addValueEventListener(eventListener2);


    }


    // on stop we will remove the listener
    @Override
    public void onStop() {
        super.onStop();
        if (inboxQuery != null)
            inboxQuery.removeEventListener(eventListener2);
    }


    //open the chat fragment and on item click and pass your id and the other person id in which
    //you want to chat with them and this parameter is that is we move from match list or inbox list
    public void chatFragment(String receiverid, String name, String picture) {
        ChatActivity chat_activity = new ChatActivity(new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {

            }
        });
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);

        Bundle args = new Bundle();
        args.putString("user_id", receiverid);
        args.putString("user_name", name);
        args.putString("user_pic", picture);

        chat_activity.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.inbox_F, chat_activity).commit();
    }


    //this method will check there is a storage permission given or not
    private boolean checkReadStoragepermission() {
        if (ContextCompat.checkSelfPermission(getActivity().getApplicationContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            try {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        Variables.PERMISSION_READ_DATA);
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            }
        }
        return false;
    }


}
