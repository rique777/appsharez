package com.qboxus.musictok.ActivitesFragment;


import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Adapters.MyVideosAdapter;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TagedVideos_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;

    NestedScrollView scrollView;
    RelativeLayout recylerviewMainLayout;

    RelativeLayout topLayout;

    RecyclerView recyclerView;
    ArrayList<HomeModel> dataList;
    MyVideosAdapter adapter;

    String tagId, tagTxt, favourite = "0";

    TextView tagTxtView, tagTitleTxt, videoCountTxt;
    ProgressBar progressBar;

    TextView favTxt;
    ImageView favBtn;

    public TagedVideos_F() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_taged_videos, container, false);
        context = getContext();


        Bundle bundle = getArguments();
        if (bundle != null) {
            tagTxt = bundle.getString("tag");
        }


        tagTxtView = view.findViewById(R.id.tag_txt_view);
        tagTitleTxt = view.findViewById(R.id.tag_title_txt);

        tagTxtView.setText(tagTxt);
        tagTitleTxt.setText(tagTxt);

        videoCountTxt = view.findViewById(R.id.video_count_txt);

        favBtn = view.findViewById(R.id.fav_btn);
        favTxt = view.findViewById(R.id.fav_txt);
        view.findViewById(R.id.fav_layout).setOnClickListener(this::onClick);

        recyclerView = view.findViewById(R.id.recylerview);
        scrollView = view.findViewById(R.id.scrollview);


        topLayout = view.findViewById(R.id.top_layout);
        recylerviewMainLayout = view.findViewById(R.id.recylerview_main_layout);


        ViewTreeObserver observer = topLayout.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {

                final int height = topLayout.getMeasuredHeight();

                topLayout.getViewTreeObserver().removeOnGlobalLayoutListener(
                        this);

                ViewTreeObserver observer = recylerviewMainLayout.getViewTreeObserver();
                observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @Override
                    public void onGlobalLayout() {

                        // TODO Auto-generated method stub
                        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) recylerviewMainLayout.getLayoutParams();
                        params.height = (int) (recylerviewMainLayout.getMeasuredHeight() + height);
                        recylerviewMainLayout.setLayoutParams(params);
                        recylerviewMainLayout.getViewTreeObserver().removeOnGlobalLayoutListener(
                                this);

                    }
                });

            }
        });


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            scrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                    if (!scrollView.canScrollVertically(1)) {
                        recyclerView.setNestedScrollingEnabled(true);


                    } else {
                        recyclerView.setNestedScrollingEnabled(false);
                    }

                }
            });
        }


        recyclerView = view.findViewById(R.id.recylerview);
        final GridLayoutManager layoutManager = new GridLayoutManager(context, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            recyclerView.setNestedScrollingEnabled(false);
        } else {
            recyclerView.setNestedScrollingEnabled(true);
        }

        dataList = new ArrayList<>();
        adapter = new MyVideosAdapter(context, dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                openWatchVideo(pos);
            }
        });

        recyclerView.setAdapter(adapter);


        progressBar = view.findViewById(R.id.progress_bar);

        view.findViewById(R.id.back_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        callApiForGetAllvideos();


        return view;
    }


    //this will get the all videos data of user and then parse the data
    private void callApiForGetAllvideos() {
        progressBar.setVisibility(View.VISIBLE);
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
            parameters.put("hashtag", tagTxt);


        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showVideosAgainstHashtag, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                progressBar.setVisibility(View.GONE);
                parseData(resp);
            }
        });


    }

    // parse the data of video list
    public void parseData(String responce) {

        dataList.clear();

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");


                for (int i = 0; i < msgArray.length(); i++) {
                    JSONObject itemdata = msgArray.optJSONObject(i);

                    JSONObject hashtag = itemdata.optJSONObject("Hashtag");
                    tagId = hashtag.optString("id");
                    favourite = hashtag.optString("favourite");


                    JSONObject video = itemdata.optJSONObject("Video");
                    JSONObject user = video.optJSONObject("User");
                    JSONObject sound = video.optJSONObject("Sound");
                    JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                    JSONObject userPushNotification = user.optJSONObject("PushNotification");

                    HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, userPushNotification);

                    dataList.add(item);
                }


                if (favourite != null && favourite.equalsIgnoreCase("1")) {
                    favBtn.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_fav_fill));
                    favTxt.setText("Remove Favorite");
                } else {
                    favBtn.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_fav));
                    favTxt.setText("Add to Favorites");
                }

                videoCountTxt.setText(jsonObject.optString("videos_count") + " Videos");

                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

            } else {
                progressBar.setVisibility(View.GONE);
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            progressBar.setVisibility(View.GONE);
            e.printStackTrace();
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        Functions.deleteCache(context);
    }

    private void openWatchVideo(int postion) {
        Intent intent = new Intent(getActivity(), WatchVideos_F.class);
        intent.putExtra("arraylist", dataList);
        intent.putExtra("position", postion);
        startActivity(intent);
    }


    public void callApiFavHashtag() {

        JSONObject params = new JSONObject();
        try {
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
            params.put("hashtag_id", tagId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.addHashtagFavourite, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();


                if (favourite != null && favourite.equalsIgnoreCase("0")) {
                    favourite = "1";
                    favBtn.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_fav_fill));
                    favTxt.setText("Remove Favorite");
                } else {
                    favourite = "0";
                    favBtn.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_fav));
                    favTxt.setText("Add to Favorites");
                }


            }
        });

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.fav_layout:
                callApiFavHashtag();
                break;
        }

    }
}
