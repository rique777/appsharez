package com.qboxus.musictok.ActivitesFragment;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.OnProgressListener;
import com.downloader.PRDownloader;
import com.downloader.Progress;
import com.downloader.request.DownloadRequest;
import com.facebook.drawee.view.SimpleDraweeView;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultAllocator;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.CacheDataSource;
import com.google.android.exoplayer2.upstream.cache.CacheDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.tabs.TabLayout;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.ActivitesFragment.Profile.Profile_F;
import com.qboxus.musictok.ActivitesFragment.SoundLists.VideoSound_A;
import com.qboxus.musictok.ActivitesFragment.VideoRecording.Video_Recoder_Duet_A;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.APICallBack;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.Interfaces.FragmentDataSend;
import com.qboxus.musictok.MainMenu.MainMenuFragment;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.TicTic;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.volokh.danylo.hashtaghelper.HashTagHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Function;

import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * A simple {@link Fragment} subclass.
 */

// this is the main view which is show all  the video in list
public class VideosList_F extends RootFragment implements Player.EventListener, View.OnClickListener, FragmentDataSend {

    View view;
    Context context;


    HomeModel item;
    FragmentCallBack fragmentCallBack;

    public VideosList_F(HomeModel item, FragmentCallBack fragmentCallBack) {
        this.item = item;
        this.fragmentCallBack = fragmentCallBack;
    }


    public VideosList_F() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.item_home_layout, container, false);
        context = getContext();


        initializePlayer();
        initalize_views();

        return view;
    }


    TextView username, descTxt, soundName, skipBtn;
    SimpleDraweeView userPic, soundImage,thumb_image;
    ImageView varifiedBtn;
    RelativeLayout duetLayoutUsername, animateRlt, mainlayout;
    LinearLayout duetOpenVideo;
    LinearLayout likeLayout, commentLayout, sharedLayout, soundImageLayout;
    LikeButton likeImage;
    ImageView commentImage;
    TextView likeTxt, commentTxt, duetUsername;
    PlayerView playerView;

    Handler handler;
    Runnable runnable;
    Boolean animationRunning = false;

    ProgressBar pbar;

    public void initalize_views() {

        mainlayout = view.findViewById(R.id.mainlayout);

        duetLayoutUsername = view.findViewById(R.id.duet_layout_username);
        duetUsername = view.findViewById(R.id.duet_username);
        duetOpenVideo = view.findViewById(R.id.duet_open_video);
        username = view.findViewById(R.id.username);
        userPic = view.findViewById(R.id.user_pic);
        thumb_image=view.findViewById(R.id.thumb_image);
        soundName = view.findViewById(R.id.sound_name);
        soundImage = view.findViewById(R.id.sound_image);
        varifiedBtn = view.findViewById(R.id.varified_btn);
        likeLayout = view.findViewById(R.id.like_layout);
        likeImage = view.findViewById(R.id.likebtn);
        likeTxt = view.findViewById(R.id.like_txt);
        animateRlt = view.findViewById(R.id.animate_rlt);

        skipBtn = view.findViewById(R.id.skip_btn);

        descTxt = view.findViewById(R.id.desc_txt);

        commentLayout = view.findViewById(R.id.comment_layout);
        commentImage = view.findViewById(R.id.comment_image);
        commentTxt = view.findViewById(R.id.comment_txt);


        soundImageLayout = view.findViewById(R.id.sound_image_layout);
        sharedLayout = view.findViewById(R.id.shared_layout);

        pbar = view.findViewById(R.id.p_bar);

        duetOpenVideo.setOnClickListener(this::onClick);
        userPic.setOnClickListener(this::onClick);
        animateRlt.setOnClickListener(this::onClick);
        username.setOnClickListener(this::onClick);
        commentLayout.setOnClickListener(this::onClick);
        sharedLayout.setOnClickListener(this::onClick);
        soundImageLayout.setOnClickListener(this::onClick);

        likeImage.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                likeVideo(item);
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                likeVideo(item);
            }
        });

        skipBtn.setOnClickListener(this::onClick);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                setData();
            }
        },200);



        if ((item!=null && item.thum != null) && !item.thum.equals("")) {
            Uri uri = Uri.parse(item.thum);
            thumb_image.setImageURI(uri);
        }

    }

    public void setData() {

        if(view==null && item!=null)
            return;
        else {


            username.setText(Functions.showUsername(""+item.username));
            if (item.profile_pic != null && !item.profile_pic.equals("")) {
                Uri uri = Uri.parse(item.profile_pic);
                userPic.setImageURI(uri);
            }


            if ((item.sound_name == null || item.sound_name.equals("") || item.sound_name.equals("null"))) {
                soundName.setText("original sound - " + item.username);
                item.sound_pic = item.profile_pic;
            }
            else {
                soundName.setText(item.sound_name);
            }
            soundName.setSelected(true);


            if (item.sound_pic != null && !item.sound_pic.equals("")) {
                Uri uri = Uri.parse(item.sound_pic);
                soundImage.setImageURI(uri);
            }


            descTxt.setText(item.video_description);
            HashTagHelper.Creator.create(context.getResources().getColor(R.color.maincolor), new HashTagHelper.OnHashTagClickListener() {
                @Override
                public void onHashTagClicked(String hashTag) {
                    onPause();
                    openHashtag(hashTag);

                }
            }).handle(descTxt);


            setLikeData();

            if (item.allow_comments != null && item.allow_comments.equalsIgnoreCase("false")) {
                commentLayout.setVisibility(View.GONE);
            } else {
                commentLayout.setVisibility(View.VISIBLE);
            }
            commentTxt.setText(Functions.getSuffix(item.video_comment_count));


            if (item.verified != null && item.verified.equalsIgnoreCase("1")) {
                varifiedBtn.setVisibility(View.VISIBLE);
            } else {
                varifiedBtn.setVisibility(View.GONE);
            }


            if (item.duet_video_id != null && !item.duet_video_id.equals("") && !item.duet_video_id.equals("0")) {
                duetLayoutUsername.setVisibility(View.VISIBLE);
                duetUsername.setText(item.duet_username);
            }


            Animation aniRotate = AnimationUtils.loadAnimation(context, R.anim.d_clockwise_rotation);
            soundImageLayout.startAnimation(aniRotate);


            if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                animateRlt.setVisibility(View.GONE);
            }

            Functions.printLog(Constants.tag, "SetData" + item.video_id);
        }
    }

    public void setLikeData() {
        if (item.liked.equals("1")) {
            likeImage.animate().start();
            likeImage.setLikeDrawable(context.getResources().getDrawable(R.drawable.ic_heart_gradient));
            likeImage.setLiked(true);
        } else {
            likeImage.setLikeDrawable(context.getResources().getDrawable(R.drawable.ic_unliked));
            likeImage.setLiked(false);
            likeImage.animate().cancel();
        }

        likeTxt.setText(Functions.getSuffix(item.like_count));

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.user_pic:
                onPause();
                openProfile(item, false);
                break;

            case R.id.username:
                onPause();
                openProfile(item, false);
                break;

            case R.id.comment_layout:
                openComment(item);
                break;

            case R.id.animate_rlt:
                if(Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN,false)){
                    animateRlt.setVisibility(View.GONE);
                    likeVideo(item);
                }
                else
                openLogin();
                break;

            case R.id.shared_layout:

                final VideoAction_F fragment = new VideoAction_F(item.video_id, new FragmentCallBack() {
                    @Override
                    public void onResponce(Bundle bundle) {

                        if (bundle.getString("action").equals("save")) {
                            saveVideo(item);
                        } else if (bundle.getString("action").equals("duet")) {

                            duetVideo(item);
                        } else if (bundle.getString("action").equals("privacy")) {

                            PrivacyVideoSetting_F privacy_video_settingF = new PrivacyVideoSetting_F(new FragmentCallBack() {
                                @Override
                                public void onResponce(Bundle bundle) {
                                    if (bundle != null) {
                                        if (bundle.getBoolean("call_api")) {
                                            callApiForSinglevideos();
                                        }
                                    }
                                }
                            });
                            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                            transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("video_id", item.video_id);
                            bundle1.putString("privacy_value", item.privacy_type);
                            bundle1.putString("duet_value", item.allow_duet);
                            bundle1.putString("comment_value", item.allow_comments);
                            bundle1.putString("duet_video_id", item.duet_video_id);
                            privacy_video_settingF.setArguments(bundle1);
                            transaction.addToBackStack(null);
                            transaction.replace(R.id.watchVideo_F, privacy_video_settingF).commit();

                            onPause();

                        } else if (bundle.getString("action").equals("delete")) {
                            Functions.showLoader(context, false, false);
                            Functions.callApiForDeleteVideo(getActivity(), item.video_id, new APICallBack() {
                                @Override
                                public void arrayData(ArrayList arrayList) {
                                    //return data in case of array list
                                }

                                @Override
                                public void onSuccess(String responce) {

                                }

                                @Override
                                public void onFail(String responce) {
                                }
                            });

                        } else if (bundle.getString("action").equals("favourite")) {
                            favouriteVideo(item);
                        } else if (bundle.getString("action").equals("not_intrested")) {
                            notInterestVideo(item);
                        } else if (bundle.getString("action").equals("report")) {
                            openVideoReport(item);
                        }


                    }
                });

                Bundle bundle = new Bundle();
                bundle.putString("video_id", item.video_id);
                bundle.putString("user_id", item.user_id);
                bundle.putSerializable("data", item);
                fragment.setArguments(bundle);
                fragment.show(getChildFragmentManager(), "");


                break;


            case R.id.sound_image_layout:

                if (checkPermissions()) {

                    Intent intent = new Intent(getActivity(), VideoSound_A.class);
                    intent.putExtra("data", item);
                    startActivity(intent);
                }

                break;

            case R.id.duet_open_video:
                openDuetVideo(item);
                break;

            case R.id.skip_btn:
                hideAd();
                break;
        }

    }

    // initlize the player for play video
    private void initializePlayer() {
        if(exoplayer==null) {

            new AsyncTask<Object, Object, Object>() {
                @Override
                protected void onPreExecute() {
                    super.onPreExecute();

                }

                @Override
                protected Object doInBackground(Object[] objects) {

                    try {

                        TicTic.getProxy(context);


                        LoadControl loadControl = new DefaultLoadControl.Builder()
                                .setAllocator(new DefaultAllocator(true, 16))
                                .setBufferDurationsMs(1 * 1024, 1 * 1024, 500, 1024)
                                .setTargetBufferBytes(-1)
                                .setPrioritizeTimeOverSizeThresholds(true)
                                .createDefaultLoadControl();

                        DefaultTrackSelector trackSelector = new DefaultTrackSelector(context);

                        exoplayer = new SimpleExoPlayer.Builder(context).
                                setTrackSelector(trackSelector)
                                .setLoadControl(loadControl)
                                .build();

                        SimpleCache simpleCache = TicTic.simpleCache;
                        CacheDataSourceFactory cacheDataSourceFactory = new CacheDataSourceFactory(simpleCache, new DefaultHttpDataSourceFactory(Util.getUserAgent(getActivity(), context.getString(R.string.app_name)))
                                , CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

                        ProgressiveMediaSource videoSource = new ProgressiveMediaSource.Factory(cacheDataSourceFactory).createMediaSource(Uri.parse(item.video_url));

                        exoplayer.prepare(videoSource);

                        exoplayer.setRepeatMode(Player.REPEAT_MODE_ALL);
                        exoplayer.addListener(VideosList_F.this);


                    } catch (Exception e) {

                    }

                    return null;
                }

                @Override
                protected void onPostExecute(Object o) {
                    super.onPostExecute(o);


                }
            }.execute();
        }
    }


    public void setPlayer(boolean isVisibleToUser) {
        Functions.printLog(Constants.tag,"setPlayer"+item.video_id);

        if (exoplayer != null) {

            playerView = view.findViewById(R.id.playerview);
            playerView.setPlayer(exoplayer);

            playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH);

            exoplayer.setPlayWhenReady(isVisibleToUser);

            playerView.setOnTouchListener(new View.OnTouchListener() {
                private GestureDetector gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                        super.onFling(e1, e2, velocityX, velocityY);
                        float deltaX = e1.getX() - e2.getX();
                        float deltaXAbs = Math.abs(deltaX);
                        // Only when swipe distance between minimal and maximal distance value then we treat it as effective swipe
                        if ((deltaXAbs > 100) && (deltaXAbs < 1000)) {
                            if (deltaX > 0) {
                                openProfile(item, true);
                            }
                        }


                        return true;
                    }

                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        super.onSingleTapUp(e);
                        if (!exoplayer.getPlayWhenReady()) {
                            exoplayer.setPlayWhenReady(true);
                        } else {
                            exoplayer.setPlayWhenReady(false);
                        }


                        return true;
                    }

                    @Override
                    public void onLongPress(MotionEvent e) {
                        super.onLongPress(e);
                        showVideoOption(item);

                    }

                    @Override
                    public boolean onDoubleTap(MotionEvent e) {
                        if (!exoplayer.getPlayWhenReady()) {
                            exoplayer.setPlayWhenReady(true);
                        }
                        if (Variables.sharedPreferences.getBoolean(Variables.IS_LOGIN, false)) {
                            if (!animationRunning) {

                                if (handler != null && runnable != null) {
                                    handler.removeCallbacks(runnable);

                                }
                                handler = new Handler();
                                runnable = new Runnable() {
                                    public void run() {
                                        showHeartOnDoubleTap(item, mainlayout, e);
                                        likeVideo(item);
                                    }
                                };
                                handler.postDelayed(runnable, 100);


                            }
                        } else {

                            Intent intent = new Intent(getActivity(), Login_A.class);
                            startActivity(intent);
                            getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                        }

                        return super.onDoubleTap(e);

                    }
                });

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    gestureDetector.onTouchEvent(event);
                    return true;
                }
            });


            if ((item.promote != null && item.promote.equals("1")) && !isAddAlreadyShow)
                showAd();
            else
                hideAd();

        }

    }

    public void updateVideoView(){
        if(Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN,false)) {
            Functions.callApiForUpdateView(getActivity(), item.video_id);
        }
    }
    // show a video as a ad
    boolean  isAddAlreadyShow;
    public void showAd() {


        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);

        view.findViewById(R.id.side_menu).setVisibility(View.GONE);
        soundImageLayout.setAnimation(null);
        soundImageLayout.setVisibility(View.GONE);
        view.findViewById(R.id.video_info_layout).setVisibility(View.GONE);


        skipBtn.setVisibility(View.VISIBLE);

        Bundle bundle = new Bundle();
        bundle.putString("action", "showad");
        fragmentCallBack.onResponce(bundle);

        countdownTimer(true);

    }



    CountDownTimer countDownTimer;
    public void countdownTimer(boolean starttimer) {

        if (countDownTimer != null)
            countDownTimer.cancel();

        if (view.findViewById(R.id.skip_btn).getVisibility() == View.VISIBLE) {

            if (starttimer) {
                countDownTimer = new CountDownTimer(100000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {

                        if (exoplayer.getCurrentPosition() > 7000) {

                            hideAd();
                            countdownTimer(false);

                        }
                    }

                    @Override
                    public void onFinish() {
                        hideAd();
                    }
                };
                countDownTimer.start();
            }

        }

    }

    // hide the ad of video after some time
    public void hideAd() {
        isAddAlreadyShow = true;

        view.findViewById(R.id.side_menu).setVisibility(View.VISIBLE);
        view.findViewById(R.id.video_info_layout).setVisibility(View.VISIBLE);

        soundImageLayout.setVisibility(View.VISIBLE);
        Animation aniRotate = AnimationUtils.loadAnimation(context, R.anim.d_clockwise_rotation);
        soundImageLayout.startAnimation(aniRotate);

        skipBtn.setVisibility(View.GONE);

        Bundle bundle = new Bundle();
        bundle.putString("action", "hidead");
        fragmentCallBack.onResponce(bundle);
    }



    boolean isVisibleToUser;
    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        isVisibleToUser = visible;

        if (exoplayer != null && visible) {
            setPlayer(isVisibleToUser);
            updateVideoView();
        }
        else if (exoplayer != null && !visible) {
            exoplayer.setPlayWhenReady(false);
        }


    }


    public void mainMenuVisibility(boolean isvisible) {

        if (exoplayer != null && isvisible) {
            exoplayer.setPlayWhenReady(true);
        }

        else if (exoplayer != null && !isvisible) {
            exoplayer.setPlayWhenReady(false);
        }


    }


    // when we swipe for another video this will relaese the privious player
    SimpleExoPlayer exoplayer;
    public void releasePriviousPlayer() {
        if (exoplayer != null) {
            exoplayer.removeListener(this);
            exoplayer.release();
        }
    }


    @Override
    public void onDestroy() {
        releasePriviousPlayer();
        super.onDestroy();

    }


    private void openDuetVideo(HomeModel item) {
        Intent intent123 = new Intent(getActivity(), WatchVideos_F.class);
        intent123.putExtra("video_id", item.duet_video_id);
        startActivity(intent123);
    }

    // this will open the profile of user which have uploaded the currenlty running video
    private void openHashtag(String tag) {

        TagedVideos_F taged_videos_f = new TagedVideos_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("tag", tag);
        taged_videos_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, taged_videos_f).commit();


    }


    @Override
    public void onPause() {
        super.onPause();
        if (exoplayer != null) {
            exoplayer.setPlayWhenReady(false);
        }
    }


    @Override
    public void onStop() {
        super.onStop();
        if (exoplayer != null) {
            exoplayer.setPlayWhenReady(false);
        }
    }


    // handle that call on the player state change
    @Override
    public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

        if (playbackState == Player.STATE_BUFFERING) {
            pbar.setVisibility(View.VISIBLE);
        }
        else if (playbackState == Player.STATE_READY) {
            thumb_image.setVisibility(View.GONE);
            pbar.setVisibility(View.GONE);
        }


    }


    // show a heart animation on double tap
    public boolean showHeartOnDoubleTap(HomeModel item, final RelativeLayout mainlayout, MotionEvent e) {

        int x = (int) e.getX() - 100;
        int y = (int) e.getY() - 100;
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        final ImageView iv = new ImageView(getApplicationContext());
        lp.setMargins(x, y, 0, 0);
        iv.setLayoutParams(lp);
        if (item.liked.equals("1")) {
            iv.setImageDrawable(getResources().getDrawable(
                    R.drawable.ic_like));
        } else {
            iv.setImageDrawable(getResources().getDrawable(
                    R.drawable.ic_like_fill));
        }
        mainlayout.addView(iv);
        Animation fadeoutani = AnimationUtils.loadAnimation(context, R.anim.fade_out);

        fadeoutani.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mainlayout.removeView(iv);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        iv.startAnimation(fadeoutani);

        return true;
    }


    // this function will call for like the video and Call an Api for like the video
    public void likeVideo(final HomeModel home_model) {
        String action = home_model.liked;

        if (action.equals("1")) {
            action = "0";
            home_model.like_count = "" + (Functions.parseInterger(home_model.like_count) - 1);
        } else {
            action = "1";
            home_model.like_count = "" + (Functions.parseInterger(home_model.like_count) + 1);
        }

        home_model.liked = action;

        setLikeData();

        Functions.callApiForLikeVideo(getActivity(), home_model.video_id, action, null);

    }


    // this will open the comment screen
    private void openComment(HomeModel item) {

        int comment_counnt = Functions.parseInterger(item.video_comment_count);

        FragmentDataSend fragment_data_send = this;

        Comment_F comment_f = new Comment_F(comment_counnt, fragment_data_send, "Home_F");
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("video_id", item.video_id);
        args.putString("user_id", item.user_id);
        args.putSerializable("data", item);
        comment_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, comment_f).commit();


    }


    // open the login screen
    public void openLogin() {
        Intent intent = new Intent(getActivity(), Login_A.class);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
    }


    // this will open the profile of user which have uploaded the currenlty running video
    private void openProfile(HomeModel item, boolean from_right_to_left) {

        if (Variables.sharedPreferences.getString(Variables.U_ID, "0").equals(item.user_id)) {

            TabLayout.Tab profile = MainMenuFragment.tabLayout.getTabAt(4);
            profile.select();

        }

        else {
            Profile_F profile_f = new Profile_F(new FragmentCallBack() {
                @Override
                public void onResponce(Bundle bundle) {

                    callApiForSinglevideos();
                }
            });
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();

            if (from_right_to_left) {
                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
            }
            else {
                transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
            }

            Bundle args = new Bundle();
            args.putString("user_id", item.user_id);
            args.putString("user_name", item.username);
            args.putString("user_pic", item.profile_pic);
            profile_f.setArguments(args);
            transaction.addToBackStack(null);
            transaction.replace(R.id.mainMenuFragment, profile_f).commit();
        }

    }


    // show the option that can be apply ti video
    private void showVideoOption(final HomeModel item) {

        Functions.showVideoOption(context, item, new Callback() {
            @Override
            public void onResponce(String resp) {

                if (Variables.sharedPreferences.getBoolean(Variables.IS_LOGIN, false)) {
                    if (resp.equalsIgnoreCase("favourite")) {
                        favouriteVideo(item);
                    } else if (resp.equalsIgnoreCase("not_intrested")) {
                        notInterestVideo(item);
                    } else if (resp.equalsIgnoreCase("report")) {
                        openVideoReport(item);
                    }

                } else
                    openLogin();
            }
        });
    }

    // this method will be favourite the video
    public void favouriteVideo(final HomeModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", item.video_id);
            params.put("user_id", Variables.sharedPreferences.getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.addVideoFavourite, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject jsonObject = new JSONObject(resp);

                    String code = jsonObject.optString("code");
                    if (code.equals("200")) {
                        Functions.showToast(context, "Successfully added to your favourite list!");
                        if (item.favourite != null && item.favourite.equals("0"))
                            item.favourite = "1";
                        else
                            item.favourite = "0";

                        setData();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });


    }

    // call the api if a user is not intersted the video then the video will not show again to him/her
    public void notInterestVideo(final HomeModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", item.video_id);
            params.put("user_id", Variables.sharedPreferences.getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }


        Functions.showLoader(context, false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.notInterestedVideo, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject jsonObject = new JSONObject(resp);
                    String code = jsonObject.optString("code");
                    if (code.equals("200")) {
                        Functions.showToast(context, "Successfully added action");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });


    }

    public void openVideoReport(HomeModel home_model) {
        ReportType_F reportType_f = new ReportType_F(false, null);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);

        Bundle bundle = new Bundle();
        bundle.putString("video_id", home_model.video_id);
        reportType_f.setArguments(bundle);

        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, reportType_f).commit();
        onPause();
    }


    // save the video in to local directory
    public void saveVideo(final HomeModel item) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_id", item.video_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.downloadVideo, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject responce = new JSONObject(resp);
                    String code = responce.optString("code");
                    if (code.equals("200")) {
                        final String download_url = responce.optString("msg");
                        if (download_url != null) {

                            Functions.showDeterminentLoader(context, false, false);
                            PRDownloader.initialize(getActivity().getApplicationContext());
                            DownloadRequest prDownloader = PRDownloader.download(Constants.BASE_URL + download_url, Functions.getAppFolder(context), item.video_id + ".mp4")
                                    .build()

                                    .setOnProgressListener(new OnProgressListener() {
                                        @Override
                                        public void onProgress(Progress progress) {

                                            int prog = (int) ((progress.currentBytes * 100) / progress.totalBytes);
                                            Functions.showLoadingProgress(prog);

                                        }
                                    });


                            prDownloader.start(new OnDownloadListener() {
                                @Override
                                public void onDownloadComplete() {
                                    Functions.cancelDeterminentLoader();

                                    deleteWaterMarkeVideo(download_url);
                                    scanFile(item);
                                }

                                @Override
                                public void onError(Error error) {

                                    Functions.showToast(context, "Error");
                                    Functions.cancelDeterminentLoader();
                                }


                            });

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });
    }


    public void deleteWaterMarkeVideo(String video_url) {

        JSONObject params = new JSONObject();
        try {
            params.put("video_url", video_url);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.deleteWaterMarkVideo, params, null);


    }


    public void scanFile(HomeModel item) {

        if (Build.VERSION.SDK_INT < 29) {

            try {
                Functions.copyFile(new File(Functions.getAppFolder(context) + item.video_id + ".mp4"),new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+item.video_id + ".mp4"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            MediaScannerConnection.scanFile(getActivity(),
                new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+item.video_id + ".mp4"},
                null,
                new MediaScannerConnection.OnScanCompletedListener() {

                    public void onScanCompleted(String path, Uri uri) {
                    }
                });

        }
    }


    // download the video for duet with
    public void duetVideo(final HomeModel item) {

        Functions.printLog(Constants.tag, item.video_url);
        if (item.video_url != null) {

            Functions.showDeterminentLoader(context, false, false);
            PRDownloader.initialize(getActivity().getApplicationContext());
            DownloadRequest prDownloader = PRDownloader.download(item.video_url, Functions.getAppFolder(context), item.video_id + ".mp4")
                    .build()

                    .setOnProgressListener(new OnProgressListener() {
                        @Override
                        public void onProgress(Progress progress) {
                            int prog = (int) ((progress.currentBytes * 100) / progress.totalBytes);
                            Functions.showLoadingProgress(prog);

                        }
                    });


            prDownloader.start(new OnDownloadListener() {
                @Override
                public void onDownloadComplete() {
                    Functions.cancelDeterminentLoader();

                    openDuetRecording(item);

                }

                @Override
                public void onError(Error error) {

                    Functions.showToast(context, "Error");
                    Functions.cancelDeterminentLoader();
                }


            });

        }

    }


    public void openDuetRecording(HomeModel item) {

        Intent intent = new Intent(getActivity(), Video_Recoder_Duet_A.class);
        intent.putExtra("data", item);
        startActivity(intent);

    }


    // call api for refersh the video details
    private void callApiForSinglevideos() {

        JSONObject parameters = new JSONObject();
        try {
            if (Variables.sharedPreferences.getString(Variables.U_ID, null) != null)
                parameters.put("user_id", Variables.sharedPreferences.getString(Variables.U_ID, "0"));

            parameters.put("video_id", item.video_id);

        }

        catch (JSONException e) {
            e.printStackTrace();
        }


        ApiRequest.callApi(getActivity(), ApiLinks.showVideoDetail, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                singalVideoParseData(resp);
            }
        });

    }

    // parse the data for a video
    public void singalVideoParseData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONObject msg = jsonObject.optJSONObject("msg");

                JSONObject video = msg.optJSONObject("Video");
                JSONObject user = msg.optJSONObject("User");
                JSONObject sound = msg.optJSONObject("Sound");
                JSONObject userprivacy = user.optJSONObject("PrivacySetting");
                JSONObject userPushNotification = user.optJSONObject("PushNotification");

                item = Functions.parseVideoData(user, sound, video, userprivacy, userPushNotification);
                setData();

            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {

            e.printStackTrace();
        }

    }

    @Override
    public void onDataSent(String yourData) {
        int comment_count = Functions.parseInterger(yourData);
        item.video_comment_count = "" + comment_count;
        commentTxt.setText(Functions.getSuffix(item.video_comment_count));
    }


    // check the camera and mic permision before open duet recording
    public boolean checkPermissions() {

        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
        };

        if (!hasPermissions(context, PERMISSIONS)) {
            requestPermissions(PERMISSIONS, 2);
        } else {

            return true;
        }

        return false;
    }


    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


}
