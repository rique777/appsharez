package com.qboxus.musictok.ActivitesFragment;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qboxus.musictok.ActivitesFragment.Accounts.RequestVarification_F;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Setting_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;


    public Setting_F() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_setting, container, false);
        context = getContext();

        view.findViewById(R.id.goBack).setOnClickListener(this);
        view.findViewById(R.id.request_verification_txt).setOnClickListener(this);
        view.findViewById(R.id.privacy_policy_txt).setOnClickListener(this);
        view.findViewById(R.id.privacy_setting_txt).setOnClickListener(this);
        view.findViewById(R.id.push_notification_txt).setOnClickListener(this);
        view.findViewById(R.id.change_password_txt).setOnClickListener(this);
        view.findViewById(R.id.terms_condition_txt).setOnClickListener(this::onClick);


        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.goBack:
                getActivity().onBackPressed();
                break;

            case R.id.request_verification_txt:
                openRequestVerification();
                break;

            case R.id.privacy_policy_txt:
                openWebUrl("Privacy Policy", Constants.privacy_policy);
                break;


            case R.id.privacy_setting_txt:
                openPrivacySetting();
                break;

            case R.id.push_notification_txt:
                openPushNotificationSetting();
                break;

            case R.id.terms_condition_txt:
                openWebUrl("Terms & Conditions", Constants.terms_conditions);
                break;

            case R.id.change_password_txt:
                openPassword();
                break;

            default:
                return;
        }

    }


    private void openPassword() {
        ChangePassword_F change_password_f = new ChangePassword_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.setting_F, change_password_f).commit();
    }


    private void openPrivacySetting() {
        PrivacyPolicySetting_F policy_setting_f = new PrivacyPolicySetting_F();
        Bundle bundle = new Bundle();
        policy_setting_f.setArguments(bundle);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.setting_F, policy_setting_f).commit();
    }

    private void openPushNotificationSetting() {
        PushNotificationSetting_F push_setting_f = new PushNotificationSetting_F();
        Bundle bundle = new Bundle();
        push_setting_f.setArguments(bundle);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.setting_F, push_setting_f).commit();
    }


    public void openRequestVerification() {
        RequestVarification_F request_varification_f = new RequestVarification_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.setting_F, request_varification_f).commit();
    }

    public void openWebUrl(String title, String url) {
        Webview_F webview_f = new Webview_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putString("title", title);
        webview_f.setArguments(bundle);
        transaction.addToBackStack(null);
        transaction.replace(R.id.setting_F, webview_f).commit();
    }


}
