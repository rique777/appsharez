package com.qboxus.musictok.ActivitesFragment.VideoRecording;

import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.daasuu.gpuv.composer.GPUMp4Composer;
import com.daasuu.gpuv.egl.filter.GlFilterGroup;
import com.daasuu.gpuv.player.GPUPlayerView;
import com.daasuu.gpuv.player.PlayerScaleType;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.SimpleClasses.FilterType;
import com.qboxus.musictok.Adapters.FilterAdapter;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class Preview_Video_A extends AppCompatActivity implements Player.EventListener {


    String videoUrl, isSoundSelected;
    GPUPlayerView gpuPlayerView;
    public static int selectPostion = 0;
    final List<FilterType> filterTypes = FilterType.createFilterList();
    FilterAdapter adapter;
    RecyclerView recylerview;

    String draftFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview_video);


        Intent intent = getIntent();
        if (intent != null) {
            String fromWhere = intent.getStringExtra("fromWhere");
            if (fromWhere != null && fromWhere.equals("video_recording")) {
                isSoundSelected = intent.getStringExtra("isSoundSelected");
                draftFile = intent.getStringExtra("draft_file");
            } else {
                draftFile = intent.getStringExtra("draft_file");
            }
        }


        selectPostion = 0;
        videoUrl = Functions.getAppFolder(this)+Variables.outputfile2;
        findViewById(R.id.goBack).setOnClickListener(v -> {

            finish();
            overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);

        });


        findViewById(R.id.next_btn).setOnClickListener(v -> {

            if (selectPostion == 0) {

                try {
                    Functions.copyFile(new File(Functions.getAppFolder(this)+Variables.outputfile2), new File(Functions.getAppFolder(this)+Variables.output_filter_file));
                    gotopostScreen();
                } catch (IOException e) {
                    e.printStackTrace();
                    Functions.printLog(Constants.tag, e.toString());
                    saveVideo(Functions.getAppFolder(this)+Variables.outputfile2, Functions.getAppFolder(this)+Variables.output_filter_file);
                }

            } else
                saveVideo(Functions.getAppFolder(this)+Variables.outputfile2, Functions.getAppFolder(this)+Variables.output_filter_file);

        });


        setPlayer(videoUrl);
        if (isSoundSelected != null && isSoundSelected.equals("yes")) {
            Functions.printLog("resp", "isSoundSelected : " + isSoundSelected);
            preparedAudio();
        }


        recylerview = findViewById(R.id.recylerview);

        adapter = new FilterAdapter(this, filterTypes, (view, postion, item) -> {

            selectPostion = postion;
            gpuPlayerView.setGlFilter(FilterType.createGlFilter(filterTypes.get(postion), getApplicationContext()));
            adapter.notifyDataSetChanged();

        });
        recylerview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recylerview.setAdapter(adapter);


    }


    MediaPlayer audio;

    public void preparedAudio() {
        videoPlayer.setVolume(0);

        File file = new File(Functions.getAppFolder(this)+Variables.APP_HIDED_FOLDER + Variables.SelectedAudio_AAC);
        if (file.exists()) {
            audio = new MediaPlayer();
            try {
                audio.setDataSource(Functions.getAppFolder(this)+Variables.APP_HIDED_FOLDER + Variables.SelectedAudio_AAC);
                audio.prepare();
                audio.setLooping(true);


                videoPlayer.seekTo(0);
                videoPlayer.setPlayWhenReady(true);
                audio.start();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    // this function will set the player to the current video
    SimpleExoPlayer videoPlayer;

    public void setPlayer(String path) {

        DefaultTrackSelector trackSelector = new DefaultTrackSelector();
        videoPlayer = ExoPlayerFactory.newSimpleInstance(this, trackSelector);
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(this,
                Util.getUserAgent(this, "TikTok"));

        MediaSource videoSource = new ExtractorMediaSource.Factory(dataSourceFactory)
                .createMediaSource(Uri.parse(path));



        videoPlayer.prepare(videoSource);
        videoPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
        videoPlayer.addListener(this);


        videoPlayer.setPlayWhenReady(true);


        gpuPlayerView = new GPUPlayerView(this);

        MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
        metaRetriever.setDataSource(path);
        String rotation = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);

        if (rotation != null && rotation.equalsIgnoreCase("0")) {
            gpuPlayerView.setPlayerScaleType(PlayerScaleType.RESIZE_FIT_WIDTH);
        } else
            gpuPlayerView.setPlayerScaleType(PlayerScaleType.RESIZE_NONE);


        gpuPlayerView.setSimpleExoPlayer(videoPlayer);
        gpuPlayerView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ((MovieWrapperView) findViewById(R.id.layout_movie_wrapper)).addView(gpuPlayerView);

        gpuPlayerView.onResume();

    }


    // this is lifecyle of the Activity which is importent for play,pause video or relaese the player

    @Override
    protected void onRestart() {
        super.onRestart();

        if (videoPlayer != null) {
            videoPlayer.setPlayWhenReady(true);
        }
        if (audio != null) {
            audio.start();
        }

    }


    @Override
    protected void onResume() {
        super.onResume();
        if (videoPlayer != null) {
            videoPlayer.setPlayWhenReady(true);
        }
    }


    @Override
    public void onStop() {
        super.onStop();
        try {
            if (videoPlayer != null) {
                videoPlayer.setPlayWhenReady(false);
            }
            if (audio != null) {
                audio.pause();
            }
        } catch (Exception e) {

        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (videoPlayer != null) {
            videoPlayer.release();
        }

        if (audio != null) {
            audio.pause();
            audio.release();
        }
    }


    @Override
    protected void onStart() {
        super.onStart();

        if (videoPlayer != null) {
            videoPlayer.setPlayWhenReady(true);
        }

    }


    // this function will add the filter to video and save that same video for post the video in post video screen
    public void saveVideo(String srcMp4Path, final String destMp4Path) {

        Functions.showDeterminentLoader(this, false, false);
        new GPUMp4Composer(srcMp4Path, destMp4Path)
                .filter(new GlFilterGroup(FilterType.createGlFilter(filterTypes.get(selectPostion), getApplicationContext())))
                .listener(new GPUMp4Composer.Listener() {
                    @Override
                    public void onProgress(double progress) {

                        Functions.printLog("resp", "" + (int) (progress * 100));
                        Functions.showLoadingProgress((int) (progress * 100));


                    }

                    @Override
                    public void onCompleted() {

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                Functions.cancelDeterminentLoader();

                                gotopostScreen();


                            }
                        });


                    }

                    @Override
                    public void onCanceled() {
                        Functions.printLog("resp", "onCanceled");
                    }

                    @Override
                    public void onFailed(Exception exception) {

                        Functions.printLog("resp", exception.toString());

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    Functions.cancelDeterminentLoader();

                                    Functions.showToast(Preview_Video_A.this, "Try Again");
                                } catch (Exception e) {

                                }
                            }
                        });

                    }
                })
                .start();


    }


    // go to the post video screen from perview video screen
    public void gotopostScreen() {

        if (adapter != null)
            adapter.recycle_bitmap();

        Intent intent = new Intent(Preview_Video_A.this, Post_Video_A.class);
        intent.putExtra("draft_file", draftFile);
        startActivity(intent);
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);

    }


    @Override
    public void onBackPressed() {

        finish();
        overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);

    }


    // handler that show the video play state
    @Override
    public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

        if (playbackState == Player.STATE_ENDED) {

            videoPlayer.seekTo(0);
            videoPlayer.setPlayWhenReady(true);

            if (audio != null) {
                audio.seekTo(0);
                audio.start();
            }
        }

    }


}
