package com.qboxus.musictok.ActivitesFragment.VideoRecording;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.qboxus.musictok.Constants;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Adapters.UsersAdapter;
import com.qboxus.musictok.Models.UsersModel;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Friends_F extends Fragment {
    View view;
    Context context;
    String userId;
    UsersAdapter adapter;
    RecyclerView recyclerView;
    ArrayList<UsersModel> datalist;
    EditText searchEdit;
    RelativeLayout noDataLayout;
    ProgressBar pbar;
    CardView searchLayout;
    String fromWhere;
    TextView titleTxt;
    Toolbar toolbar;

    FragmentCallBack fragmentCallback;

    @SuppressLint("ValidFragment")
    public Friends_F(FragmentCallBack fragmentCallback, String fromWhere) {
        this.fragmentCallback = fragmentCallback;
        this.fromWhere = fromWhere;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_friends_layout, container, false);
        context = getContext();

        Bundle bundle = getArguments();
        if (bundle != null) {
            userId = bundle.getString("id");
        }

        titleTxt = view.findViewById(R.id.title_txt);

        datalist = new ArrayList<>();

        recyclerView = view.findViewById(R.id.recylerview);
        searchEdit = view.findViewById(R.id.search_edit);
        toolbar = view.findViewById(R.id.toolbar);
        searchLayout = view.findViewById(R.id.search_layout);


        callApiForGetAllfollowing();

        searchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //TODO implementation
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                String search_txt = searchEdit.getText().toString();
                if (search_txt.length() > 0) {
                    callApiForOtherUsers();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //TODO implementation
            }
        });

        final LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        adapter = new UsersAdapter(context, datalist, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {

                UsersModel item1 = (UsersModel) object;
                switch (view.getId()) {
                    case R.id.mainlayout:
                        passDataBack(item1);
                        break;

                }

            }
        });

        recyclerView.setAdapter(adapter);


        noDataLayout = view.findViewById(R.id.no_data_layout);
        pbar = view.findViewById(R.id.pbar);


        view.findViewById(R.id.back_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });


        return view;
    }


    //call api for get the all follwers of specific profile
    private void callApiForOtherUsers() {
        noDataLayout.setVisibility(View.GONE);
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("type", "user");
            parameters.put("keyword", searchEdit.getText().toString());
            parameters.put("starting_point", "0");
        } catch (JSONException e) {
            e.printStackTrace();
        }


        ApiRequest.callApi(getActivity(), ApiLinks.search, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                parseFollowingData(resp);
            }
        });


    }


    // Bottom two function will call the api and get all the videos form api and parse the json data
    private void callApiForGetAllfollowing() {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showFollowing, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                parseFollowingData(resp);
            }
        });


    }

    public void parseFollowingData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {

                JSONArray msg = jsonObject.optJSONArray("msg");
                ArrayList<UsersModel> temp_list = new ArrayList<>();
                for (int i = 0; i < msg.length(); i++) {
                    JSONObject data = msg.optJSONObject(i);

                    JSONObject userObject = data.optJSONObject("User");
                    if (userObject == null)
                        userObject = data.optJSONObject("FollowingList");

                    UsersModel user = new UsersModel();
                    user.fb_id = userObject.optString("id");
                    user.username = userObject.optString("username");
                    user.first_name = userObject.optString("first_name");
                    user.last_name = userObject.optString("last_name");
                    user.gender = userObject.optString("gender");

                    user.profile_pic = userObject.optString("profile_pic", "");
                    if (!user.profile_pic.contains(Variables.http)) {
                        user.profile_pic = Constants.BASE_URL + user.profile_pic;
                    }

                    user.followers_count = userObject.optString("followers_count", "0");
                    user.videos = userObject.optString("video_count", "0");


                    temp_list.add(user);


                }

                datalist.clear();
                datalist.addAll(temp_list);
                adapter.notifyDataSetChanged();

                pbar.setVisibility(View.GONE);

                if (datalist.isEmpty()) {
                    noDataLayout.setVisibility(View.VISIBLE);
                } else
                    noDataLayout.setVisibility(View.GONE);

            } else {
                pbar.setVisibility(View.GONE);
                searchEdit.setHint("Not following anyone yet");
                noDataLayout.setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    // this will open the profile of user which have uploaded the currenlty running video
    private void passDataBack(final UsersModel item) {
        Bundle bundle = new Bundle();
        if (fragmentCallback != null) {
            bundle.putSerializable("data", item);
            fragmentCallback.onResponce(bundle);
        }
        getActivity().getSupportFragmentManager().popBackStackImmediate();

    }

}