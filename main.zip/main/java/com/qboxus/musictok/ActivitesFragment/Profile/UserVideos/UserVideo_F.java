package com.qboxus.musictok.ActivitesFragment.Profile.UserVideos;


import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.Adapters.MyVideosAdapter;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.qboxus.musictok.ActivitesFragment.WatchVideos_F;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class UserVideo_F extends Fragment {

    RecyclerView recyclerView;
    ArrayList<HomeModel> dataList;
    MyVideosAdapter adapter;
    View view;
    Context context;
    String userId;

    RelativeLayout noDataLayout;

    NewVideoBroadCast mReceiver;

    public UserVideo_F() {

    }

    boolean is_my_profile = true;

    @SuppressLint("ValidFragment")
    public UserVideo_F(boolean is_my_profile, String userId) {
        this.is_my_profile = is_my_profile;
        this.userId = userId;
    }


    private class NewVideoBroadCast extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            Variables.reloadMyVideosInner = false;
            callApiForGetAllvideos();
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_user_video, container, false);

        context = getContext();


        recyclerView = view.findViewById(R.id.recylerview);
        final GridLayoutManager layoutManager = new GridLayoutManager(context, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        dataList = new ArrayList<>();
        adapter = new MyVideosAdapter(context, dataList, (view, pos, object) -> {
            HomeModel item = (HomeModel) object;
            openWatchVideo(pos);

        });

        recyclerView.setAdapter(adapter);

        noDataLayout = view.findViewById(R.id.no_data_layout);


        mReceiver = new NewVideoBroadCast();
        getActivity().registerReceiver(mReceiver, new IntentFilter("newVideo"));

        return view;

    }

    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        new Handler().postDelayed(() -> {

            if (view != null && visible) {
                callApiForGetAllvideos();
            }

        }, 200);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mReceiver != null) {
            getActivity().unregisterReceiver(mReceiver);
            mReceiver = null;
        }
    }


    Boolean isApiRun = false;

    //this will get the all videos data of user and then parse the data
    private void callApiForGetAllvideos() {
        isApiRun = true;
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

            if (!is_my_profile) {
                parameters.put("other_user_id", userId);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showVideosAgainstUserID, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                isApiRun = false;
                parseData(resp);
            }
        });


    }

    public void parseData(String responce) {

        dataList.clear();
        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONObject msg = jsonObject.optJSONObject("msg");
                JSONArray public_array = msg.optJSONArray("public");


                for (int i = 0; i < public_array.length(); i++) {
                    JSONObject itemdata = public_array.optJSONObject(i);

                    JSONObject video = itemdata.optJSONObject("Video");
                    JSONObject user = itemdata.optJSONObject("User");
                    JSONObject sound = itemdata.optJSONObject("Sound");
                    JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                    JSONObject userPushNotification = user.optJSONObject("PushNotification");

                    HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, userPushNotification);


                    dataList.add(item);
                }

                if (dataList.isEmpty()) {
                    noDataLayout.setVisibility(View.VISIBLE);
                } else {
                    noDataLayout.setVisibility(View.GONE);
                }

                adapter.notifyDataSetChanged();


            } else {
                noDataLayout.setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    // open the videos in full screen on click
    private void openWatchVideo(int postion) {

        Intent intent = new Intent(getActivity(), WatchVideos_F.class);
        intent.putExtra("arraylist", dataList);
        intent.putExtra("position", postion);
        startActivity(intent);

    }


    @Override
    public void onResume() {
        super.onResume();
        callApiForGetAllvideos();
    }


}
