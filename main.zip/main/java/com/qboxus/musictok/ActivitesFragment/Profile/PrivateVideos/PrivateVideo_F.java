package com.qboxus.musictok.ActivitesFragment.Profile.PrivateVideos;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.Adapters.MyVideosAdapter;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.qboxus.musictok.ActivitesFragment.WatchVideos_F;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class PrivateVideo_F extends Fragment {

    public RecyclerView recyclerView;
    ArrayList<HomeModel> dataList;
    MyVideosAdapter adapter;
    View view;
    Context context;

    RelativeLayout noDataLayout;

    NewVideoBroadCast mReceiver;

    public PrivateVideo_F() {

    }


    private class NewVideoBroadCast extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            Variables.reloadMyVideosInner = false;
            callApiForGetAllvideos();
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_user_video, container, false);

        context = getContext();


        recyclerView = view.findViewById(R.id.recylerview);
        final GridLayoutManager layoutManager = new GridLayoutManager(context, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        dataList = new ArrayList<>();
        adapter = new MyVideosAdapter(context, dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                HomeModel item = (HomeModel) object;
                openWatchVideo(pos);
            }
        });

        recyclerView.setAdapter(adapter);

        noDataLayout = view.findViewById(R.id.no_data_layout);


        callApiForGetAllvideos();


        mReceiver = new NewVideoBroadCast();
        getActivity().registerReceiver(mReceiver, new IntentFilter("newVideo"));

        return view;

    }

    Boolean isVisibleToUser = false;

    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        this.isVisibleToUser = visible;
        if (view != null && isVisibleToUser) {
            callApiForGetAllvideos();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        if ((view != null && isVisibleToUser) && !isApiRun) {
            callApiForGetAllvideos();
        } else if ((view != null && Variables.reloadMyVideosInner) && !isApiRun) {
            Variables.reloadMyVideosInner = false;
            callApiForGetAllvideos();
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mReceiver != null) {
            getActivity().unregisterReceiver(mReceiver);
            mReceiver = null;
        }

    }


    Boolean isApiRun = false;

    //this will get the all videos data of user and then parse the data
    private void callApiForGetAllvideos() {
        isApiRun = true;
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showVideosAgainstUserID, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                isApiRun = false;
                parseData(resp);
            }
        });


    }

    // parse the video list data
    public void parseData(String responce) {

        dataList.clear();

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONObject msg = jsonObject.optJSONObject("msg");
                JSONArray public_array = msg.optJSONArray("private");


                for (int i = 0; i < public_array.length(); i++) {
                    JSONObject itemdata = public_array.optJSONObject(i);

                    JSONObject video = itemdata.optJSONObject("Video");
                    JSONObject user = itemdata.optJSONObject("User");
                    JSONObject sound = itemdata.optJSONObject("Sound");
                    JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                    JSONObject userPushNotification = user.optJSONObject("PushNotification");

                    HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, userPushNotification);


                    dataList.add(item);
                }

                if (dataList.isEmpty()) {
                    noDataLayout.setVisibility(View.VISIBLE);
                } else {
                    noDataLayout.setVisibility(View.GONE);
                }

                adapter.notifyDataSetChanged();


            } else {
                noDataLayout.setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    // open the video in full screen
    private void openWatchVideo(int postion) {

        Intent intent = new Intent(getActivity(), WatchVideos_F.class);
        intent.putExtra("arraylist", dataList);
        intent.putExtra("position", postion);
        startActivity(intent);

    }


}
