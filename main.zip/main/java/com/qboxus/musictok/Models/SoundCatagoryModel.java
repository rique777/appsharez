package com.qboxus.musictok.Models;

import java.util.ArrayList;

public class SoundCatagoryModel {
    public String id, catagory;
    public ArrayList<SoundsModel> sound_list = new ArrayList<>();
}
