package com.qboxus.musictok.Models;

import java.io.Serializable;

public class UserModel implements Serializable {

    public String socail_id, socail_type, fname, lname, email, date_of_birth, phone_no, password, username, auth_tokon;
}
