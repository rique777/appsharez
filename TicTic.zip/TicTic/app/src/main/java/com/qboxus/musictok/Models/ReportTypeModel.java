package com.qboxus.musictok.Models;

public class ReportTypeModel {

    public String id, title;

}
