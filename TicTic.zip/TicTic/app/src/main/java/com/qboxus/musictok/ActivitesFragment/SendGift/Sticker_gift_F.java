package com.qboxus.musictok.ActivitesFragment.SendGift;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.qboxus.musictok.ActivitesFragment.My_Wallet.MyWallet;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class Sticker_gift_F  extends BottomSheetDialogFragment {

    View view;
    Context context;
    TextView coins_txt;
    double total_coins=0;
    Button tab_send_gift;
    SendGiftVHAdapter giftSliderAdapter;
    List<Sticker_model> data_list=new ArrayList<>();
    Sticker_model selectedModel;

    SliderView imageSlider;

    private Handler handler = new Handler();
    private Runnable runnable;

    String id,name,image;
    int giftCounter=0;

    FragmentCallBack callBack;


    public Sticker_gift_F() {

    }

    public Sticker_gift_F(String id,String name,String image, ArrayList<Sticker_model> data_list,FragmentCallBack callBack) {
        this.id=id;
        this.name=name;
        this.image=image;
        this.data_list=data_list;
        this.callBack = callBack;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_sticker_gift, container, false);
        context=getContext();

        coins_txt=view.findViewById(R.id.coins_txt);

        String wallet =""+Functions.getSharedPreference(view.getContext()).getString(Variables.U_WALLET, "0");
        total_coins=Double.parseDouble(wallet);
        coins_txt.setText(wallet);
        tab_send_gift=view.findViewById(R.id.tab_send_gift);
        imageSlider=view.findViewById(R.id.imageSlider);
        SetUpGiftSliderAdapter();

        view.findViewById(R.id.recharge_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                startActivity(new Intent(getActivity(), MyWallet.class));
            }
        });


        tab_send_gift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                giftCounter=giftCounter+1;

                Bundle bundle=new Bundle();
                bundle.putBoolean("isShow",false);
                bundle.putBoolean("showCount",true);
                bundle.putString("count",""+giftCounter);
                bundle.putSerializable("Data",selectedModel);
                callBack.onResponce(bundle);

                handler.removeCallbacks(runnable);
                runnable=new Runnable() {
                    @Override
                    public void run() {

                        for(Sticker_model model:data_list)
                        {
                            if (model.isSelected)
                            {

                                double coin_required=(Double.valueOf(model.coins)*giftCounter);
                                if(total_coins!=0 && coin_required!=0){

                                    if(total_coins>=coin_required){
                                        Call_api_Send_sticker(model,giftCounter);
                                        giftCounter=0;
                                    }
                                    else {
                                        Toast.makeText(context, "You don't have sufficient Coins", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }


                    }
                };
                handler.postDelayed(runnable, 1000);



            }
        });


        TextView username_txt=view.findViewById(R.id.username_txt);
        username_txt.setText("Send gift to "+name);


        return view;

    }

    private void SetUpGiftSliderAdapter() {

        giftSliderAdapter=new SendGiftVHAdapter(Functions.createChunksOfList(data_list,6),tab_send_gift, new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {
                if (bundle.getBoolean("isShow",false))
                {
                    selectedModel= (Sticker_model) bundle.getSerializable("Data");
                }
            }
        });
        imageSlider.setSliderAdapter(giftSliderAdapter);
        giftSliderAdapter.notifyDataSetChanged();
    }



    public void Call_api_Send_sticker(Sticker_model model,int giftCount){
        JSONObject params=new JSONObject();
        try {
            params.put("sender_id",Variables.sharedPreferences.getString(Variables.U_ID,""));
            params.put("receiver_id",id);
            params.put("gift_id",model.id);
            params.put("gift_count",giftCount);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context,false,false);
        ApiRequest.callApi(getActivity(), ApiLinks.sendGift, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject jsonObject=new JSONObject(resp);
                    String code=jsonObject.optString("code");
                    if(code!=null && code.equals("200")){
                        JSONObject msgObj=jsonObject.getJSONObject("msg");
                        JSONObject userdata = msgObj.getJSONObject("User");
                        SharedPreferences.Editor editor = Functions.getSharedPreference(view.getContext()).edit();
                        editor.putString(Variables.U_WALLET, userdata.optString("wallet","0"));
                        editor.commit();

                        Bundle bundle=new Bundle();
                        bundle.putBoolean("isShow",true);
                        bundle.putString("count",""+giftCount);
                        bundle.putSerializable("Data",model);
                        callBack.onResponce(bundle);
                        dismiss();
                    }
                    else
                    if(code!=null && code.equals("201"))
                    {
                        Functions.showAlert(view.getContext(),getString(R.string.server_error),""+jsonObject.optString("msg"));
                    }
                    else
                        Toast.makeText(context, ""+jsonObject.optString("msg"), Toast.LENGTH_SHORT).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });

    }



}
