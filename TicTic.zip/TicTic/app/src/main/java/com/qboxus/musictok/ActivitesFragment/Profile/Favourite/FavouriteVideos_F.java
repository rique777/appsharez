package com.qboxus.musictok.ActivitesFragment.Profile.Favourite;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.qboxus.musictok.ActivitesFragment.WatchVideos_F;
import com.qboxus.musictok.Adapters.VideosListAdapter;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class FavouriteVideos_F extends Fragment {

    View view;
    Context context;
    ShimmerFrameLayout shimmerFrameLayout;
    RecyclerView recyclerView;

    public FavouriteVideos_F() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_favourite_videos, container, false);
        context = getContext();

        shimmerFrameLayout = view.findViewById(R.id.shimmer_view_container);
        shimmerFrameLayout.startShimmer();
        recyclerView = view.findViewById(R.id.recylerview);

        callApi();

        return view;
    }


    // get the list of videos that you favourite
    public void callApi() {

        JSONObject params = new JSONObject();
        try {
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showFavouriteVideos, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                shimmerFrameLayout.stopShimmer();
                shimmerFrameLayout.setVisibility(View.GONE);
                parseVideo(resp);


            }
        });

    }


    // parse the video list in data model
    ArrayList<HomeModel> dataList;

    public void parseVideo(String responce) {

        dataList = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");
                for (int i = 0; i < msgArray.length(); i++) {
                    JSONObject itemdata = msgArray.optJSONObject(i);
                    JSONObject video = itemdata.optJSONObject("Video");
                    JSONObject sound = video.optJSONObject("Sound");
                    JSONObject user = video.optJSONObject("User");
                    JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                    JSONObject userPushNotification = user.optJSONObject("PushNotification");

                    HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, userPushNotification);

                    dataList.add(item);
                }

                if (dataList.isEmpty()) {
                    view.findViewById(R.id.no_data_layout).setVisibility(View.VISIBLE);
                } else
                    view.findViewById(R.id.no_data_layout).setVisibility(View.GONE);


                GridLayoutManager linearLayoutManager = new GridLayoutManager(context, 2);
                recyclerView.setLayoutManager(linearLayoutManager);
                VideosListAdapter adapter = new VideosListAdapter(context, dataList, new AdapterClickListener() {
                    @Override
                    public void onItemClick(View view, int pos, Object object) {

                        HomeModel item = (HomeModel) object;
                        openWatchVideo(item.video_id);


                    }
                });
                recyclerView.setAdapter(adapter);


            } else {
                view.findViewById(R.id.no_data_layout).setVisibility(View.VISIBLE);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    // open the video in full screen
    private void openWatchVideo(String videoId) {
        Intent intent = new Intent(getActivity(), WatchVideos_F.class);
        intent.putExtra("video_id", videoId);
        startActivity(intent);
    }


}