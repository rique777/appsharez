package com.qboxus.musictok.ActivitesFragment;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.qboxus.musictok.Constants;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;


/**
 * A simple {@link Fragment} subclass.
 */


// show any kind of url in app
public class Webview_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;

    ProgressBar progressBar;
    WebView webView;
    String url = "www.google.com";
    String title;
    TextView titleTxt;

    public Webview_F() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_webview, container, false);
        context = getContext();

        Bundle bundle = getArguments();
        if (bundle != null) {
            url = bundle.getString("url");
            title = bundle.getString("title");

            if (title.equals("Promote Video")) {
                view.findViewById(R.id.toolbar).setVisibility(View.GONE);
            }
        }


        Functions.printLog(Constants.tag,url);


        view.findViewById(R.id.goBack).setOnClickListener(this::onClick);

        titleTxt = view.findViewById(R.id.title_txt);
        titleTxt.setText(title);

        webView = view.findViewById(R.id.webview);
        progressBar = view.findViewById(R.id.progress_bar);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int progress) {
                if (progress >= 80) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });


        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(url);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                if (url.equalsIgnoreCase("closePopup")) {
                    getActivity().onBackPressed();
                }
                return false;
            }
        });


        return view;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.goBack:
                getActivity().onBackPressed();
                break;
        }
    }
}
