package com.qboxus.musictok.ActivitesFragment;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.PrivacyPolicySettingModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;

import io.paperdb.Paper;


public class PrivacyPolicySetting_F extends RootFragment implements View.OnClickListener {

    View view;
    TextView allowDownloadTxt, allowCommenetTxt, allowDirectMesgTxt, allowDuetTxt,
            allowViewLikevidTxt;

    String cancel = "Cancel";

    PrivacyPolicySettingModel privacyPolicySettingModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_privacy_policy_setting_, container, false);
        initControl();
        return view;
    }


    // initialize the all views
    private void initControl() {
        privacyPolicySettingModel = (PrivacyPolicySettingModel) Paper.book("Setting").read("PrivacySettingModel");
        allowDownloadTxt = view.findViewById(R.id.allow_download_txt);
        allowCommenetTxt = view.findViewById(R.id.allow_commenet_txt);
        allowDirectMesgTxt = view.findViewById(R.id.allow_direct_mesg_txt);
        allowDuetTxt = view.findViewById(R.id.allow_duet_txt);
        allowViewLikevidTxt = view.findViewById(R.id.allow_view_likevid_txt);

        setUpScreenData();

        view.findViewById(R.id.PrivacyPolicySetting_F_img_back).setOnClickListener(this);
        view.findViewById(R.id.clickLess).setOnClickListener(this);

        view.findViewById(R.id.allow_download_layout).setOnClickListener(this);
        view.findViewById(R.id.allow_commenet_layout).setOnClickListener(this);
        view.findViewById(R.id.allow_dmesges_layout).setOnClickListener(this);
        view.findViewById(R.id.allow_duet_layout).setOnClickListener(this);
        view.findViewById(R.id.allow_view_likevid_layout).setOnClickListener(this);
    }

    private void setUpScreenData() {
        try {
            if (privacyPolicySettingModel.getVideos_download().equals("1")) {
                allowDownloadTxt.setText(Functions.stringParseFromServerRestriction("On"));
            } else {
                allowDownloadTxt.setText(Functions.stringParseFromServerRestriction("Off"));
            }
            allowCommenetTxt.setText(Functions.stringParseFromServerRestriction(privacyPolicySettingModel.getVideo_comment()));
            allowDirectMesgTxt.setText(Functions.stringParseFromServerRestriction(privacyPolicySettingModel.getDirect_message()));
            allowDuetTxt.setText(Functions.stringParseFromServerRestriction(privacyPolicySettingModel.getDuet()));
            allowViewLikevidTxt.setText(Functions.stringParseFromServerRestriction(privacyPolicySettingModel.getLiked_videos()));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.clickLess:
                break;
            case R.id.PrivacyPolicySetting_F_img_back:
                getActivity().onBackPressed();
                break;
            case R.id.allow_download_layout:
                final CharSequence[] options = {"On", "Off", "Cancel"};
                selectimage("Select download option", options, (TextView) view.findViewById(R.id.allow_download_txt), 1);
                break;
            case R.id.allow_commenet_layout:
                final CharSequence[] Commentoptions = {"Everyone", "Friend", "No One", "Cancel"};
                selectimage("Select Comment option", Commentoptions, (TextView) view.findViewById(R.id.allow_commenet_txt), 2);
                break;
            case R.id.allow_dmesges_layout:
                final CharSequence[] messgeoptions = {"Everyone", "Friend", "No One", "Cancel"};
                selectimage("Select message option", messgeoptions, allowDirectMesgTxt, 3);
                break;
            case R.id.allow_duet_layout:
                final CharSequence[] duetoption = {"Everyone", "Friend", "No One", "Cancel"};
                selectimage("Select duet option", duetoption, allowDuetTxt, 4);
                break;
            case R.id.allow_view_likevid_layout:
                final CharSequence[] likevidoption = {"Everyone", "Only Me", "Cancel"};
                selectimage("Select like video option", likevidoption, allowViewLikevidTxt, 5);
                break;

        }
    }

    private void selectimage(String title, final CharSequence[] options, final TextView textView, final int Selected_box) {
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext(), R.style.AlertDialogCustom);
        builder.setTitle(title);
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                CharSequence op = options[item];
                if (!op.equals(cancel)) {
                    textView.setText(("" + options[item]).toUpperCase());

                    switch (Selected_box) {
                        case 1:
                            if (op.toString().equalsIgnoreCase("On")) {
                                strVideoDownload = "1";
                            } else {
                                strVideoDownload = "0";
                            }
                            break;
                        case 2:
                            if (op.toString().equalsIgnoreCase("Everyone")) {
                                strVideoComment = Functions.stringParseIntoServerRestriction("Everyone");
                            } else if (op.toString().equalsIgnoreCase("Friend")) {
                                strVideoComment = Functions.stringParseIntoServerRestriction("Friend");
                            } else {
                                strVideoComment = Functions.stringParseIntoServerRestriction("No One");
                            }
                            break;
                        case 3:
                            if (op.toString().equalsIgnoreCase("Everyone")) {
                                strDirectMessage = Functions.stringParseIntoServerRestriction("Everyone");
                            } else if (op.toString().equalsIgnoreCase("Friend")) {
                                strDirectMessage = Functions.stringParseIntoServerRestriction("Friend");
                            } else {
                                strDirectMessage = Functions.stringParseIntoServerRestriction("No One");
                            }
                            break;
                        case 4:
                            if (op.toString().equalsIgnoreCase("Everyone")) {
                                strDuet = Functions.stringParseIntoServerRestriction("Everyone");
                            } else if (op.toString().equalsIgnoreCase("Friend")) {
                                strDuet = Functions.stringParseIntoServerRestriction("Friend");
                            } else {
                                strDuet = Functions.stringParseIntoServerRestriction("No One");
                            }
                            break;
                        case 5:
                            if (op.toString().equalsIgnoreCase("Everyone")) {
                                strLikedVideo = Functions.stringParseIntoServerRestriction("Everyone");
                            } else {
                                strLikedVideo = Functions.stringParseIntoServerRestriction("Only Me");
                            }

                            break;

                    }
                    callApi();
                }
            }
        });
        builder.show();
    }


    String strVideoDownload, strDirectMessage, strDuet, strLikedVideo, strVideoComment;

    public void callApi() {

        JSONObject params = new JSONObject();
        try {
            params.put("videos_download", strVideoDownload);
            params.put("direct_message", strDirectMessage);
            params.put("duet", strDuet);
            params.put("liked_videos", strLikedVideo);
            params.put("video_comment", strVideoComment);
            params.put("user_id", Functions.getSharedPreference(getContext()).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.addPolicySetting, params, new Callback() {
            @Override
            public void onResponce(String resp) {

                parseData(resp);
            }
        });

    }

    // parse the privacy data for change the ui
    public void parseData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONObject msg = jsonObject.optJSONObject("msg");
                JSONObject privacy_policy_setting = msg.optJSONObject("PrivacySetting");
                privacyPolicySettingModel = new PrivacyPolicySettingModel();
                privacyPolicySettingModel.setVideos_download("" + privacy_policy_setting.optString("videos_download"));
                privacyPolicySettingModel.setDirect_message("" + privacy_policy_setting.optString("direct_message"));
                privacyPolicySettingModel.setDuet("" + privacy_policy_setting.optString("duet"));
                privacyPolicySettingModel.setLiked_videos("" + privacy_policy_setting.optString("liked_videos"));
                privacyPolicySettingModel.setVideo_comment("" + privacy_policy_setting.optString("video_comment"));
                Paper.book("Setting").write("PrivacySettingModel", privacyPolicySettingModel);

                Functions.showToast(view.getContext(), "Privacy Setting Updated");
            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}