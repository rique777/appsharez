package com.qboxus.musictok.ActivitesFragment;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.Adapters.DiscoverAdapter;
import com.qboxus.musictok.Adapters.SlidingAdapter;
import com.qboxus.musictok.Models.DiscoverModel;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.Models.SliderModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ActivitesFragment.Search.SearchMain_F;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.rd.PageIndicatorView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class Discover_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;

    RecyclerView recyclerView;
    EditText searchEdit;


    SwipeRefreshLayout swiperefresh;

    public Discover_F() {
        // Required empty public constructor
    }

    ArrayList<DiscoverModel> datalist;
    DiscoverAdapter adapter;


    PageIndicatorView pageIndicatorView;
    ViewPager viewPager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_discover, container, false);
        context = getContext();


        datalist = new ArrayList<>();


        recyclerView = (RecyclerView) view.findViewById(R.id.recylerview);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);


        adapter = new DiscoverAdapter(context, datalist, new DiscoverAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, ArrayList<HomeModel> home_models, int parent_postion, int child_position) {


                if (view.getId() == R.id.fav_btn) {
                    if (Functions.getSharedPreference(getActivity()).getBoolean(Variables.IS_LOGIN, false)) {
                        callApiFavHashtag(parent_postion);
                    } else {
                        openLogin();
                    }

                } else if (view.getId() == R.id.hashtag_layout || home_models.get(child_position).thum == null) {
                    openHashtag(datalist.get(parent_postion).title);
                } else {
                    openWatchVideo(child_position, home_models);
                }


            }
        });
        recyclerView.setAdapter(adapter);


        searchEdit = view.findViewById(R.id.search_edit);
        searchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                // this method call before text change

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                String query = searchEdit.getText().toString();
                if (adapter != null)
                    adapter.getFilter().filter(query);

            }

            @Override
            public void afterTextChanged(Editable s) {
                // this method call after text change
            }
        });


        viewPager = view.findViewById(R.id.viewPager);
        pageIndicatorView = view.findViewById(R.id.pageIndicatorView);
        swiperefresh = view.findViewById(R.id.swiperefresh);
        swiperefresh.setColorSchemeResources(R.color.black);
        swiperefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                callApiSlider();
                callApiForAllvideos();
            }
        });

        view.findViewById(R.id.search_layout).setOnClickListener(this);
        view.findViewById(R.id.search_edit).setOnClickListener(this);

        callApiForAllvideos();
        callApiSlider();


        return view;
    }


    // get the image of the upper slider in the discover screen
    private void callApiSlider() {

        ApiRequest.callApi(getActivity(), ApiLinks.showAppSlider, new JSONObject(), new Callback() {
            @Override
            public void onResponce(String resp) {
                parseSliderData(resp);
            }
        });

    }


    ArrayList<SliderModel> slider_list = new ArrayList<>();

    public void parseSliderData(String resp) {
        try {
            JSONObject jsonObject = new JSONObject(resp);

            String code = jsonObject.optString("code");
            if (code.equals("200")) {

                slider_list.clear();

                JSONArray msg = jsonObject.optJSONArray("msg");
                for (int i = 0; i < msg.length(); i++) {
                    JSONObject object = msg.optJSONObject(i);
                    JSONObject AppSlider = object.optJSONObject("AppSlider");

                    SliderModel sliderModel = new SliderModel();
                    sliderModel.id = AppSlider.optString("id");
                    sliderModel.image = AppSlider.optString("image");
                    sliderModel.url = AppSlider.optString("url");

                    slider_list.add(sliderModel);
                }

                setSliderAdapter();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void setSliderAdapter() {

        pageIndicatorView.setCount(slider_list.size());
        pageIndicatorView.setSelection(0);

        viewPager.setAdapter(new SlidingAdapter(getActivity(), slider_list, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                String slider_url = slider_list.get(pos).url;
                if (slider_url != null && !slider_url.equals("")) {
                    Webview_F webview_f = new Webview_F();
                    FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                    transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                    Bundle bundle = new Bundle();
                    bundle.putString("url", slider_url);
                    bundle.putString("title", "Link");
                    webview_f.setArguments(bundle);
                    transaction.addToBackStack(null);
                    transaction.replace(R.id.discovery_container, webview_f).commit();
                }
            }
        }));

        pageIndicatorView.setViewPager(viewPager);

    }

    // Bottom two function will get the Discover videos
    // from api and parse the json data which is shown in Discover tab

    private void callApiForAllvideos() {

        JSONObject parameters = new JSONObject();

        ApiRequest.callApi(getActivity(), ApiLinks.showDiscoverySections, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {

                parseData(resp);

                swiperefresh.setRefreshing(false);


            }
        });

    }


    public void parseData(String responce) {

        datalist.clear();

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");
                for (int d = 0; d < msgArray.length(); d++) {

                    JSONObject discover_object = msgArray.optJSONObject(d);
                    JSONObject hashtag = discover_object.optJSONObject("Hashtag");

                    DiscoverModel discover_model = new DiscoverModel();
                    discover_model.id = hashtag.optString("id");
                    discover_model.title = hashtag.optString("name");
                    discover_model.views = hashtag.optString("views");
                    discover_model.videos_count = hashtag.optString("videos_count");
                    discover_model.fav = hashtag.optString("favourite", "0");

                    JSONArray video_array = hashtag.optJSONArray("Videos");

                    ArrayList<HomeModel> video_list = new ArrayList<>();
                    for (int i = 0; i < video_array.length(); i++) {
                        JSONObject itemdata = video_array.optJSONObject(i);

                        JSONObject video = itemdata.optJSONObject("Video");
                        JSONObject user = video.optJSONObject("User");
                        JSONObject sound = video.optJSONObject("Sound");
                        JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                        JSONObject userPushNotification = user.optJSONObject("PushNotification");

                        HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, userPushNotification);


                        video_list.add(item);
                    }

                    if (video_list.size() >= 5)
                        video_list.add(new HomeModel());

                    discover_model.arrayList = video_list;

                    datalist.add(discover_model);

                }

                adapter.notifyDataSetChanged();

            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    // When you click on any Video a new activity is open which will play the Clicked video
    private void openWatchVideo(int postion, ArrayList<HomeModel> data_list) {
        if(data_list.size()>5)
            data_list.remove(data_list.size()-1);

        Intent intent = new Intent(getActivity(), WatchVideos_F.class);
        intent.putExtra("arraylist", data_list);
        intent.putExtra("position", postion);
        startActivity(intent);

    }


    public void openSearch() {

        SearchMain_F search_main_f = new SearchMain_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, search_main_f).commit();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_layout:
                openSearch();
                break;
            case R.id.search_edit:
                openSearch();
                break;
            default:
                return;

        }
    }


    public void callApiFavHashtag(int pos) {

        DiscoverModel item = datalist.get(pos);

        JSONObject params = new JSONObject();
        try {
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
            params.put("hashtag_id", item.id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(context, false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.addHashtagFavourite, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                if (item.fav != null && item.fav.equals("0")) {
                    item.fav = "1";
                } else {
                    item.fav = "0";
                }
                datalist.remove(pos);
                datalist.add(pos, item);
                adapter.notifyDataSetChanged();

            }
        });

    }


    public void openLogin() {
        Intent intent = new Intent(getActivity(), Login_A.class);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
    }


    private void openHashtag(String tag) {

        TagedVideos_F taged_videos_f = new TagedVideos_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("tag", tag);
        taged_videos_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, taged_videos_f).commit();


    }


}
