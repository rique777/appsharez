package com.qboxus.musictok.ActivitesFragment;

import android.os.Bundle;

import androidx.fragment.app.FragmentTransaction;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;


public class SubmitReport_F extends RootFragment implements View.OnClickListener {
    View view;
    TextView reportTypeTxt;
    EditText reportDescriptionTxt;
    String reportId, txtReportType, videoId, userId;
    FragmentCallBack fragmentCallBack;

    public SubmitReport_F() {
    }

    public SubmitReport_F(FragmentCallBack fragmentCallBack) {
        this.fragmentCallBack = fragmentCallBack;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_submit_report, container, false);

        Bundle bundle = getArguments();
        if (bundle != null) {
            reportId = bundle.getString("report_id");
            txtReportType = bundle.getString("report_type");
            videoId = bundle.getString("video_id");
            userId = bundle.getString("user_id");
        }


        reportTypeTxt = view.findViewById(R.id.report_type);
        reportTypeTxt.setText(txtReportType);

        reportDescriptionTxt = view.findViewById(R.id.report_description_txt);


        view.findViewById(R.id.back_btn).setOnClickListener(this);
        view.findViewById(R.id.report_reason_layout).setOnClickListener(this);
        view.findViewById(R.id.submit_btn).setOnClickListener(this);

        return view;
    }


    public boolean checkValidation() {

        if (TextUtils.isEmpty(reportTypeTxt.getText())) {
            Functions.showToast(getContext(), "Please give some reason.");
            return false;
        }

        return true;
    }


    // call the api for report against video
    public void callApiReportVideo() {

        JSONObject params = new JSONObject();
        try {

            params.put("user_id", Functions.getSharedPreference(getContext()).getString(Variables.U_ID, ""));
            params.put("video_id", videoId);
            params.put("report_reason_id", reportId);
            params.put("description", reportDescriptionTxt.getText());

        } catch (JSONException e) {
            e.printStackTrace();
        }


        Functions.showLoader(getContext(), false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.reportVideo, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject jsonObject = new JSONObject(resp);
                    String code = jsonObject.optString("code");
                    if (code.equals("200")) {
                        Functions.showToast(getContext(), "Report submitted successfully");
                        if (fragmentCallBack != null)
                            fragmentCallBack.onResponce(null);

                        getActivity().onBackPressed();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });

    }


    // call the api for report against apis
    public void callApiReportUser() {

        JSONObject params = new JSONObject();
        try {

            params.put("user_id", Functions.getSharedPreference(getContext()).getString(Variables.U_ID, ""));
            params.put("report_user_id", userId);
            params.put("report_reason_id", reportId);
            params.put("description", reportDescriptionTxt.getText());

        } catch (JSONException e) {
            e.printStackTrace();
        }


        Functions.showLoader(getContext(), false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.reportUser, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject jsonObject = new JSONObject(resp);
                    String code = jsonObject.optString("code");
                    if (code.equals("200")) {
                        Functions.showToast(getContext(), "Report submitted successfully");
                        if (fragmentCallBack != null)
                            fragmentCallBack.onResponce(null);

                        getActivity().onBackPressed();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.submit_btn:
                if (videoId != null && checkValidation())
                    callApiReportVideo();

                else if (userId != null && checkValidation())
                    callApiReportUser();

                break;

            case R.id.report_reason_layout:
                ReportType_F _report_typeF = new ReportType_F(true, new FragmentCallBack() {
                    @Override
                    public void onResponce(Bundle resp) {
                        if (resp != null) {
                            String report_reason = resp.getString("reason");
                            reportTypeTxt.setText(report_reason);
                        }
                    }
                });
                Bundle bundle = new Bundle();
                bundle.putString("video_id", videoId);
                bundle.putString("user_id", userId);
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
                transaction.addToBackStack(null);
                transaction.replace(R.id.submit_f, _report_typeF).commit();
                break;

            case R.id.back_btn:
                getActivity().onBackPressed();
                break;
        }
    }


}