package com.qboxus.musictok.ActivitesFragment.Accounts;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Models.UserModel;
import com.qboxus.musictok.MainMenu.MainMenuActivity;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class Login_A extends AppCompatActivity implements View.OnClickListener {


    FirebaseAuth mAuth;
    FirebaseUser firebaseUser;
    SharedPreferences sharedPreferences;
    UserModel userModel = new UserModel();
    View topView;
    long mBackPressed;
    TextView loginTitleTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (Build.VERSION.SDK_INT == 26) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_USER);
        }

        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_login);


        mAuth = FirebaseAuth.getInstance();
        firebaseUser = mAuth.getCurrentUser();

        // if the user is already login trought facebook then we will logout the user automatically
        LoginManager.getInstance().logOut();

        sharedPreferences = getSharedPreferences(Variables.PREF_NAME, MODE_PRIVATE);

        findViewById(R.id.facebook_btn).setOnClickListener(this::onClick);
        findViewById(R.id.email_login_btn).setOnClickListener(this::onClick);
        findViewById(R.id.signUp).setOnClickListener(this::onClick);
        findViewById(R.id.google_btn).setOnClickListener(this::onClick);
        findViewById(R.id.goBack).setOnClickListener(this::onClick);


        topView = findViewById(R.id.top_view);

        loginTitleTxt = findViewById(R.id.login_title_txt);
        loginTitleTxt.setText("You need a " + getString(R.string.app_name) + "\naccount to Continue");


        SpannableString ss = new SpannableString("By signing up, you confirm that you agree to our \n Terms of Use and have read and understood \n our Privacy Policy.");
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View textView) {
                openPrivacyPolicy();
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
            }
        };
        ss.setSpan(clickableSpan, 99, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);


        TextView textView = (TextView) findViewById(R.id.login_terms_condition_txt);
        textView.setText(ss);
        textView.setClickable(true);
        textView.setMovementMethod(LinkMovementMethod.getInstance());


        printKeyHash();


    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.goBack:
                onBackPressed();
                break;

            case R.id.google_btn:
                signInWithGmail();
                break;

            case R.id.signUp:
                openDobFragment("signup");
                break;

            case R.id.email_login_btn:
                EmailPhone_F emailPhoneF = new EmailPhone_F("login");
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user_model", userModel);
                emailPhoneF.setArguments(bundle);
                transaction.addToBackStack(null);
                transaction.replace(R.id.login_f, emailPhoneF).commit();
                break;

            case R.id.facebook_btn:
                Loginwith_FB();
                break;
        }

    }

    public void openPrivacyPolicy() {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.privacy_policy));
        startActivity(browserIntent);
    }


    // this method will be call when activity animation will complete
    @Override
    public void onEnterAnimationComplete() {
        super.onEnterAnimationComplete();

        AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(200);
        topView.startAnimation(anim);
        topView.setVisibility(View.VISIBLE);

    }


    @Override
    public void onBackPressed() {
        int count = this.getSupportFragmentManager().getBackStackEntryCount();
        if (count == 0) {
            if (mBackPressed + 2000 > System.currentTimeMillis()) {
                super.onBackPressed();
                return;
            } else {
                topView.setVisibility(View.GONE);
                finish();
                overridePendingTransition(R.anim.in_from_top, R.anim.out_from_bottom);
            }
        } else {
            super.onBackPressed();
        }
    }


    // Bottom two function are related to Fb implimentation
    private CallbackManager mCallbackManager;

    //facebook implimentation
    public void Loginwith_FB() {

        LoginManager.getInstance()
                .logInWithReadPermissions(Login_A.this,
                        Arrays.asList("public_profile", "email"));


        mCallbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                handleFacebookAccessToken(loginResult.getAccessToken());
                Functions.printLog("resp_token", loginResult.getAccessToken() + "");
            }

            @Override
            public void onCancel() {
                // App code
                Functions.showToast(Login_A.this, "Login Cancel");
            }

            @Override
            public void onError(FacebookException error) {
                Functions.printLog("resp", "" + error.toString());
                Functions.showToast(Login_A.this, "Login Error" + error.toString());
            }

        });


    }

    private void handleFacebookAccessToken(final AccessToken token) {
        // if user is login then this method will call and
        // facebook will return us a token which will user for get the info of user
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        Functions.printLog("resp_token", token.getToken() + "");
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Functions.showLoader(Login_A.this, false, false);
                            final String id = Profile.getCurrentProfile().getId();
                            GraphRequest request = GraphRequest.newMeRequest(token, new GraphRequest.GraphJSONObjectCallback() {
                                @Override
                                public void onCompleted(JSONObject user, GraphResponse graphResponse) {

                                    Functions.cancelLoader();
                                    Functions.printLog("resp", user.toString());
                                    //after get the info of user we will pass to function which will store the info in our server

                                    String fname = "" + user.optString("first_name");
                                    String lname = "" + user.optString("last_name");
                                    String email = "" + user.optString("email");
                                    String auth_token = token.getToken();


                                    userModel = new UserModel();

                                    userModel.fname = Functions.removeSpecialChar(fname);
                                    userModel.email = email;
                                    userModel.lname = Functions.removeSpecialChar(lname);
                                    userModel.socail_id = id;
                                    userModel.socail_type = "facebook";
                                    userModel.auth_tokon = auth_token;


                                    callApiForLogin("" + id,
                                            "facebook",
                                            auth_token);

                                }
                            });

                            // here is the request to facebook sdk for which type of info we have required
                            Bundle parameters = new Bundle();
                            parameters.putString("fields", "last_name,first_name,email");
                            request.setParameters(parameters);
                            request.executeAsync();
                        } else {
                            Functions.cancelLoader();
                            Functions.showToast(Login_A.this, "Authentication failed.");
                        }

                    }
                });
    }


    // call the api for login
    private void callApiForLogin(String socialId, String social, final String authtoken) {

        JSONObject parameters = new JSONObject();
        try {

            parameters.put("social_id", socialId);
            parameters.put("social", "" + social);
            parameters.put("auth_token", "" + authtoken);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(this, false, false);
        ApiRequest.callApi(this, ApiLinks.registerUser, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                parseLoginData(resp, authtoken);

            }
        });


    }

    public void parseLoginData(String loginData, String authtoken) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {

                JSONObject jsonArray = jsonObject.getJSONObject("msg");
                JSONObject userdata = jsonArray.getJSONObject("User");
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(Variables.U_ID, userdata.optString("id"));
                editor.putString(Variables.F_NAME, userdata.optString("first_name"));
                editor.putString(Variables.L_NAME, userdata.optString("last_name"));
                editor.putString(Variables.U_NAME, userdata.optString("username"));
                editor.putString(Variables.GENDER, userdata.optString("gender"));
                editor.putString(Variables.U_PIC, userdata.optString("profile_pic"));
                editor.putString(Variables.U_WALLET, userdata.optString("wallet","0"));
                editor.putString(Variables.U_PAYOUT_ID, userdata.optString("paypal",""));
                editor.putString(Variables.AUTH_TOKEN, authtoken);
                editor.putBoolean(Variables.IS_LOGIN, true);
                editor.commit();

                sendBroadcast(new Intent("newVideo"));


                Variables.reloadMyVideos = true;
                Variables.reloadMyVideosInner = true;
                Variables.reloadMyLikesInner = true;
                Variables.reloadMyNotification = true;
                topView.setVisibility(View.GONE);


                finish();
                startActivity(new Intent(this, MainMenuActivity.class));

            } else if (code.equals("201") && !jsonObject.optString("msg").contains("have been blocked")) {
                openDobFragment("social");
            } else {
                Toast.makeText(this, jsonObject.optString("msg"), Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void openDobFragment(String fromWhere) {
        DateOfBirth_F DOBF = new DateOfBirth_F();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        Bundle bundle = new Bundle();
        bundle.putSerializable("user_model", userModel);
        bundle.putString("fromWhere", fromWhere);
        DOBF.setArguments(bundle);
        transaction.addToBackStack(null);
        transaction.replace(R.id.login_f, DOBF).commit();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        } else if (mCallbackManager != null)
            mCallbackManager.onActivityResult(requestCode, resultCode, data);

        else
            for (Fragment fragment : getSupportFragmentManager().getFragments()) {
                if (fragment instanceof EmailPhone_F) {
                    fragment.onActivityResult(requestCode, resultCode, data);
                }
            }
    }


    //google Implimentation
    GoogleSignInClient mGoogleSignInClient;
    public void signInWithGmail() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.google_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(Login_A.this);

        if (account != null) {

            String id = account.getId();
            String fname = "" + account.getGivenName();
            String lname = "" + account.getFamilyName();
            String email = account.getEmail();
            String auth_tokon = account.getIdToken();

            userModel = new UserModel();
            userModel.fname = Functions.removeSpecialChar(fname);
            userModel.email = email;
            userModel.lname = Functions.removeSpecialChar(lname);
            userModel.socail_id = id;
            userModel.auth_tokon = auth_tokon;


            userModel.socail_type = "google";


            String auth_token = "" + account.getIdToken();


            Functions.printLog(Constants.tag, "signInResult:auth_token===" + auth_token);
            callApiForLogin("" + id,
                    "google",
                    auth_token);

        } else {

            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, 123);

        }

    }


    //Relate to google login
    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            if (account != null) {
                String id = account.getId();
                String fname = "" + account.getGivenName();
                String lname = "" + account.getFamilyName();
                String auth_token = account.getIdToken();
                String email = account.getEmail();

                Functions.printLog(Constants.tag, "signInResult:auth_token =" + auth_token);
                // if we do not get the picture of user then we will use default profile picture


                userModel = new UserModel();

                userModel.fname = fname;
                userModel.email = email;
                userModel.lname = lname;
                userModel.socail_id = id;
                userModel.socail_type = "google";
                userModel.auth_tokon = account.getIdToken();


                callApiForLogin("" + id,
                        "google",
                        auth_token);


            }
        } catch (ApiException e) {
            Functions.printLog("TicTic_log", "signInResult:failed code=" + e.getStatusCode());
        }
    }


    // this will print the keyhash for facebook which will add on facebook developer console
    public void printKeyHash() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.i("keyhash", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

    }


}
