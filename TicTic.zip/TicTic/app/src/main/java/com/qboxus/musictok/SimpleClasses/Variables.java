package com.qboxus.musictok.SimpleClasses;

import android.content.SharedPreferences;
import android.os.Environment;

import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Created by qboxus on 2/15/2019.
 */

public class Variables {


    public Variables() {
    }

    public static final String DEVICE = "android";

    public static int screenWidth;
    public static int screenHeight;

    public static final String SelectedAudio_AAC = "SelectedAudio.aac";


    public static final String APP_HIDED_FOLDER = ".HidedTicTic/";
    public static final String DRAFT_APP_FOLDER = "Draft/";



    public static String is_puchase = "is_puchase";
    public static String streaming_used_time = "streaming_used_time";

    public static String output_frontcamera = APP_HIDED_FOLDER + "output_frontcamera.mp4";
    public static String outputfile = APP_HIDED_FOLDER + "output.mp4";
    public static String outputfile2 = APP_HIDED_FOLDER + "output2.mp4";
    public static String output_filter_file = APP_HIDED_FOLDER + "output-filtered.mp4";
    public static String gallery_trimed_video = APP_HIDED_FOLDER + "gallery_trimed_video.mp4";
    public static String gallery_resize_video = APP_HIDED_FOLDER + "gallery_resize_video.mp4";


    public static SharedPreferences sharedPreferences;
    public static final String PREF_NAME = "pref_name";
    public static final String U_ID = "u_id";
    public static final String U_WALLET = "u_wallet";
    public static final String U_PAYOUT_ID = "u_payout_id";
    public static final String U_NAME = "u_name";
    public static final String U_PIC = "u_pic";
    public static final String F_NAME = "f_name";
    public static final String L_NAME = "l_name";
    public static final String GENDER = "u_gender";
    public static final String IS_LOGIN = "is_login";
    public static final String DEVICE_TOKEN = "device_token";
    public static final String AUTH_TOKEN = "api_token";
    public static final String DEVICE_ID = "device_id";
    public static final String UPLOADING_VIDEO_THUMB = "uploading_video_thumb";
    public static final String IsExtended = "IsExtended";




    public static String selectedSoundId = "null";
    public static boolean reloadMyVideos = false;
    public static boolean reloadMyVideosInner = false;
    public static boolean reloadMyLikesInner = false;
    public static boolean reloadMyNotification = false;


    public static final String GIF_FIRSTPART = "https://media.giphy.com/media/";
    public static final String GIF_SECONDPART = "/100w.gif";


    public static final String http = "http";

    public static final SimpleDateFormat df =
            new SimpleDateFormat("dd-MM-yyyy HH:mm:ssZZ", Locale.ENGLISH);

    public static final SimpleDateFormat df2 =
            new SimpleDateFormat("dd-MM-yyyy HH:mmZZ", Locale.ENGLISH);


    public final static int PERMISSION_CAMERA_CODE = 786;
    public final static int PERMISSION_WRITE_DATA = 788;
    public final static int PERMISSION_READ_DATA = 789;
    public final static int PERMISSION_RECORDING_AUDIO = 790;
    public final static int PICK_VIDEO_FROM_GALLERY = 791;


}
