package com.qboxus.musictok.ActivitesFragment.Profile;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.qboxus.musictok.ActivitesFragment.LiveStreaming.activities.StreamingMain_A;
import com.qboxus.musictok.ActivitesFragment.My_Wallet.MyWallet;
import com.qboxus.musictok.ActivitesFragment.My_Wallet.WalletPayment;
import com.qboxus.musictok.ActivitesFragment.Profile.PrivateVideos.PrivateVideo_F;
import com.qboxus.musictok.ActivitesFragment.Setting_F;
import com.qboxus.musictok.ActivitesFragment.Webview_F;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.google.android.material.tabs.TabLayout;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qboxus.musictok.ActivitesFragment.Following_F;
import com.qboxus.musictok.MainMenu.MainMenuActivity;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.ActivitesFragment.Profile.LikedVideos.LikedVideo_F;
import com.qboxus.musictok.ActivitesFragment.Profile.UserVideos.UserVideo_F;
import com.qboxus.musictok.Models.PrivacyPolicySettingModel;
import com.qboxus.musictok.Models.PushNotificationSettingModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ActivitesFragment.SeeFullImage_F;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.qboxus.musictok.ActivitesFragment.VideoRecording.DraftVideos_A;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.function.Function;

import io.paperdb.Paper;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileTab_F extends RootFragment implements View.OnClickListener {
    View view;
    Context context;
    private TextView username, username2Txt, videoCountTxt;
    private SimpleDraweeView imageView;
    private TextView followCountTxt, fansCountTxt, heartCountTxt, draftCountTxt;

    ImageView settingBtn;


    protected TabLayout tabLayout;

    protected ViewPager pager;

    private ViewPagerAdapter adapter;

    RelativeLayout tabsMainLayout;

    LinearLayout topLayout;

    private String picUrl;
    private LinearLayout createPopupLayout;

    private int myvideoCount = 0;

    PushNotificationSettingModel pushNotificationSettingModel;
    PrivacyPolicySettingModel privacyPolicySettingModel;

    public ProfileTab_F() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_profile_tab, container, false);
        context = getContext();


        return init();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.live_btn:
                String user_id = Functions.getSharedPreference(context).getString(Variables.U_ID, "");
                String user_name = Functions.getSharedPreference(context).getString(Variables.F_NAME, "") + " " +
                        Functions.getSharedPreference(context).getString(Variables.L_NAME, "");
                String user_image = Functions.getSharedPreference(context).getString(Variables.U_PIC, "");

                openTicticLive(user_id, user_name, user_image, io.agora.rtc.Constants.CLIENT_ROLE_BROADCASTER);
                break;


            case R.id.user_image:
                openfullsizeImage(picUrl);
                break;

            case R.id.message_btn:
                openMenuTab(settingBtn);
                break;

            case R.id.following_layout:
                openFollowing();
                break;


            case R.id.fans_layout:
                openFollowers();
                break;

            case R.id.draft_btn:
                Intent upload_intent = new Intent(getActivity(), DraftVideos_A.class);
                startActivity(upload_intent);
                getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                break;

        }
    }


    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        if ((view != null && visible)) {

            if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false)) {
                updateProfile();

                callApiForGetAllvideos();

            }
        }

    }


    @Override
    public void onResume() {
        super.onResume();
        showDraftCount();

    }

    private View init() {


        view.findViewById(R.id.live_btn).setOnClickListener(this::onClick);

        username = view.findViewById(R.id.username);
        username2Txt = view.findViewById(R.id.username2_txt);
        imageView = view.findViewById(R.id.user_image);
        imageView.setOnClickListener(this);

        videoCountTxt = view.findViewById(R.id.video_count_txt);

        followCountTxt = view.findViewById(R.id.follow_count_txt);
        fansCountTxt = view.findViewById(R.id.fan_count_txt);
        heartCountTxt = view.findViewById(R.id.heart_count_txt);
        draftCountTxt = view.findViewById(R.id.draft_count_txt);

        showDraftCount();

        settingBtn = view.findViewById(R.id.message_btn);
        settingBtn.setOnClickListener(this);


        tabLayout = (TabLayout) view.findViewById(R.id.tabs);
        pager = view.findViewById(R.id.pager);
        pager.setOffscreenPageLimit(3);

        adapter = new ViewPagerAdapter(getChildFragmentManager());
        pager.setAdapter(adapter);
        tabLayout.setupWithViewPager(pager);

        setupTabIcons();


        tabsMainLayout = view.findViewById(R.id.tabs_main_layout);
        topLayout = view.findViewById(R.id.top_layout);


        ViewTreeObserver observer = topLayout.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {

                final int height = topLayout.getMeasuredHeight();

                topLayout.getViewTreeObserver().removeOnGlobalLayoutListener(
                        this);

                ViewTreeObserver observer = tabsMainLayout.getViewTreeObserver();
                observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @Override
                    public void onGlobalLayout() {

                        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tabsMainLayout.getLayoutParams();
                        params.height = (int) (tabsMainLayout.getMeasuredHeight() + height);
                        tabsMainLayout.setLayoutParams(params);
                        tabsMainLayout.getViewTreeObserver().removeOnGlobalLayoutListener(
                                this);

                    }
                });

            }
        });


        createPopupLayout = view.findViewById(R.id.create_popup_layout);


        view.findViewById(R.id.following_layout).setOnClickListener(this);
        view.findViewById(R.id.fans_layout).setOnClickListener(this);

        return view;
    }

    public void showDraftCount() {
        try {

            String path = Functions.getAppFolder(context)+Variables.DRAFT_APP_FOLDER;
            File directory = new File(path);
            File[] files = directory.listFiles();
            draftCountTxt.setText("" + files.length);
            if (files.length <= 0) {
                view.findViewById(R.id.draft_btn).setVisibility(View.GONE);
            } else {
                view.findViewById(R.id.draft_btn).setVisibility(View.VISIBLE);
                view.findViewById(R.id.draft_btn).setOnClickListener(this);
            }
        } catch (Exception e) {
            view.findViewById(R.id.draft_btn).setVisibility(View.GONE);
        }
    }


    // place the profile data
    private void updateProfile() {
        username2Txt.setText(Functions.getSharedPreference(context).getString(Variables.U_NAME, ""));

        String firstName = Functions.getSharedPreference(context).getString(Variables.F_NAME, "");
        String lastName = Functions.getSharedPreference(context).getString(Variables.L_NAME, "");
        if (firstName.equalsIgnoreCase("") && lastName.equalsIgnoreCase("")) {
            username.setText(Functions.getSharedPreference(context).getString(Variables.U_NAME, ""));
        } else {
            username.setText(firstName + " " + lastName);
        }


        picUrl = Functions.getSharedPreference(context).getString(Variables.U_PIC, "null");

        if (!picUrl.contains(Variables.http)) {
            picUrl = Constants.BASE_URL + picUrl;
        }

        if (picUrl != null && !picUrl.equals("")) {
            Uri uri = Uri.parse(picUrl);
            imageView.setImageURI(uri);
        }


    }


    // change the icons of the tab
    private void setupTabIcons() {

        View view1 = LayoutInflater.from(context).inflate(R.layout.item_tabs_profile_menu, null);
        ImageView imageView1 = view1.findViewById(R.id.image);
        imageView1.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_video_color));
        tabLayout.getTabAt(0).setCustomView(view1);

        View view2 = LayoutInflater.from(context).inflate(R.layout.item_tabs_profile_menu, null);
        ImageView imageView2 = view2.findViewById(R.id.image);
        imageView2.setImageDrawable(getResources().getDrawable(R.drawable.ic_liked_video_gray));
        tabLayout.getTabAt(1).setCustomView(view2);

        View view3 = LayoutInflater.from(context).inflate(R.layout.item_tabs_profile_menu, null);
        ImageView imageView3 = view3.findViewById(R.id.image);
        imageView3.setImageDrawable(getResources().getDrawable(R.drawable.ic_lock_gray));
        tabLayout.getTabAt(2).setCustomView(view3);


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {


            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View v = tab.getCustomView();
                ImageView image = v.findViewById(R.id.image);

                switch (tab.getPosition()) {
                    case 0:

                        if (myvideoCount > 0) {
                            createPopupLayout.setVisibility(View.GONE);
                        } else {
                            createPopupLayout.setVisibility(View.VISIBLE);
                            Animation aniRotate = AnimationUtils.loadAnimation(context, R.anim.up_and_down_animation);
                            createPopupLayout.startAnimation(aniRotate);
                        }

                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_video_color));
                        break;

                    case 1:
                        createPopupLayout.clearAnimation();
                        createPopupLayout.setVisibility(View.GONE);
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_liked_video_color));
                        break;

                    case 2:
                        createPopupLayout.clearAnimation();
                        createPopupLayout.setVisibility(View.GONE);
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_lock_black));
                        break;
                }
                tab.setCustomView(v);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View v = tab.getCustomView();
                ImageView image = v.findViewById(R.id.image);

                switch (tab.getPosition()) {
                    case 0:
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_video_gray));
                        break;
                    case 1:
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_liked_video_gray));
                        break;

                    case 2:
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_lock_gray));
                        break;
                }

                tab.setCustomView(v);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });


    }


    class ViewPagerAdapter extends FragmentPagerAdapter {

        SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();


        public ViewPagerAdapter(FragmentManager fm) {
            super(fm, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {
            final Fragment result;
            switch (position) {
                case 0:
                    result = new UserVideo_F(true, Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
                    break;
                case 1:
                    result = new LikedVideo_F(true, Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
                    break;

                case 2:
                    result = new PrivateVideo_F();
                    break;

                default:
                    result = null;
                    break;
            }

            return result;
        }

        @Override
        public int getCount() {
            return 3;
        }


        @Override
        public CharSequence getPageTitle(final int position) {
            return null;
        }


        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            Fragment fragment = (Fragment) super.instantiateItem(container, position);
            registeredFragments.put(position, fragment);
            return fragment;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            registeredFragments.remove(position);
            super.destroyItem(container, position, object);
        }


        /**
         * Get the Fragment by position
         *
         * @param position tab position of the fragment
         * @return
         */
        public Fragment getRegisteredFragment(int position) {
            return registeredFragments.get(position);
        }


    }


    //this will get the all videos data of user and then parse the data
    private void callApiForGetAllvideos() {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.showUserDetail, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                parseData(resp);
            }
        });


    }

    public void parseData(String responce) {


        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {


                JSONObject msg = jsonObject.optJSONObject("msg");

                JSONObject user = msg.optJSONObject("User");
                JSONObject pushNotificationSetting = msg.optJSONObject("PushNotification");
                JSONObject privacyPolicySetting = msg.optJSONObject("PrivacySetting");


                pushNotificationSettingModel = new PushNotificationSettingModel();
                if (pushNotificationSetting != null) {
                    pushNotificationSettingModel.setComments("" + pushNotificationSetting.optString("comments"));
                    pushNotificationSettingModel.setLikes("" + pushNotificationSetting.optString("likes"));
                    pushNotificationSettingModel.setNewfollowers("" + pushNotificationSetting.optString("new_followers"));
                    pushNotificationSettingModel.setMentions("" + pushNotificationSetting.optString("mentions"));
                    pushNotificationSettingModel.setDirectmessage("" + pushNotificationSetting.optString("direct_messages"));
                    pushNotificationSettingModel.setVideoupdates("" + pushNotificationSetting.optString("video_updates"));
                }

                privacyPolicySettingModel = new PrivacyPolicySettingModel();
                if (privacyPolicySetting != null) {
                    privacyPolicySettingModel.setVideos_download("" + privacyPolicySetting.optString("videos_download"));
                    privacyPolicySettingModel.setDirect_message("" + privacyPolicySetting.optString("direct_message"));
                    privacyPolicySettingModel.setDuet("" + privacyPolicySetting.optString("duet"));
                    privacyPolicySettingModel.setLiked_videos("" + privacyPolicySetting.optString("liked_videos"));
                    privacyPolicySettingModel.setVideo_comment("" + privacyPolicySetting.optString("video_comment"));
                }

                Paper.book("Setting").write("PushSettingModel", pushNotificationSettingModel);
                Paper.book("Setting").write("PrivacySettingModel", privacyPolicySettingModel);

                username2Txt.setText(user.optString("username"));

                String firstName = user.optString("first_name", "");
                String lastName = user.optString("last_name", "");

                if (firstName.equalsIgnoreCase("") && lastName.equalsIgnoreCase("")) {
                    username.setText(user.optString("username"));
                } else {
                    username.setText(firstName + " " + lastName);
                }

                picUrl = user.optString("profile_pic");

                if (!picUrl.contains(Variables.http)) {
                    picUrl = Constants.BASE_URL + picUrl;
                }


                Uri uri = Uri.parse(picUrl);
                imageView.setImageURI(uri);

                Functions.printLog(Constants.tag,picUrl);

                Functions.getSharedPreference(context).edit().putString(Variables.U_PIC, picUrl).commit();


                followCountTxt.setText(user.optString("following_count"));
                fansCountTxt.setText(user.optString("followers_count"));
                heartCountTxt.setText(user.optString("likes_count"));

                myvideoCount = Functions.parseInterger(user.optString("video_count", "0"));
                videoCountTxt.setText(user.optString("video_count") + " videos");

                if (myvideoCount != 0) {
                    createPopupLayout.setVisibility(View.GONE);
                    createPopupLayout.clearAnimation();
                } else {

                    createPopupLayout.setVisibility(View.VISIBLE);
                    Animation aniRotate = AnimationUtils.loadAnimation(context, R.anim.up_and_down_animation);
                    createPopupLayout.startAnimation(aniRotate);

                }


                String verified = user.optString("verified");
                if (verified != null && verified.equalsIgnoreCase("1")) {
                    view.findViewById(R.id.varified_btn).setVisibility(View.VISIBLE);
                }


            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void openEditProfile() {
        EditProfile_F edit_profile_f = new EditProfile_F(new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {

                updateProfile();
            }
        });
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, edit_profile_f).commit();
    }

    private void openSetting() {
        Setting_F setting_f = new Setting_F();
        Bundle bundle = new Bundle();
        setting_f.setArguments(bundle);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, setting_f).commit();
    }

    private void openPayout() {
        WalletPayment payout_f = new WalletPayment();
        Bundle bundle = new Bundle();
        payout_f.setArguments(bundle);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, payout_f).commit();
    }


    private void openUrl(String Link, String title) {
        Webview_F webview_f = new Webview_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
        Bundle bundle = new Bundle();
        bundle.putString("url", Link);
        bundle.putString("title", title);
        webview_f.setArguments(bundle);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, webview_f).commit();
    }

    //this method will get the big size of profile image.
    private void openfullsizeImage(String url) {
        SeeFullImage_F see_image_f = new SeeFullImage_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);
        Bundle args = new Bundle();
        args.putSerializable("image_url", url);
        see_image_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, see_image_f).commit();
    }

    private void openMenuTab(View anchor_view) {
        Context wrapper = new ContextThemeWrapper(context, R.style.AlertDialogCustom);
        PopupMenu popup = new PopupMenu(wrapper, anchor_view);

        if(Functions.getSharedPreference(context).getBoolean(Variables.IsExtended,false))
        popup.getMenuInflater().inflate(R.menu.menu_extended, popup.getMenu());
        else
            popup.getMenuInflater().inflate(R.menu.menu, popup.getMenu());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            popup.setGravity(Gravity.TOP | Gravity.RIGHT);
        }
        popup.show();
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {

                    case R.id.edit_Profile_id:
                        openEditProfile();
                        break;
                    case R.id.wallet_id:
                    {
                        startActivity(new Intent(getActivity(), MyWallet.class));
                    }
                    break;
                    case R.id.payout_id:
                    {
                        openPayout();
                    }
                    break;
                    case R.id.favourite_id:
                        openFavouriteVideos();
                        break;


                    case R.id.promotion_id:
                        openUrl(ApiLinks.pastPromotions + Functions.getSharedPreference(getContext()).getString(Variables.U_ID, "0"), "Promotions");
                        break;


                    case R.id.setting_id:
                        openSetting();
                        break;

                    case R.id.logout_id:
                        logout();
                        break;
                }
                return true;
            }
        });

    }

    // open the favourite videos fragment
    private void openFavouriteVideos() {
        FavouriteMain_F favourite_main_f = new FavouriteMain_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, favourite_main_f).commit();
    }

    // open the following fragment
    private void openFollowing() {

        Following_F following_f = new Following_F(new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {

                callApiForGetAllvideos();

            }
        });
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
        args.putString("from_where", "following");
        following_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, following_f).commit();

    }


    // open the followers fragment
    private void openFollowers() {
        Following_F following_f = new Following_F(new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {
                callApiForGetAllvideos();
            }
        });
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
        args.putString("from_where", "fan");
        following_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.mainMenuFragment, following_f).commit();

    }

    // this will erase all the user info store in locally and logout the user
    public void logout() {

        JSONObject params = new JSONObject();
        try {
            params.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(getActivity(), ApiLinks.logout, params, new Callback() {
            @Override
            public void onResponce(String resp) {

                try {
                    JSONObject jsonObject = new JSONObject(resp);
                    String code = jsonObject.optString("code");

                    if (code.equalsIgnoreCase("200")) {
                        Paper.book("Setting").destroy();

                        GoogleSignInOptions gso = new GoogleSignInOptions.
                                Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).
                                build();
                        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient(getActivity(), gso);
                        googleSignInClient.signOut();

                        LoginManager.getInstance().logOut();

                        SharedPreferences.Editor editor = Functions.getSharedPreference(context).edit();
                        editor.putString(Variables.U_ID, "");
                        editor.putString(Variables.U_NAME, "");
                        editor.putString(Variables.U_PIC, "");
                        editor.putString(Variables.U_WALLET, "0");
                        editor.putString(Variables.U_PAYOUT_ID, "");
                        editor.putString(Variables.AUTH_TOKEN, null);
                        editor.putBoolean(Variables.IS_LOGIN, false);
                        editor.commit();
                        getActivity().finish();
                        startActivity(new Intent(getActivity(), MainMenuActivity.class));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });

    }


    // open the live streaming
    public void openTicticLive(String user_id, String user_name, String user_image, int role) {

        if (checkPermissions()) {

            Intent intent = new Intent(getActivity(), StreamingMain_A.class);
            intent.putExtra("user_id", user_id);
            intent.putExtra("user_name", user_name);
            intent.putExtra("user_picture", user_image);
            intent.putExtra("user_role", role);
            startActivity(intent);

        }
    }


    // check the permission of camera and audio
    public boolean checkPermissions() {

        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
        };

        if (!hasPermissions(context, PERMISSIONS)) {
            requestPermissions(PERMISSIONS, 2);
        } else {

            return true;
        }

        return false;
    }

    private static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    @Override
    public void onDetach() {
        super.onDetach();
        Functions.deleteCache(context);
    }


}
