package com.qboxus.musictok.ActivitesFragment.Accounts;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.qboxus.musictok.Models.UserModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;

public class CreatePassword_F extends Fragment {
    View view;
    EditText passwordEdt;
    Button btnPass;
    UserModel userModel;
    String fromWhere, stEmail;

    public CreatePassword_F(String fromWhere) {
        this.fromWhere = fromWhere;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_create_password, container, false);
        Bundle bundle = getArguments();
        userModel = (UserModel) bundle.getSerializable("user_model");
        stEmail = bundle.getString("email");

        view.findViewById(R.id.goBack).setOnClickListener(v -> {
            getActivity().onBackPressed();

        });

        passwordEdt = view.findViewById(R.id.password_edt);
        btnPass = view.findViewById(R.id.btn_pass);
        passwordEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                //check the password lenght
                String txtName = passwordEdt.getText().toString();
                if (txtName.length() > 0) {
                    btnPass.setEnabled(true);
                    btnPass.setClickable(true);
                } else {
                    btnPass.setEnabled(false);
                    btnPass.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        //check validation and then open the username for get the username from user
        btnPass.setOnClickListener(v -> {
            if (checkValidation()) {
                CreateUsername_F user_name_f = new CreateUsername_F(fromWhere);
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                Bundle bundle2 = new Bundle();
                userModel.password = passwordEdt.getText().toString();
                bundle2.putSerializable("user_model", userModel);
                user_name_f.setArguments(bundle2);
                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                transaction.addToBackStack(null);
                transaction.replace(R.id.pass_f, user_name_f).commit();
            }

        });

        return view;
    }

    // this will check the validations like none of the field can be the empty
    public boolean checkValidation() {

        String password = passwordEdt.getText().toString();
        if (TextUtils.isEmpty(password) || password.length() < 2) {
            Functions.showToast(getActivity(), "Please enter password");
            return false;
        }

        return true;
    }


}