package com.qboxus.musictok.ActivitesFragment.Profile;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.Callback;
import com.google.android.material.tabs.TabLayout;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qboxus.musictok.ActivitesFragment.Chat.ChatActivity;
import com.qboxus.musictok.ActivitesFragment.Following_F;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.ActivitesFragment.Profile.LikedVideos.LikedVideo_F;
import com.qboxus.musictok.ActivitesFragment.Profile.UserVideos.UserVideo_F;
import com.qboxus.musictok.Models.PrivacyPolicySettingModel;
import com.qboxus.musictok.Models.PushNotificationSettingModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ActivitesFragment.SeeFullImage_F;
import com.qboxus.musictok.Interfaces.APICallBack;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


// This is the profile screen which is show in 5 tab as well as it is also call
// when we see the profile of other users

public class Profile_F extends RootFragment implements View.OnClickListener {

    View view;
    Context context;


    public TextView followUnfollowBtn;
    public TextView username, username2Txt, videoCountTxt;
    public SimpleDraweeView imageView;
    public TextView followCountTxt, fansCountTxt, heartCountTxt;

    ImageView backBtn, messageBtn;

    String userId, userName, userPic;

    Bundle bundle;

    protected TabLayout tabLayout;

    protected ViewPager pager;
    private ViewPagerAdapter adapter;
    public boolean isdataload = false;
    RelativeLayout tabsMainLayout;

    LinearLayout topLayout, tabPraivacyLikes;

    public String picUrl;


    public Profile_F() {

    }


    FragmentCallBack fragment_callback;

    @SuppressLint("ValidFragment")
    public Profile_F(FragmentCallBack fragment_callback) {
        this.fragment_callback = fragment_callback;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_profile, container, false);
        context = getContext();

        getActivity();

        bundle = getArguments();
        if (bundle != null) {
            userId = bundle.getString("user_id");
            userName = bundle.getString("user_name");
            userPic = bundle.getString("user_pic");
        }


        return init();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.user_image:
                openfullsizeImage(picUrl);
                break;

            case R.id.follow_unfollow_btn:

                if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false))
                    followUnFollowUser();
                else {

                    Intent intent = new Intent(getActivity(), Login_A.class);
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                }
                break;

            case R.id.message_btn:
                openSetting();
                break;

            case R.id.following_layout:
                openFollowing();
                break;

            case R.id.fans_layout:
                openFollowers();
                break;

            case R.id.back_btn:
                getActivity().onBackPressed();
                break;
        }
    }


    public View init() {

        username = view.findViewById(R.id.username);
        username2Txt = view.findViewById(R.id.username2_txt);
        imageView = view.findViewById(R.id.user_image);
        imageView.setOnClickListener(this);
        tabPraivacyLikes = view.findViewById(R.id.tab_privacy_likes);
        videoCountTxt = view.findViewById(R.id.video_count_txt);

        followCountTxt = view.findViewById(R.id.follow_count_txt);
        fansCountTxt = view.findViewById(R.id.fan_count_txt);
        heartCountTxt = view.findViewById(R.id.heart_count_txt);


        messageBtn = view.findViewById(R.id.message_btn);
        messageBtn.setOnClickListener(this);

        backBtn = view.findViewById(R.id.back_btn);
        backBtn.setOnClickListener(this);

        followUnfollowBtn = view.findViewById(R.id.follow_unfollow_btn);
        followUnfollowBtn.setOnClickListener(this);


        tabLayout = (TabLayout) view.findViewById(R.id.tabs);
        pager = view.findViewById(R.id.pager);
        pager.setOffscreenPageLimit(2);


        tabsMainLayout = view.findViewById(R.id.tabs_main_layout);
        topLayout = view.findViewById(R.id.top_layout);


        ViewTreeObserver observer = topLayout.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {

                final int height = topLayout.getMeasuredHeight();

                topLayout.getViewTreeObserver().removeOnGlobalLayoutListener(
                        this);

                ViewTreeObserver observer = tabsMainLayout.getViewTreeObserver();
                observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @Override
                    public void onGlobalLayout() {

                        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tabsMainLayout.getLayoutParams();
                        params.height = (int) (tabsMainLayout.getMeasuredHeight() + height);
                        tabsMainLayout.setLayoutParams(params);
                        tabsMainLayout.getViewTreeObserver().removeOnGlobalLayoutListener(
                                this);

                    }
                });

            }
        });


        view.findViewById(R.id.following_layout).setOnClickListener(this);
        view.findViewById(R.id.fans_layout).setOnClickListener(this);

        isdataload = true;


        if (userId != null)
            setupTabIcons();


        callApiForGetAllvideos();


        return view;
    }


    @Override
    public void onResume() {
        super.onResume();

        if (isRunFirstTime) {

            callApiForGetAllvideos();

        }

    }


    private void setupTabIcons() {

        adapter = new ViewPagerAdapter(getChildFragmentManager());
        pager.setAdapter(adapter);
        tabLayout.setupWithViewPager(pager);

        View view1 = LayoutInflater.from(context).inflate(R.layout.item_tabs_profile_menu, null);
        ImageView imageView1 = view1.findViewById(R.id.image);
        imageView1.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_video_color));
        tabLayout.getTabAt(0).setCustomView(view1);

        View view2 = LayoutInflater.from(context).inflate(R.layout.item_tabs_profile_menu, null);
        ImageView imageView2 = view2.findViewById(R.id.image);
        imageView2.setImageDrawable(getResources().getDrawable(R.drawable.ic_liked_video_gray));
        tabLayout.getTabAt(1).setCustomView(view2);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {


            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View v = tab.getCustomView();
                ImageView image = v.findViewById(R.id.image);

                switch (tab.getPosition()) {
                    case 0:

                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_video_color));
                        break;

                    case 1:
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_liked_video_color));
                        break;
                }
                tab.setCustomView(v);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View v = tab.getCustomView();
                ImageView image = v.findViewById(R.id.image);

                switch (tab.getPosition()) {
                    case 0:
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_video_gray));
                        break;
                    case 1:
                        image.setImageDrawable(getResources().getDrawable(R.drawable.ic_liked_video_gray));
                        break;
                }

                tab.setCustomView(v);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });


    }


    class ViewPagerAdapter extends FragmentPagerAdapter {


        SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();


        private ViewPagerAdapter(FragmentManager fm) {
            super(fm, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {
            final Fragment result;
            switch (position) {
                case 0:
                    result = new UserVideo_F(false, userId);
                    break;
                case 1:
                    result = new LikedVideo_F(false, userId);
                    break;

                default:
                    result = null;
                    break;
            }

            return result;
        }

        @Override
        public int getCount() {
            return 2;
        }


        @Override
        public CharSequence getPageTitle(final int position) {
            return null;
        }


        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            Fragment fragment = (Fragment) super.instantiateItem(container, position);
            registeredFragments.put(position, fragment);
            return fragment;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            registeredFragments.remove(position);
            super.destroyItem(container, position, object);
        }


    }


    // get the profile details of user
    boolean isRunFirstTime = false;

    private void callApiForGetAllvideos() {

        if (bundle == null) {
            userId = Functions.getSharedPreference(context).getString(Variables.U_ID, "0");
        }

        JSONObject parameters = new JSONObject();
        try {

            if (Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false) && userId != null) {
                parameters.put("user_id", Functions.getSharedPreference(context).getString(Variables.U_ID, ""));
                parameters.put("other_user_id", userId);
            } else if (userId != null) {
                parameters.put("user_id", userId);
            } else {
                parameters.put("username", userName);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


        ApiRequest.callApi(getActivity(), ApiLinks.showUserDetail, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                isRunFirstTime = true;
                parseData(resp);
            }
        });

    }


    public void parseData(String responce) {

        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONObject msg = jsonObject.optJSONObject("msg");

                JSONObject user = msg.optJSONObject("User");
                JSONObject push_notification_setting = msg.optJSONObject("PushNotification");
                JSONObject privacy_policy_setting = msg.optJSONObject("PrivacySetting");

                if (userId == null) {
                    userId = user.optString("id");
                    setupTabIcons();
                }

                String first_name = user.optString("first_name", "");
                String last_name = user.optString("last_name", "");

                if (first_name.equalsIgnoreCase("") && last_name.equalsIgnoreCase("")) {
                    username.setText(user.optString("username"));
                } else {
                    username.setText(first_name + " " + last_name);
                }

                username2Txt.setText(user.optString("username"));

                picUrl = user.optString("profile_pic");
                if (!picUrl.contains(Variables.http)) {
                    picUrl = Constants.BASE_URL + picUrl;
                }


                if (picUrl != null && !picUrl.equals("")) {
                    Uri uri = Uri.parse(picUrl);
                    imageView.setImageURI(uri);
                }

                followCountTxt.setText(user.optString("following_count"));
                fansCountTxt.setText(user.optString("followers_count"));
                heartCountTxt.setText(user.optString("likes_count"));

                PushNotificationSettingModel pushNotificationSetting_model = new PushNotificationSettingModel();
                pushNotificationSetting_model.setComments("" + push_notification_setting.optString("comments"));
                pushNotificationSetting_model.setLikes("" + push_notification_setting.optString("likes"));
                pushNotificationSetting_model.setNewfollowers("" + push_notification_setting.optString("new_followers"));
                pushNotificationSetting_model.setMentions("" + push_notification_setting.optString("mentions"));
                pushNotificationSetting_model.setDirectmessage("" + push_notification_setting.optString("direct_messages"));
                pushNotificationSetting_model.setVideoupdates("" + push_notification_setting.optString("video_updates"));


                PrivacyPolicySettingModel privacyPolicySetting_model = new PrivacyPolicySettingModel();
                privacyPolicySetting_model.setVideos_download("" + privacy_policy_setting.optString("videos_download"));
                privacyPolicySetting_model.setDirect_message("" + privacy_policy_setting.optString("direct_message"));
                privacyPolicySetting_model.setDuet("" + privacy_policy_setting.optString("duet"));
                privacyPolicySetting_model.setLiked_videos("" + privacy_policy_setting.optString("liked_videos"));
                privacyPolicySetting_model.setVideo_comment("" + privacy_policy_setting.optString("video_comment"));

                if (Functions.isShowContentPrivacy(context, privacyPolicySetting_model.getLiked_videos(),
                        privacy_policy_setting.optString("liked_videos").toLowerCase().equalsIgnoreCase("friends"))) {

                    tabLayout.getTabAt(1).view.setClickable(true);
                    tabPraivacyLikes.setVisibility(View.VISIBLE);
                } else {
                    tabLayout.getTabAt(1).view.setClickable(false);
                    tabPraivacyLikes.setVisibility(View.GONE);
                }


                if (Functions.isShowContentPrivacy(context, privacyPolicySetting_model.getDirect_message(),
                        user.optString("button").toLowerCase().equalsIgnoreCase("friends"))) {
                    messageBtn.setVisibility(View.VISIBLE);
                } else {
                    messageBtn.setVisibility(View.GONE);
                }


                String follow_status = user.optString("button");
                if (!user.optString("id").
                        equals(Functions.getSharedPreference(context).getString(Variables.U_ID, ""))) {

                    followUnfollowBtn.setVisibility(View.VISIBLE);

                    if (follow_status.equalsIgnoreCase("following")) {
                        followUnfollowBtn.setText("UnFollow");
                    } else if (follow_status.equalsIgnoreCase("friends")) {
                        followUnfollowBtn.setVisibility(View.GONE);
                    } else {
                        followUnfollowBtn.setText("Follow");
                    }


                }


                videoCountTxt.setText(user.optString("video_count") + " videos");
                String verified = user.optString("verified");
                if (verified != null && verified.equalsIgnoreCase("1")) {
                    view.findViewById(R.id.varified_btn).setVisibility(View.VISIBLE);
                }


            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void openSetting() {

        if (Functions.getSharedPreference(context)
                .getBoolean(Variables.IS_LOGIN, false)) {

            openChatF();

        } else {
            Intent intent = new Intent(getActivity(), Login_A.class);
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);

        }

    }


    private void followUnFollowUser() {
        Functions.callApiForFollowUnFollow(getActivity(),
                Functions.getSharedPreference(context).getString(Variables.U_ID, ""),
                userId,
                new APICallBack() {
                    @Override
                    public void arrayData(ArrayList arrayList) {
                    }

                    @Override
                    public void onSuccess(String responce) {

                        callApiForGetAllvideos();
                    }

                    @Override
                    public void onFail(String responce) {

                    }

                });

    }


    //this method will get the big size of profile image.
    private void openfullsizeImage(String url) {
        SeeFullImage_F see_image_f = new SeeFullImage_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);
        Bundle args = new Bundle();
        args.putSerializable("image_url", url);
        see_image_f.setArguments(args);
        transaction.addToBackStack(null);

        View view = getActivity().findViewById(R.id.mainMenuFragment);
        if (view != null)
            transaction.replace(R.id.mainMenuFragment, see_image_f).commit();
        else
            transaction.replace(R.id.profile_F, see_image_f).commit();


    }


    // open the chat screen
    private void openChatF() {

        ChatActivity chat_activity = new ChatActivity(new FragmentCallBack() {
            @Override
            public void onResponce(Bundle bundle) {

            }
        });
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("user_id", userId);
        args.putString("user_name", userName);
        args.putString("user_pic", userPic);
        chat_activity.setArguments(args);
        transaction.addToBackStack(null);

        View view = getActivity().findViewById(R.id.mainMenuFragment);
        if (view != null)
            transaction.replace(R.id.mainMenuFragment, chat_activity).commit();
        else
            transaction.replace(R.id.profile_F, chat_activity).commit();

    }


    // open the following screen
    private void openFollowing() {

        Following_F following_f = new Following_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("id", userId);
        args.putString("from_where", "following");
        following_f.setArguments(args);
        transaction.addToBackStack(null);


        View view = getActivity().findViewById(R.id.mainMenuFragment);

        if (view != null)
            transaction.replace(R.id.mainMenuFragment, following_f).commit();
        else
            transaction.replace(R.id.profile_F, following_f).commit();


    }

    // open the followers screen
    private void openFollowers() {

        Following_F following_f = new Following_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("id", userId);
        args.putString("from_where", "fan");
        following_f.setArguments(args);
        transaction.addToBackStack(null);


        View view = getActivity().findViewById(R.id.mainMenuFragment);

        if (view != null)
            transaction.replace(R.id.mainMenuFragment, following_f).commit();
        else
            transaction.replace(R.id.profile_F, following_f).commit();


    }


    @Override
    public void onDetach() {
        super.onDetach();


        if (fragment_callback != null)
            fragment_callback.onResponce(new Bundle());

        Functions.deleteCache(context);

    }


}
