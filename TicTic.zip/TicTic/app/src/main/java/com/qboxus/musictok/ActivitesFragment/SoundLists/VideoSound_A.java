package com.qboxus.musictok.ActivitesFragment.SoundLists;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.CacheDataSource;
import com.google.android.exoplayer2.upstream.cache.CacheDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;
import com.qboxus.musictok.ActivitesFragment.Accounts.Login_A;
import com.qboxus.musictok.ActivitesFragment.VideoRecording.Video_Recoder_Duet_A;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.Adapters.MyVideosAdapter;
import com.qboxus.musictok.R;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.TicTic;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.qboxus.musictok.ActivitesFragment.VideoRecording.Video_Recoder_A;
import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.PRDownloader;
import com.downloader.request.DownloadRequest;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.qboxus.musictok.ActivitesFragment.WatchVideos_F;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class VideoSound_A extends AppCompatActivity implements View.OnClickListener {

    HomeModel item;
    TextView soundName, descriptionTxt;
    ImageView soundImage;

    File audioFile;


    RecyclerView recyclerView;
    GridLayoutManager linearLayoutManager;
    ProgressBar loadMoreProgress;
    int pageCount = 0;
    boolean ispostFinsh;
    ArrayList<HomeModel> dataList;
    MyVideosAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_sound);

        Functions.makeDirectry(Functions.getAppFolder(this)+Variables.APP_HIDED_FOLDER);
        Functions.makeDirectry(Functions.getAppFolder(this)+Variables.DRAFT_APP_FOLDER);


        Intent intent = getIntent();
        if (intent.hasExtra("data")) {
            item = (HomeModel) intent.getSerializableExtra("data");
        }


        soundName = findViewById(R.id.sound_name);
        descriptionTxt = findViewById(R.id.description_txt);
        soundImage = findViewById(R.id.sound_image);

        if ((item.sound_name == null || item.sound_name.equals("") || item.sound_name.equals("null"))) {
            soundName.setText("original sound - " + item.first_name + " " + item.last_name);
        } else {
            soundName.setText(item.sound_name);
        }
        descriptionTxt.setText(item.video_description);


        findViewById(R.id.back_btn).setOnClickListener(this);

        findViewById(R.id.save_btn).setOnClickListener(this);
        findViewById(R.id.create_btn).setOnClickListener(this);

        findViewById(R.id.play_btn).setOnClickListener(this);
        findViewById(R.id.pause_btn).setOnClickListener(this);


        Uri uri = Uri.parse(item.sound_pic);
        soundImage.setImageURI(uri);

        Functions.printLog(Constants.tag, item.sound_pic);
        Functions.printLog(Constants.tag, item.sound_url_acc);

        saveAudio();


        recyclerView = findViewById(R.id.recylerview);
        linearLayoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(linearLayoutManager);

        dataList = new ArrayList<>();

        adapter = new MyVideosAdapter(this, dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {

                HomeModel item = (HomeModel) object;
                openWatchVideo(item.video_id);


            }
        });
        recyclerView.setAdapter(adapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            boolean userScrolled;
            int scrollOutitems;

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    userScrolled = true;
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                scrollOutitems = linearLayoutManager.findLastVisibleItemPosition();

                Functions.printLog("resp", "" + scrollOutitems);
                if (userScrolled && (scrollOutitems == dataList.size() - 1)) {
                    userScrolled = false;

                    if (loadMoreProgress.getVisibility() != View.VISIBLE && !ispostFinsh) {
                        loadMoreProgress.setVisibility(View.VISIBLE);
                        pageCount = pageCount + 1;
                        callApi();
                    }
                }


            }
        });


        loadMoreProgress = findViewById(R.id.load_more_progress);

        pageCount = 0;
        callApi();


    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.back_btn:
                onBackPressed();
                break;
            case R.id.save_btn:

                // save the audio file in local directry
                if (audioFile != null && audioFile.exists()) {
                    try {
                        Functions.copyFile(audioFile,
                                new File(Functions.getAppFolder(VideoSound_A.this) + item.video_id + ".acc"));
                        Functions.showAlert(VideoSound_A.this, "Audio Saved", "This sound is saved successfully");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;

            case R.id.create_btn:
                // make the video against specific sound id
                if (Functions.getSharedPreference(this).getBoolean(Variables.IS_LOGIN, false)) {
                    if (audioFile != null && audioFile.exists()) {
                        stopPlaying();
                        openVideoRecording();
                    }
                } else {
                    Intent intent = new Intent(this, Login_A.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
                }
                break;

            case R.id.play_btn:
                if (audioFile != null && audioFile.exists())
                    playaudio();

                break;

            case R.id.pause_btn:
                stopPlaying();
                break;
        }
    }


    // get the video list sound id
    public void callApi() {


        JSONObject params = new JSONObject();
        try {

            params.put("sound_id", item.sound_id);
            params.put("starting_point", "" + pageCount);
            params.put("device_id", Functions.getSharedPreference(this).getString(Variables.DEVICE_ID, ""));


        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(this, ApiLinks.showVideosAgainstSound, params, new Callback() {
            @Override
            public void onResponce(String resp) {
                parseVideo(resp);


            }
        });

    }


    // parse the data of the video list against sound id
    public void parseVideo(String responce) {
        try {
            JSONObject jsonObject = new JSONObject(responce);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msgArray = jsonObject.getJSONArray("msg");

                ArrayList<HomeModel> temp_list = new ArrayList<>();

                for (int i = 0; i < msgArray.length(); i++) {
                    JSONObject itemdata = msgArray.optJSONObject(i);

                    JSONObject video = itemdata.optJSONObject("Video");
                    JSONObject user = itemdata.optJSONObject("User");
                    JSONObject sound = itemdata.optJSONObject("Sound");
                    JSONObject userPrivacy = user.optJSONObject("PrivacySetting");
                    JSONObject userPushNotification = user.optJSONObject("PushNotification");

                    HomeModel item = Functions.parseVideoData(user, sound, video, userPrivacy, userPushNotification);

                    temp_list.add(item);
                }

                if (temp_list.isEmpty())
                    ispostFinsh = true;
                else {
                    dataList.addAll(temp_list);
                    adapter.notifyDataSetChanged();
                }


            }
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            loadMoreProgress.setVisibility(View.GONE);
        }

    }


    // open the video in full screen
    private void openWatchVideo(String video_id) {
        Intent intent = new Intent(this, WatchVideos_F.class);
        intent.putExtra("video_id", video_id);
        startActivity(intent);
    }


    // initialize the player for the audio

    SimpleExoPlayer player;

    public void playaudio() {

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(this);

        player = new SimpleExoPlayer.Builder(this).
                setTrackSelector(trackSelector)
                .build();

        SimpleCache simpleCache = TicTic.simpleCache;
        CacheDataSourceFactory cacheDataSourceFactory = new CacheDataSourceFactory(simpleCache, new DefaultHttpDataSourceFactory(Util.getUserAgent(this, getString(R.string.app_name)))
                , CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

        ProgressiveMediaSource videoSource = new ProgressiveMediaSource.Factory(cacheDataSourceFactory).createMediaSource(Uri.parse(item.video_url));

        player.prepare(videoSource);
        player.setPlayWhenReady(true);

        showPlayingState();
    }


    public void stopPlaying() {
        if (player != null) {
            player.setPlayWhenReady(false);
        }
        showPauseState();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        stopPlaying();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopPlaying();
        Functions.printLog(Constants.tag, "onStop");

    }


    // show the player state
    public void showPlayingState() {
        findViewById(R.id.play_btn).setVisibility(View.GONE);
        findViewById(R.id.pause_btn).setVisibility(View.VISIBLE);
    }

    public void showPauseState() {
        findViewById(R.id.play_btn).setVisibility(View.VISIBLE);
        findViewById(R.id.pause_btn).setVisibility(View.GONE);
    }

    DownloadRequest prDownloader;
    ProgressDialog progressDialog;

    public void saveAudio() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        prDownloader = PRDownloader.download(item.sound_url_acc, Functions.getAppFolder(this)+Variables.APP_HIDED_FOLDER, Variables.SelectedAudio_AAC)
                .build();

        prDownloader.start(new OnDownloadListener() {
            @Override
            public void onDownloadComplete() {
                progressDialog.dismiss();
                audioFile = new File(Functions.getAppFolder(VideoSound_A.this)+Variables.APP_HIDED_FOLDER + Variables.SelectedAudio_AAC);
            }

            @Override
            public void onError(Error error) {
                progressDialog.dismiss();
            }
        });


    }


    // open the camera for recording video
    public void openVideoRecording() {
        Intent intent = new Intent(VideoSound_A.this, Video_Recoder_A.class);
        intent.putExtra("sound_name", soundName.getText().toString());
        intent.putExtra("sound_id", item.sound_id);
        intent.putExtra("isSelected", "yes");
        startActivity(intent);
        overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);

    }


}
