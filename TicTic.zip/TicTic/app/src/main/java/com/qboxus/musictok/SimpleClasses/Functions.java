package com.qboxus.musictok.SimpleClasses;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qboxus.musictok.ActivitesFragment.LiveStreaming.CallBack;
import com.qboxus.musictok.ActivitesFragment.LiveStreaming.activities.LiveActivity;
import com.qboxus.musictok.ActivitesFragment.SendGift.Sticker_model;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Interfaces.APICallBack;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Models.CommentModel;
import com.qboxus.musictok.Models.HomeModel;
import com.qboxus.musictok.Models.PrivacyPolicySettingModel;
import com.qboxus.musictok.Models.PushNotificationSettingModel;
import com.qboxus.musictok.R;
import com.gmail.samehadar.iosdialog.CamomileSpinner;
import com.googlecode.mp4parser.authoring.Track;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * Created by qboxus on 2/20/2019.
 */

public class Functions {


    // change the color of status bar into black
    public static void blackStatusBar(Activity activity) {
        View view = activity.getWindow().getDecorView();

        int flags = view.getSystemUiVisibility();
        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        view.setSystemUiVisibility(flags);
        activity.getWindow().setStatusBarColor(Color.BLACK);
    }


    // change the color of status bar into white
    public static void whiteStatusBar(Activity activity) {
        View view = activity.getWindow().getDecorView();
        int flags = view.getSystemUiVisibility();
        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        view.setSystemUiVisibility(flags);
        activity.getWindow().setStatusBarColor(Color.WHITE);
    }


    // close the keybord
    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


    // open the keyboard
    public static void showKeyboard(Activity activity) {
        View view = activity.findViewById(android.R.id.content);
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        }
    }

    // retun the sharepref instance
    public static SharedPreferences getSharedPreference(Context context) {
        if (Variables.sharedPreferences != null)
            return Variables.sharedPreferences;
        else {
            Variables.sharedPreferences = context.getSharedPreferences(Variables.PREF_NAME, Context.MODE_PRIVATE);
            return Variables.sharedPreferences;
        }

    }

    // print any kind of log
    public static void printLog(String title, String text) {
        if (!Constants.IS_SECURE_INFO) {
            if (title != null && text != null)
                Log.d(title, text);
        }

    }

    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    // change string value to integer
    public static int parseInterger(String value) {
        if (value != null && !value.equals("")) {
            return Integer.parseInt(value);
        } else
            return 0;
    }

    // format the count value
    public static String getSuffix(String value) {
        try {

            if (value != null && (!value.equals("") && !value.equalsIgnoreCase("null"))) {
                long count = Long.parseLong(value);
                if (count < 1000)
                    return "" + count;
                int exp = (int) (Math.log(count) / Math.log(1000));
                return String.format("%.1f %c",
                        count / Math.pow(1000, exp),
                        "kMBTPE".charAt(exp - 1));
            } else {
                return "0";
            }
        } catch (Exception e) {
            return value;
        }

    }


    // return  the rundom string of given length
    public static String getRandomString(int n) {
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "abcdefghijklmnopqrstuvxyz";

        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());

            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }


    public static String removeSpecialChar(String s){
        return s.replaceAll("[^a-zA-Z0-9]", "");
    }

    // show loader of simple messages
    public static void showAlert(Context context, String title, String Message) {
        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(Message)
                .setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }




    // dialog for show loader for showing dialog with title and descriptions
    public static void showAlert(Context context, String title, String description, final CallBack callBack) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(description);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (callBack != null)
                    callBack.getResponse("alert", "OK");
            }
        });
        builder.create();
        builder.show();

    }


    // dialog for show any kind of alert
    public static void showAlert(Context context, String title, String Message, String postivebtn, String negitivebtn, final Callback callback) {

        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(Message)
                .setNegativeButton(negitivebtn, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        callback.onResponce("no");
                    }
                })
                .setPositiveButton(postivebtn, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                        callback.onResponce("yes");

                    }
                }).show();
    }

    // initialize the loader dialog and show
    public static Dialog dialog;

    public static void showLoader(Context context, boolean outside_touch, boolean cancleable) {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.item_dialog_loading_view);
        dialog.getWindow().setBackgroundDrawable(context.getResources().getDrawable(R.drawable.d_round_white_background));


        CamomileSpinner loader = dialog.findViewById(R.id.loader);
        loader.start();


        if (!outside_touch)
            dialog.setCanceledOnTouchOutside(false);

        if (!cancleable)
            dialog.setCancelable(false);

        dialog.show();
    }

    public static void cancelLoader() {
        if (dialog != null) {
            dialog.cancel();
        }
    }


    // show the diolge of video options
    @SuppressLint("SetTextI18n")
    public static void showVideoOption(Context context, final HomeModel home_model, final Callback callback) {


        final Dialog alertDialog = new Dialog(context);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.setContentView(R.layout.alert_label_editor);
        alertDialog.getWindow().setBackgroundDrawable(context.getResources().getDrawable(R.drawable.d_round_white_background));

        RelativeLayout btn_add_to_fav = alertDialog.findViewById(R.id.btn_add_to_fav);
        RelativeLayout btn_not_insterested = alertDialog.findViewById(R.id.btn_not_insterested);
        RelativeLayout btn_report = alertDialog.findViewById(R.id.btn_report);


        TextView fav_unfav_txt = alertDialog.findViewById(R.id.fav_unfav_txt);


        if (home_model.favourite != null && home_model.favourite.equals("1"))
            fav_unfav_txt.setText("Remove from favourite");
        else
            fav_unfav_txt.setText("Add to favourite");


        if (home_model.user_id.equalsIgnoreCase(Functions.getSharedPreference(context).getString(Variables.U_ID, ""))) {
            btn_report.setVisibility(View.GONE);
        }


        btn_add_to_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.dismiss();
                callback.onResponce("favourite");

            }
        });


        btn_not_insterested.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.dismiss();
                callback.onResponce("not_intrested");

            }
        });


        btn_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                callback.onResponce("report");
            }
        });

        alertDialog.show();
    }


    public static List<List<Sticker_model>> createChunksOfList(List<Sticker_model> originalList,
                                                  int chunkSize) {
        List<List<Sticker_model>> listOfChunks = new ArrayList<List<Sticker_model>>();
        for (int i = 0; i < originalList.size() / chunkSize; i++) {
            listOfChunks.add(originalList.subList(i * chunkSize, i * chunkSize
                    + chunkSize));
        }
        if (originalList.size() % chunkSize != 0) {
            listOfChunks.add((List<Sticker_model>) originalList.subList(originalList.size()
                    - originalList.size() % chunkSize, originalList.size()));
        }
        return listOfChunks;
    }


    // format the username
    public static String showUsername(String username) {
        if (username != null && username.contains("@"))
            return username;
        else
            return "@" + username;
    }


    public static boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i("isMyServiceRunning?", true + "");
                return true;
            }
        }
        Log.i("isMyServiceRunning?", false + "");
        return false;
    }


    public static boolean checkTimeDiffernce(Calendar current_cal, String date) {
        try {


            Calendar date_cal = Calendar.getInstance();

            SimpleDateFormat f = new SimpleDateFormat("dd-MM-yyyy HH:mm:ssZZ");
            Date d = null;
            try {
                d = f.parse(date);
                date_cal.setTime(d);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            long difference = (current_cal.getTimeInMillis() - date_cal.getTimeInMillis()) / 1000;


            Log.d(Constants.tag,"Tag : "+difference);

            if (difference <0) {
               return true;
            }
            else {
                return false;
            }

        } catch (Exception e) {
            return false;
        }


    }


    public static String changeDateTodayYesterday(Context context, String date) {
        try {
            Calendar current_cal = Calendar.getInstance();

            Calendar date_cal = Calendar.getInstance();

            SimpleDateFormat f = new SimpleDateFormat("dd-MM-yyyy HH:mm:ssZZ");
            Date d = null;
            try {
                d = f.parse(date);
                date_cal.setTime(d);
            } catch (ParseException e) {
                e.printStackTrace();
            }


            long difference = (current_cal.getTimeInMillis() - date_cal.getTimeInMillis()) / 1000;

            if (difference < 86400) {
                if (current_cal.get(Calendar.DAY_OF_YEAR) - date_cal.get(Calendar.DAY_OF_YEAR) == 0) {

                    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
                    return sdf.format(d);
                } else
                    return "yesterday";
            } else if (difference < 172800) {
                return "yesterday";
            } else
                return (difference / 86400) + " day ago";

        }
        catch (Exception e) {
            return date;
        }


    }


    public static String bitmapToBase64(Bitmap imagebitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        imagebitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] byteArray = baos.toByteArray();
        String base64 = Base64.encodeToString(byteArray, Base64.DEFAULT);
        return base64;
    }

    public static Bitmap base64ToBitmap(String base_64) {
        Bitmap decodedByte = null;
        try {

            byte[] decodedString = Base64.decode(base_64, Base64.DEFAULT);
            decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        } catch (Exception e) {

        }
        return decodedByte;
    }


    public static boolean isShowContentPrivacy(Context context, String string_case, boolean isFriend) {
        if (string_case == null)
            return true;
        else {
            string_case = stringParseFromServerRestriction(string_case);

            if (string_case.equalsIgnoreCase("Everyone")) {
                return true;
            } else if (string_case.equalsIgnoreCase("Friends") &&
                    Functions.getSharedPreference(context).getBoolean(Variables.IS_LOGIN, false) && isFriend) {
                return true;
            } else {
                return false;
            }


        }

    }

    public static String stringParseFromServerRestriction(String res_string) {
        res_string = res_string.toUpperCase();
        res_string = res_string.replace("_", " ");
        return res_string;
    }

    public static String stringParseIntoServerRestriction(String res_string) {
        res_string = res_string.toLowerCase();
        res_string = res_string.replace(" ", "_");
        return res_string;
    }


    public static double correctTimeToSyncSample(Track track, double cutHere, boolean next) {
        double[] timeOfSyncSamples = new double[track.getSyncSamples().length];
        long currentSample = 0;
        double currentTime = 0;
        for (int i = 0; i < track.getSampleDurations().length; i++) {
            long delta = track.getSampleDurations()[i];

            if (Arrays.binarySearch(track.getSyncSamples(), currentSample + 1) >= 0) {
                timeOfSyncSamples[Arrays.binarySearch(track.getSyncSamples(), currentSample + 1)] = currentTime;
            }
            currentTime += (double) delta / (double) track.getTrackMetaData().getTimescale();
            currentSample++;

        }
        double previous = 0;
        for (double timeOfSyncSample : timeOfSyncSamples) {
            if (timeOfSyncSample > cutHere) {
                if (next) {
                    return timeOfSyncSample;
                } else {
                    return previous;
                }
            }
            previous = timeOfSyncSample;
        }
        return timeOfSyncSamples[timeOfSyncSamples.length - 1];
    }


    // make the directory on specific path
    public static void makeDirectry(String path) {
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdir();
        }
    }


    // return the random string of 10 char
    public static String getRandomString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 10) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }


    public static long getFileDuration(Context context, Uri uri) {
        try {

            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            mmr.setDataSource(context, uri);
            String durationStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            final int file_duration = Functions.parseInterger(durationStr);

            return file_duration;
        } catch (Exception e) {

        }
        return 0;
    }



    public static String getAppFolder(Context activity){
        return activity.getExternalFilesDir(null).getPath()+"/";
    }



    // Bottom is all the Apis which is mostly used in app we have add it
    // just one time and whenever we need it we will call it

    public static void callApiForLikeVideo(final Activity activity,
                                           String video_id, String action,
                                           final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, "0"));
            parameters.put("video_id", video_id);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.likeVideo, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {

                if (api_callBack != null)
                    api_callBack.onSuccess(resp);
            }
        });


    }


    // this method will like the comment
    public static void callApiForLikeComment(final Activity activity,
                                             String video_id,
                                             final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, "0"));
            parameters.put("comment_id", video_id);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.likeComment, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {

                if (api_callBack != null)
                    api_callBack.onSuccess(resp);
            }
        });


    }


    // this method will like the reply comment
    public static void callApiForLikeCommentReply(final Activity activity,
                                                  String comment_reply_id,
                                                  final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, "0"));
            parameters.put("comment_reply_id", comment_reply_id);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.likeCommentReply, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {

                Functions.printLog(Constants.tag, "resp at like comment reply : " + resp);

                if (api_callBack != null)
                    api_callBack.onSuccess(resp);
            }
        });


    }


    public static void callApiForSendComment(final Activity activity, String videoId, String comment, final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, "0"));
            parameters.put("video_id", videoId);
            parameters.put("comment", comment);

        } catch (JSONException e) {
            e.printStackTrace();
        }


        ApiRequest.callApi(activity, ApiLinks.postCommentOnVideo, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {

                ArrayList<CommentModel> arrayList = new ArrayList<>();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {

                        JSONObject msg = response.optJSONObject("msg");
                        JSONObject videoComment = msg.optJSONObject("VideoComment");
                        JSONObject userobject = msg.optJSONObject("User");

                        CommentModel item = new CommentModel();

                        item.fb_id = userobject.optString("id");
                        item.user_name = userobject.optString("username");
                        item.first_name = userobject.optString("first_name");
                        item.last_name = userobject.optString("last_name");
                        item.profile_pic = userobject.optString("profile_pic");
                        if (!item.profile_pic.contains(Variables.http)) {
                            item.profile_pic = Constants.BASE_URL + item.profile_pic;
                        }

                        item.video_id = videoComment.optString("video_id");
                        item.comments = videoComment.optString("comment");
                        item.created = videoComment.optString("created");

                        arrayList.add(item);

                        api_callBack.arrayData(arrayList);

                    } else {
                        Functions.showToast(activity, "" + response.optString("msg"));
                    }

                } catch (JSONException e) {
                    api_callBack.onFail(e.toString());
                    e.printStackTrace();
                }

            }
        });


    }


    // this method will send the reply to the comment of the video
    public static void callApiForSendCommentReply(final Activity activity, String commentId, String comment, final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("comment_id", commentId);
            parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, "0"));
            parameters.put("comment", comment);

            Functions.printLog(Constants.tag, "parameters at reply : " + parameters);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        ApiRequest.callApi(activity, ApiLinks.postCommentReply, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.printLog(Constants.tag, "resp at reply : " + resp);

                ArrayList<CommentModel> arrayList = new ArrayList<>();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {

                        JSONObject msg = response.optJSONObject("msg");
                        JSONObject videoComment = msg.optJSONObject("VideoComment");
                        JSONObject videoCommentReply = msg.optJSONObject("VideoCommentReply");
                        JSONObject user = msg.optJSONObject("User");

                        CommentModel item = new CommentModel();

                        item.fb_id = user.optString("id");
                        item.first_name = user.optString("first_name");
                        item.last_name = user.optString("last_name");
                        item.replay_user_name = user.optString("username");
                        item.replay_user_url = user.optString("profile_pic");

                        item.video_id = videoComment.optString("video_id");
                        item.comments = videoComment.optString("comment");
                        item.created = videoComment.optString("created");


                        item.comment_reply_id = videoCommentReply.optString("id");
                        item.comment_reply = videoCommentReply.optString("comment");
                        item.parent_comment_id = videoCommentReply.optString("comment_id");
                        item.reply_create_date = videoCommentReply.optString("created");
                        item.reply_liked_count = "0";
                        item.comment_reply_liked = "0";

                        arrayList.add(item);
                        item.item_count_replies = "1";
                        api_callBack.arrayData(arrayList);

                    } else {
                        Functions.showToast(activity, "" + response.optString("msg"));
                    }

                } catch (JSONException e) {
                    api_callBack.onFail(e.toString());
                    e.printStackTrace();
                }
            }
        });


    }


    // this method will get all the comments of the specific video
    public static void callApiForGetComment(final Activity activity, String video_id, final APICallBack apiCallBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("video_id", video_id);
            if (Functions.getSharedPreference(activity).getBoolean(Variables.IS_LOGIN, false)) {
                parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, "0"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.showVideoComments, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.printLog(Constants.tag, "resp at comment : " + resp);
                ArrayList<CommentModel> arrayList = new ArrayList<>();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {


                        JSONArray msgArray = response.getJSONArray("msg");
                        for (int i = 0; i < msgArray.length(); i++) {
                            JSONObject itemdata = msgArray.optJSONObject(i);

                            JSONObject videoComment = itemdata.optJSONObject("VideoComment");
                            JSONObject userobject = itemdata.optJSONObject("User");

                            JSONArray videoCommentReply = itemdata.optJSONArray("VideoCommentReply");

                            ArrayList<CommentModel> replyList = new ArrayList<>();
                            if (videoCommentReply.length() > 0) {
                                for (int j = 0; j < videoCommentReply.length(); j++) {
                                    JSONObject jsonObject = videoCommentReply.getJSONObject(j);

                                    JSONObject reply_user = jsonObject.getJSONObject("User");
                                    CommentModel comment_model = new CommentModel();

                                    comment_model.comment_reply_id = jsonObject.optString("id");
                                    comment_model.reply_liked_count = jsonObject.optString("like_count");
                                    comment_model.comment_reply_liked = jsonObject.optString("like");
                                    comment_model.comment_reply = jsonObject.optString("comment");
                                    comment_model.created = jsonObject.optString("created");


                                    comment_model.replay_user_name = reply_user.optString("username");
                                    comment_model.replay_user_url = reply_user.optString("profile_pic");
                                    comment_model.parent_comment_id = videoComment.optString("id");
                                    replyList.add(comment_model);
                                }
                            }

                            CommentModel item = new CommentModel();


                            item.fb_id = userobject.optString("id");
                            item.user_name = userobject.optString("username");
                            item.first_name = userobject.optString("first_name");
                            item.last_name = userobject.optString("last_name");
                            item.arraylist_size = String.valueOf(videoCommentReply.length());
                            item.profile_pic = userobject.optString("profile_pic");
                            if (!item.profile_pic.contains(Variables.http)) {
                                item.profile_pic = Constants.BASE_URL + item.profile_pic;
                            }

                            item.arrayList = replyList;
                            item.video_id = videoComment.optString("video_id");
                            item.comments = videoComment.optString("comment");
                            item.liked = videoComment.optString("like");
                            item.like_count = videoComment.optString("like_count");
                            item.comment_id = videoComment.optString("id");
                            item.created = videoComment.optString("created");


                            arrayList.add(item);
                        }

                        apiCallBack.arrayData(arrayList);
                        apiCallBack.onSuccess(code.toString());
                    } else {
                        apiCallBack.onFail(code.toString());
                    }

                } catch (JSONException e) {
                    apiCallBack.onFail(e.toString());
                    e.printStackTrace();
                }
            }
        });

    }


    public static void callApiForUpdateView(final Activity activity,
                                            String video_id) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("device_id", Functions.getSharedPreference(activity).getString(Variables.DEVICE_ID, "0"));
            parameters.put("video_id", video_id);
            parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, ""));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.watchVideo, parameters, null);


    }


    public static void callApiForFollowUnFollow
            (final Activity activity,
             String fbId,
             String followedFbId,
             final APICallBack api_callBack) {

        Functions.showLoader(activity, false, false);


        JSONObject parameters = new JSONObject();
        try {
            parameters.put("sender_id", fbId);
            parameters.put("receiver_id", followedFbId);


        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.followUser, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {
                        api_callBack.onSuccess(response.toString());

                    } else {
                        Functions.showToast(activity, "" + response.optString("msg"));
                    }

                } catch (Exception e) {
                    api_callBack.onFail(e.toString());
                    e.printStackTrace();
                }
            }
        });


    }


    public static void callApiForGetUserData
            (final Activity activity,
             String fbId,
             final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("user_id", fbId);
            if (Functions.getSharedPreference(activity).getBoolean(Variables.IS_LOGIN, false) && fbId != null) {
                parameters.put("user_id", Functions.getSharedPreference(activity).getString(Variables.U_ID, ""));
                parameters.put("other_user_id", fbId);
            } else if (fbId != null) {
                parameters.put("user_id", fbId);
            } else {
                parameters.put("username", fbId);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.printLog("resp", parameters.toString());

        ApiRequest.callApi(activity, ApiLinks.showUserDetail, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {
                        api_callBack.onSuccess(response.toString());

                    } else {
                        Functions.showToast(activity, "" + response.optString("msg"));
                    }

                } catch (Exception e) {
                    api_callBack.onFail(e.toString());
                    e.printStackTrace();
                }
            }
        });

    }


    public static void callApiForDeleteVideo
            (final Activity activity,
             String videoId,
             final APICallBack api_callBack) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("video_id", videoId);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(activity, ApiLinks.deleteVideo, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();

                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {
                        if (api_callBack != null)
                            api_callBack.onSuccess(response.toString());

                    } else {
                        Functions.showToast(activity, "" + response.optString("msg"));
                    }

                } catch (Exception e) {
                    if (api_callBack != null)
                        api_callBack.onFail(e.toString());
                    e.printStackTrace();
                }


            }
        });


    }


    public static HomeModel parseVideoData(JSONObject user, JSONObject sound, JSONObject video, JSONObject userPrivacy, JSONObject userPushNotification) {
        HomeModel item = new HomeModel();

        if (user != null) {
            item.user_id = user.optString("id");
            item.username = user.optString("username");
            item.first_name = user.optString("first_name", "");
            item.last_name = user.optString("last_name", "");
            item.profile_pic = user.optString("profile_pic", "null");
            if (!item.profile_pic.contains(Variables.http)) {
                item.profile_pic = Constants.BASE_URL + item.profile_pic;
            }

            item.verified = user.optString("verified");
            item.follow_status_button = user.optString("button");
        }

        if (sound != null) {
            item.sound_id = sound.optString("id");
            item.sound_name = sound.optString("name");
            item.sound_pic = sound.optString("thum");

            item.sound_url_mp3 = sound.optString("audio");
            item.sound_url_acc = sound.optString("audio");

            if (!item.sound_url_mp3.contains(Variables.http)) {
                item.sound_url_mp3 = Constants.BASE_URL + item.sound_url_mp3;
            }
            if (!item.sound_url_acc.contains(Variables.http)) {
                item.sound_url_acc = Constants.BASE_URL + item.sound_url_acc;
            }

        }

        if (video != null) {

            item.like_count = "0" + video.optInt("like_count");
            item.video_comment_count = video.optString("comment_count");


            item.privacy_type = video.optString("privacy_type");
            item.allow_comments = video.optString("allow_comments");
            item.allow_duet = video.optString("allow_duet");
            item.video_id = video.optString("id");
            item.liked = video.optString("like");
            item.favourite = video.optString("favourite");

            item.views = video.optString("view");

            item.video_description = video.optString("description");
            item.favourite = video.optString("favourite");
            item.created_date = video.optString("created");

            item.thum = video.optString("thum");
            item.gif = video.optString("gif");
            item.video_url = video.optString("video", "");

            if (!item.video_url.contains(Variables.http)) {
                item.video_url = Constants.BASE_URL + item.video_url;
            }

            if (!item.thum.contains(Variables.http))
                item.thum = Constants.BASE_URL + item.thum;

            if (!item.gif.contains(Variables.http))
                item.gif = Constants.BASE_URL + item.gif;


            item.allow_duet = video.optString("allow_duet");
            item.duet_video_id = video.optString("duet_video_id");
            if (video.has("duet")) {
                JSONObject duet = video.optJSONObject("duet");
                if (duet != null) {
                    JSONObject duet_user_obj = duet.optJSONObject("User");
                    if (duet_user_obj != null)
                        item.duet_username = duet_user_obj.optString("username");
                }

            }


            item.promote = video.optString("promote");
            item.promotion_id = video.optString("promotion_id");
            JSONObject Promotion = video.optJSONObject("Promotion");
            if (Promotion != null) {
                item.destination = Promotion.optString("destination");
                item.website_url = Promotion.optString("website_url");
            }


            item.promote_button = video.optString("promote_button");


        }


        item.apply_privacy_model = new PrivacyPolicySettingModel();
        item.apply_push_notification_model = new PushNotificationSettingModel();

        if (userPrivacy != null) {
            item.apply_privacy_model.setVideo_comment(userPrivacy.optString("video_comment"));
            item.apply_privacy_model.setLiked_videos(userPrivacy.optString("liked_videos"));
            item.apply_privacy_model.setDuet(userPrivacy.optString("duet"));
            item.apply_privacy_model.setDirect_message(userPrivacy.optString("direct_message"));
            item.apply_privacy_model.setVideos_download(userPrivacy.optString("videos_download"));
        }

        if (userPushNotification != null) {
            item.apply_push_notification_model.setComments(userPushNotification.optString("comments"));
            item.apply_push_notification_model.setDirectmessage(userPushNotification.optString("direct_messages"));
            item.apply_push_notification_model.setLikes(userPushNotification.optString("likes"));
            item.apply_push_notification_model.setMentions(userPushNotification.optString("mentions"));
            item.apply_push_notification_model.setNewfollowers(userPushNotification.optString("new_followers"));
            item.apply_push_notification_model.setVideoupdates(userPushNotification.optString("video_updates"));
        }

        return item;

    }


    public static Dialog indeterminantDialog;

    public static void showIndeterminentLoader(Context context, boolean outside_touch, boolean cancleable) {

        indeterminantDialog = new Dialog(context);
        indeterminantDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        indeterminantDialog.setContentView(R.layout.item_indeterminant_progress_layout);
        indeterminantDialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.d_round_white_background));


        if (!outside_touch)
            indeterminantDialog.setCanceledOnTouchOutside(false);

        if (!cancleable)
            indeterminantDialog.setCancelable(false);

        indeterminantDialog.show();

    }


    public static void cancelIndeterminentLoader() {
        if (indeterminantDialog != null) {
            indeterminantDialog.cancel();
        }
    }


    public static Dialog determinant_dialog;
    public static ProgressBar determinant_progress;

    public static void showDeterminentLoader(Context context, boolean outside_touch, boolean cancleable) {

        determinant_dialog = new Dialog(context);
        determinant_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        determinant_dialog.setContentView(R.layout.item_determinant_progress_layout);
        determinant_dialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.d_round_white_background));

        determinant_progress = determinant_dialog.findViewById(R.id.pbar);

        if (!outside_touch)
            determinant_dialog.setCanceledOnTouchOutside(false);

        if (!cancleable)
            determinant_dialog.setCancelable(false);

        determinant_dialog.show();

    }

    public static void showLoadingProgress(int progress) {
        if (determinant_progress != null) {
            determinant_progress.setProgress(progress);

        }
    }


    public static void cancelDeterminentLoader() {
        if (determinant_dialog != null) {
            determinant_progress = null;
            determinant_dialog.cancel();
        }
    }


    public static boolean checkStoragePermision(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (activity.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;

            } else {

                activity.requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        } else {

            return true;
        }
    }


    public static boolean checkPermissions(Activity context) {

        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
        };

        if (!hasPermissions(context, PERMISSIONS)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                context.requestPermissions(PERMISSIONS, 2);
            }
        } else {

            return true;
        }

        return false;
    }


    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    // these function are remove the cache memory which is very helpfull in memmory managmet
    public static void deleteCache(Context context) {


        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if (dir != null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }

    public static void copyFile(File sourceFile, File destFile) throws IOException {
        if (!destFile.getParentFile().exists())
            destFile.getParentFile().mkdirs();

        if (!destFile.exists()) {
            destFile.createNewFile();
        }

        FileChannel source = null;
        FileChannel destination = null;

        try {
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } finally {
            if (source != null) {
                source.close();
            }
            if (destination != null) {
                destination.close();
            }
        }
    }

    public static void showToast(Context context, String msg) {
        if (Constants.IS_TOAST_ENABLE) {
            Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
        }
    }


}
