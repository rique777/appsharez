package com.qboxus.musictok.ActivitesFragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.qboxus.musictok.ActivitesFragment.LiveStreaming.LiveUserAdapter;
import com.qboxus.musictok.ActivitesFragment.LiveStreaming.LiveUserModel;
import com.qboxus.musictok.ActivitesFragment.LiveStreaming.activities.LiveActivity;
import com.qboxus.musictok.Interfaces.AdapterClickListener;
import com.qboxus.musictok.MainMenu.RelateToFragmentOnBack.RootFragment;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.TicTic;

import java.util.ArrayList;

import io.agora.rtc.Constants;

/**
 * A simple {@link Fragment} subclass.
 */
public class LiveUsers_F extends RootFragment implements View.OnClickListener {


    View view;
    Context context;
    ArrayList<LiveUserModel> dataList;
    RecyclerView recyclerView;
    LiveUserAdapter adapter;

    ImageView btnBack;

    DatabaseReference rootref;

    TextView noDataFound;

    public LiveUsers_F() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_live_users, container, false);
        context = getContext();
        rootref = FirebaseDatabase.getInstance().getReference();

        btnBack = view.findViewById(R.id.back_btn);
        btnBack.setOnClickListener(this);

        dataList = new ArrayList<>();

        recyclerView = (RecyclerView) view.findViewById(R.id.recylerview);
        recyclerView.setLayoutManager(new GridLayoutManager(context, 2));

        recyclerView.setHasFixedSize(true);

        adapter = new LiveUserAdapter(context, dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                LiveUserModel live_user_model = (LiveUserModel) object;
                openTicTicLive(live_user_model.getUser_id(),
                        live_user_model.getUser_name(), live_user_model.getUser_picture(), Constants.CLIENT_ROLE_AUDIENCE);

            }
        });

        recyclerView.setAdapter(adapter);


        getData();

        noDataFound = view.findViewById(R.id.no_data_found);
        return view;
    }


    // get the list of all live user from the firebase
    ChildEventListener valueEventListener;
    public void getData() {

        valueEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                LiveUserModel model = dataSnapshot.getValue(LiveUserModel.class);
                dataList.add(model);
                adapter.notifyDataSetChanged();
                noDataFound.setVisibility(View.GONE);

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                LiveUserModel model = dataSnapshot.getValue(LiveUserModel.class);

                for (int i = 0; i < dataList.size(); i++) {
                    if (model.getUser_id().equals(dataList.get(i).getUser_id())) {
                        dataList.remove(i);
                    }
                }
                adapter.notifyDataSetChanged();

                if (dataList.isEmpty()) {
                    noDataFound.setVisibility(View.VISIBLE);
                }


            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };


        rootref.child("LiveUsers").addChildEventListener(valueEventListener);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (rootref != null && valueEventListener != null)
            rootref.child("LiveUsers").removeEventListener(valueEventListener);
    }


    // watch the streaming of user which will be live
    public void openTicTicLive(String userId, String userName, String userImage, int role) {

        if (checkPermissions()) {

            final Intent intent = new Intent();
            intent.putExtra("user_id", userId);
            intent.putExtra("user_name", userName);
            intent.putExtra("user_picture", userImage);
            intent.putExtra("user_role", role);
            intent.putExtra(com.qboxus.musictok.ActivitesFragment.LiveStreaming.Constants.KEY_CLIENT_ROLE, role);
            intent.setClass(getActivity(), LiveActivity.class);
            TicTic ticTic = (TicTic) getActivity().getApplication();
            ticTic.engineConfig().setChannelName(userId);
            startActivity(intent);

        }

    }


    // check the camera and mic permission before open the streaming
    public boolean checkPermissions() {

        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
        };

        if (!hasPermissions(context, PERMISSIONS)) {
            requestPermissions(PERMISSIONS, 2);
        } else {

            return true;
        }

        return false;
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {

                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }

            }
        }
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back_btn:
                getActivity().onBackPressed();
                break;
        }
    }


}
