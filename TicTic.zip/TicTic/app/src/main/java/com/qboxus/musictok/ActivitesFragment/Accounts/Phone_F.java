package com.qboxus.musictok.ActivitesFragment.Accounts;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.auth.api.credentials.Credential;
import com.qboxus.musictok.Constants;
import com.qboxus.musictok.Models.UserModel;
import com.qboxus.musictok.R;
import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.ybs.countrypicker.CountryPicker;
import com.ybs.countrypicker.CountryPickerListener;

import org.json.JSONException;
import org.json.JSONObject;

import io.michaelrocks.libphonenumber.android.PhoneNumberUtil;

import static android.app.Activity.RESULT_OK;


public class Phone_F extends Fragment implements View.OnClickListener {

    public final static int RESOLVE_HINT = 1011;
    View view;
    TextView tvCountryCode;
    RelativeLayout mainRlt;
    FrameLayout container;
    String countryDialingCode = "", countryCodeValue, mPhoneNumber, fromWhere;
    EditText phoneEdit;
    UserModel userModel;
    Button btnSendCode;
    TextView loginTermsConditionTxt;
    String phoneNo;
    CountryCodePicker ccp;

    public Phone_F(UserModel userModel, String fromWhere) {
        this.userModel = userModel;
        this.fromWhere = fromWhere;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_phone, container, false);
        initView();

        clickListnere();

        // this will get the current country of mobile device

        TelephonyManager tm = (TelephonyManager) getActivity().getSystemService(getActivity().TELEPHONY_SERVICE);
        if (tm != null) {
            countryCodeValue = tm.getNetworkCountryIso().toUpperCase();
            int cc = PhoneNumberUtil.createInstance(getActivity()).getCountryCodeForRegion(countryCodeValue);
            tvCountryCode.setText(countryCodeValue.toUpperCase() + " " + cc);
            countryDialingCode = String.valueOf(cc);
        }


        if (fromWhere != null && fromWhere.equals("login")) {

            loginTermsConditionTxt.setVisibility(View.GONE);

        }


        return view;
    }


    // this will initialize all the views
    private void initView() {
        tvCountryCode = view.findViewById(R.id.country_code);
        loginTermsConditionTxt = view.findViewById(R.id.login_terms_condition_txt);
        container = view.findViewById(R.id.container);
        mainRlt = view.findViewById(R.id.main_rlt);
        phoneEdit = view.findViewById(R.id.phone_edit);
        btnSendCode = view.findViewById(R.id.btn_send_code);
        btnSendCode.setOnClickListener(this);


        phoneEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                String txtName = phoneEdit.getText().toString();
                if (txtName.length() > 0) {
                    btnSendCode.setEnabled(true);
                    btnSendCode.setClickable(true);
                } else {
                    btnSendCode.setEnabled(false);
                    btnSendCode.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        ccp = view.findViewById(R.id.ccp);

        ccp.registerPhoneNumberTextView(phoneEdit);
    }

    private void clickListnere() {
        tvCountryCode.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.country_code:
                opencountry();
                break;
            case R.id.btn_send_code:
                if (checkValidation()) {

                    if (!ccp.isValid()) {
                        phoneEdit.setError("Invalid Phone Number");
                        return;
                    }

                    phoneNo = phoneEdit.getText().toString();
                    if (phoneNo.charAt(0) == '0') {
                        phoneNo = phoneNo.substring(1);
                    }
                    phoneNo = ccp.getSelectedCountryCodeWithPlus() + phoneNo;

                    callApiOtp();
                }

                break;
        }
    }

    public boolean checkValidation() {

        final String st_phone = phoneEdit.getText().toString();

        if (TextUtils.isEmpty(st_phone)) {
            Functions.showToast(getActivity(), "Please enter phone number");
            return false;
        }


        return true;
    }

    private void callApiOtp() {

        JSONObject parameters = new JSONObject();
        try {

            parameters.put("phone", phoneNo);
            parameters.put("verify", "0");
        } catch (
                JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(getActivity(), false, false);
        ApiRequest.callApi(getActivity(), ApiLinks.verifyPhoneNo, parameters, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                parseLoginData(resp);
            }
        });


    }

    // if api return the ok responce then open the get opt screen
    public void parseLoginData(String loginData) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
                PhoneOtp_F phoneOtp_f = new PhoneOtp_F();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.setCustomAnimations(R.anim.in_from_right, R.anim.out_to_left, R.anim.in_from_left, R.anim.out_to_right);
                Bundle bundle = new Bundle();
                String phone_no = phoneEdit.getText().toString();
                bundle.putString("phone_number", phoneNo);
                userModel.phone_no = phone_no;
                bundle.putSerializable("user_data", userModel);
                phoneOtp_f.setArguments(bundle);
                transaction.addToBackStack(null);
                transaction.replace(R.id.sign_up_fragment, phoneOtp_f).commit();

            } else {
                Functions.showToast(getActivity(), jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    // this will open the county picker screen
    @SuppressLint("WrongConstant")
    public void opencountry() {
        final CountryPicker picker = CountryPicker.newInstance("Select Country");
        picker.setListener(new CountryPickerListener() {
            @Override
            public void onSelectCountry(String name, String code, String dialCode, int flagDrawableResID) {

                countryDialingCode = dialCode;
                tvCountryCode.setText(code + " " + dialCode);
                picker.dismiss();

            }
        });
        picker.show(getFragmentManager(), "Select Country");
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == RESOLVE_HINT) {
            com.google.android.gms.auth.api.credentials.Credential credential = data.getParcelableExtra(Credential.EXTRA_KEY);
            if (credential != null) {
                mPhoneNumber = credential.getId();
                if (mPhoneNumber != null) {
                    mPhoneNumber = mPhoneNumber.replace(countryDialingCode, "");
                    if (phoneEdit == null)
                        phoneEdit = view.findViewById(R.id.phone_edit);

                    phoneEdit.setText(mPhoneNumber);
                }
                Functions.printLog(Constants.tag, "mPhoneNumber" + mPhoneNumber);

            } else {
                Functions.showToast(getActivity(), "err");
            }
        }

    }


}