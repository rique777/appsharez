package com.qboxus.musictok.Models;

public class DraftVideoModel {
    public String video_path, video_time;
    public long video_duration_ms;
}
