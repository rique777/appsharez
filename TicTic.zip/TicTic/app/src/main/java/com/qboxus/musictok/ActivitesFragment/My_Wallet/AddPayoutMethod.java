package com.qboxus.musictok.ActivitesFragment.My_Wallet;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.qboxus.musictok.ApiClasses.ApiLinks;
import com.qboxus.musictok.ApiClasses.ApiRequest;
import com.qboxus.musictok.Interfaces.Callback;
import com.qboxus.musictok.Interfaces.FragmentCallBack;
import com.qboxus.musictok.R;
import com.qboxus.musictok.SimpleClasses.Functions;
import com.qboxus.musictok.SimpleClasses.Variables;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.function.Function;


public class AddPayoutMethod extends Fragment implements View.OnClickListener{

    View view;
    EditText etEmail;
    Button btnAdd;
    FragmentCallBack callBack;

    public AddPayoutMethod(FragmentCallBack callBack) {
        this.callBack = callBack;
    }

    public AddPayoutMethod() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_add_payout_method, container, false);
        InitControl();
        ActionContorl();
        return view;
    }

    private void ActionContorl() {
        etEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                // check the email validation during user typing
                String txtName = etEmail.getText().toString();
                if (txtName.length() > 0) {
                    if (Functions.isValidEmail(etEmail.getText().toString()))
                    {
                        btnAdd.setEnabled(true);
                        btnAdd.setClickable(true);
                    }
                    else
                    {
                        btnAdd.setEnabled(false);
                        btnAdd.setClickable(false);
                    }
                } else {
                    btnAdd.setEnabled(false);
                    btnAdd.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void InitControl() {
        etEmail=view.findViewById(R.id.et_email);
        btnAdd=view.findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(this);

        view.findViewById(R.id.goBack1).setOnClickListener(this::onClick);
        SetupScreenData();
    }

    private void SetupScreenData() {
        if (getArguments().getBoolean("isEdit",false))
        {
            etEmail.setText(getArguments().getString("email"));
            btnAdd.setText("Update Payout");
        }
        else
        {
            btnAdd.setText("Add Payout");
        }

    }


    private void CallApiAddPayment() {
        JSONObject sendobj = new JSONObject();
        try {
            sendobj.put("user_id", Functions.getSharedPreference(view.getContext()).getString(Variables.U_ID, "0"));
            sendobj.put("email", etEmail.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Functions.showLoader(view.getContext(),false,false);
        ApiRequest.callApi(getActivity(), ApiLinks.addPayout, sendobj, new Callback() {
            @Override
            public void onResponce(String resp) {
                Functions.cancelLoader();
                if (resp!=null){

                    try {
                        JSONObject respobj = new JSONObject(resp);

                        if (respobj.optString("code").equals("200")){
                            JSONObject msgObj=respobj.getJSONObject("msg");
                            JSONObject userdata = msgObj.getJSONObject("User");
                            SharedPreferences.Editor editor = Functions.getSharedPreference(view.getContext()).edit();
                            editor.putString(Variables.U_PAYOUT_ID, userdata.optString("paypal",""));
                            editor.commit();
                            Bundle bundle=new Bundle();
                            bundle.putBoolean("isShow",true);
                            callBack.onResponce(bundle);
                            getActivity().onBackPressed();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }
        });
    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {

            case R.id.goBack1:
                getActivity().onBackPressed();
                break;

            case R.id.btnAdd:
            {
                if (TextUtils.isEmpty(etEmail.getText().toString()))
                {
                    etEmail.setError("Email is can't empety");
                    etEmail.setFocusable(true);
                    return;
                }
                if (!(Functions.isValidEmail(etEmail.getText().toString())))
                {
                    etEmail.setError("Email format is invalid");
                    etEmail.setFocusable(true);
                    return;
                }
                CallApiAddPayment();


            }
            break;
        }
    }


}